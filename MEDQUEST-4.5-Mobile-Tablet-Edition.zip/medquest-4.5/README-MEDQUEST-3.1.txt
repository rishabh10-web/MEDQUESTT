# MEDQUEST 3.1 — Milestone 3: The Clinical World

This release builds on the MEDQUEST 3.0 light-mode pixel-art RPG project.

## Milestone 3 features
- Five structured OPD cases: DKA, inferior STEMI, community-acquired pneumonia, acute appendicitis and iron-deficiency anaemia.
- Topic matching with direct matches first and integrated supporting-concept matches second.
- Difficulty-specific case pool.
- Optional prioritisation of selected topics marked Revision.
- Local progress records with latest score per unique case.
- Topic-level and subject-level score summaries.
- Legacy reviewed case IDs remain visible even when no pre-M3 score was stored.

## Run locally
```powershell
npm.cmd install
npm.cmd run build
npm.cmd run dev
```

## Data and safety
Clinical cases are structured educational simulations with predetermined teaching data and answer keys. They are not a substitute for supervised clinical care or local protocols. Clinical content should be reviewed by qualified clinicians before educational/public deployment.

## Persistence
Existing V3 LocalStorage keys are retained. New keys:
- `mq-case-results-v1`
- `mq-prioritize-revision-v1`

Progress is local to the browser and is not synced across devices.
