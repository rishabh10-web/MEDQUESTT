# MEDQUEST M6 — GIT Clinical Content Expansion

## Included
- 116 original GIT clinical case records.
- Four existing difficulty tiers: Easy, Medium, Hard, Expert; case pool sorted in that order.
- Integrated tags across Anatomy, Physiology, Pathology, Pharmacology, Microbiology, Medicine, Histology and Embryology.
- New GIT topic groupings for the syllabus, including histology and embryology.
- Topic-tree migration merges new M6 topics into existing local saves without replacing existing topic status/progress.
- Existing M5 progression/customisation and the original OPD case are retained.

## Content note
Cases are newly authored educational vignettes informed by the supplied First Aid and GIT subject PDFs and USMLE Rx material. UWorld 2024 was not supplied for this release. No source question text is reproduced. Some shared examination panels, distractor rationales and supporting test options use common templates; targeted diagnosis, vignette, mechanism, test and management anchors vary by case. Review the cases clinically before using them as a high-stakes assessment resource. All numerical investigation results are illustrative teaching values, not patient-specific reference ranges.

## Run locally
```powershell
npm.cmd install
npm.cmd run dev
```
Production build: `npm.cmd run build`.

## Verification status
- 116 unique case IDs verified by script.
- Difficulty counts: 17 Easy, 36 Medium, 40 Hard, 23 Expert.
- ZIP integrity checked after packaging.
- Production build not verified: dependency installation timed out in the build environment, leaving React/Vite dependencies unavailable.
