MEDQUEST 3.0 — Clinical RPG UI Update

This build advances the project version to 3.0 and includes the requested UI refinements:
- Brighter, differentiated investigation result cards.
- Pixel-art diagnostic icons for vitals, glucose, ketones, blood gas, electrolytes (K+), renal function, CBC, urine, ECG and chest X-ray.
- CASE NOTE heading uses one consistent font with inherited text shadow removed.
- Topic selection, saved presets and configuration headings use a coordinated pastel palette.
- Existing case data, answer keys, navigation, and local save logic are retained.

Install:
1. Back up your existing MEDQUEST folder.
2. Extract this project.
3. In the project folder run: npm.cmd install
4. Run: npm.cmd run build
5. If build passes, run: npm.cmd run dev

No backend is required. Google Fonts are loaded through the existing CSS @import when online.
The build has not been production-tested in this packaging environment.
