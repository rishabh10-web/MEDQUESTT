import { additionalCases } from "./clinicalCases";
import { gitCases } from "./gitCases";
import { renalCases } from "./renalCases";
import { hematologyCases } from "./hematologyCases";
export const SUBJECTS = [
  "Anatomy", "Physiology", "Biochemistry", "Pathology", "Pharmacology",
  "Microbiology", "Immunology", "Genetics", "Behavioral sciences", "Histology", "Embryology", "Medicine"
] as const;

export type Subject = typeof SUBJECTS[number];
export type Topic = { id: string; name: string; status: "Active" | "Revision" | "Completed" };
export type TopicTree = Record<string, Record<string, Topic[]>>;
export type Investigation = {
  id: string; name: string; category: string; relevance: string; result: string;
  units?: string; reference?: string; interpretation: string; useful: boolean;
};
export type Case = {
  id: string; title: string; difficulty: string; subjectTags: string[];
  topicTags: string[]; supportingConcepts: string[];
  patient: { age: number; sex: string; name: string; portrait: string };
  complaint: string; hopi: string; background: string[];
  examination: string[]; vitals: { label: string; value: string; flag?: string }[];
  investigations: Investigation[];
  diagnosisOptions: string[]; correctDiagnosis: string;
  mechanismOptions: string[]; correctMechanism: string;
  differentials: { name: string; whyNot: string }[];
  managementOptions: { id: string; label: string; detail: string }[];
  correctManagement: string[];
  explanation: string; pathophysiology: string;
  learningObjectives: string[];
};

const seed: Record<Subject, Record<string, string[]>> = {
  Anatomy: {
    "General anatomy": ["Upper limb", "Lower limb", "Thorax", "Abdomen", "Head and neck", "Neuroanatomy"],
    "Organ systems": ["Cardiovascular anatomy", "Respiratory anatomy", "Gastrointestinal anatomy", "Urogenital anatomy"]
  },
  Physiology: {
    "General physiology": ["Cell physiology", "Blood", "Nerve and muscle"],
    "Organ systems": ["Cardiovascular physiology", "Respiratory physiology", "Renal physiology", "Gastrointestinal physiology", "Endocrine physiology", "CNS physiology", "Reproductive physiology"]
  },
  Biochemistry: {
    "Molecular foundations": ["Enzymes", "Vitamins", "Molecular biology", "Genetics and gene expression"],
    "Metabolism": ["Carbohydrate metabolism", "Lipid metabolism", "Protein metabolism", "Nutrition", "Inborn errors of metabolism"]
  },
  Pathology: {
    "General pathology": ["Cell injury and adaptation", "Inflammation and repair", "Hemodynamic disorders", "Neoplasia", "Genetic disorders"],
    "Systemic pathology": ["Cardiovascular pathology", "Respiratory pathology", "Renal pathology", "Gastrointestinal pathology", "Endocrine pathology", "Hematopathology", "CNS pathology"]
  },
  Pharmacology: {
    "General pharmacology": ["Pharmacokinetics", "Pharmacodynamics", "Autonomic pharmacology"],
    "Systemic pharmacology": ["Cardiovascular drugs", "Respiratory drugs", "CNS drugs", "Antimicrobials", "Endocrine drugs", "Chemotherapy"]
  },
  Microbiology: {
    "Foundations": ["Bacteriology", "Virology", "Mycology", "Parasitology", "Sterilization and disinfection"],
    "Clinical microbiology": ["Respiratory infections", "CNS infections", "Gastrointestinal infections", "Genitourinary infections", "Systemic infections"]
  },
  Immunology: {
    "Immune foundations": ["Innate immunity", "Adaptive immunity", "Antibodies", "Complement", "Hypersensitivity", "Immunodeficiency", "Transplantation"]
  },
  Genetics: {
    "Human genetics": ["Inheritance patterns", "Chromosomal disorders", "Molecular genetics", "Population genetics", "Genetic testing"]
  },
  "Behavioral sciences": {
    "Psychiatry and behavior": ["Learning and memory", "Personality", "Psychiatric disorders", "Ethics", "Communication", "Biostatistics and epidemiology"]
  },
  Histology: { "Organ systems": ["Oesophageal and gastric histology", "Small and large intestinal histology", "Liver and gallbladder histology", "Pancreatic histology"] },
  Embryology: { "Organ systems": ["Foregut development", "Midgut rotation and derivatives", "Hindgut development", "Ventral wall and congenital anomalies"] },
  Medicine: { "Clinical foundations": ["Clinical reasoning", "Systemic disease"] }
};

const gitTopicNames: Record<string, string[]> = {
  Anatomy: ["Oesophagus and stomach", "Small and large intestine", "Liver, biliary tree and pancreas", "Peritoneum and abdominal vasculature", "Anorectal anatomy"],
  Physiology: ["Motility and swallowing", "Gastric secretion", "Pancreatic and biliary secretion", "Digestion and absorption", "Intestinal fluid and electrolyte transport"],
  Pathology: ["Oesophageal disorders", "Gastric and duodenal disorders", "Small intestinal disorders", "Colorectal disorders", "Hepatobiliary disorders", "Pancreatic disorders"],
  Pharmacology: ["Acid suppression and mucosal protection", "Antiemetics and prokinetics", "Inflammatory bowel disease drugs", "Laxatives and antidiarrhoeals", "Hepatobiliary and pancreatic drugs", "Gastrointestinal antimicrobials"],
  Microbiology: ["Bacterial enteritis", "Viral gastroenteritis", "Protozoal and helminthic disease", "H pylori and C difficile", "Hepatitis viruses"],
  Medicine: ["Upper gastrointestinal presentations", "Lower gastrointestinal presentations", "Hepatology", "Pancreatobiliary medicine", "GI emergencies and nutrition"],
  Histology: ["Oesophageal and gastric histology", "Small and large intestinal histology", "Liver and gallbladder histology", "Pancreatic histology"],
  Embryology: ["Foregut development", "Midgut rotation and derivatives", "Hindgut development", "Ventral wall and congenital anomalies"]
};


const renalTopicNames: Record<string, string[]> = {
  Anatomy: ["Kidney and ureter anatomy", "Renal vasculature and collecting system"],
  Physiology: ["Glomerular filtration and renal blood flow", "Tubular transport and concentration", "Electrolyte and acid-base regulation", "Water balance and RAAS"],
  Pathology: ["Glomerular diseases", "Acute kidney injury", "Chronic kidney disease", "Tubulointerstitial and vascular disease", "Renal neoplasia and stones"],
  Pharmacology: ["Diuretics and tubular transport", "RAAS drugs and renal hemodynamics", "Nephrotoxic drugs and renal dosing"],
  Microbiology: ["Urinary tract infections", "Renal infections and tuberculosis"],
  Histology: ["Glomerular filtration barrier", "Tubular segments and collecting duct", "Juxtaglomerular apparatus"],
  Embryology: ["Ureteric bud and metanephric mesenchyme", "Congenital renal and urinary anomalies"],
  Medicine: ["Nephritic and nephrotic syndromes", "AKI and CKD", "Electrolyte and acid-base disorders", "Stones, obstruction and urinary infections", "Transplant and renal emergencies"]
};


const hematologyTopicNames: Record<string, string[]> = {
  Anatomy: ["Hematopoietic organs and marrow anatomy"],
  Physiology: ["Hematopoiesis and blood cell physiology", "Hemostasis and coagulation physiology"],
  Pathology: ["Hematopathology", "Anemia and red cell disorders", "Leukemia and lymphoma", "Platelet and coagulation disorders", "Transfusion medicine"],
  Pharmacology: ["Hematologic drugs and anticoagulants", "Antineoplastic mechanisms and adverse effects"],
  Microbiology: ["Blood-borne infections and marrow pathogens"],
  Histology: ["Blood smear and bone marrow histology"],
  Embryology: ["Hematopoietic development and fetal hemoglobin"],
  Medicine: ["Anemia approach and hemolysis", "Hematologic malignancies", "Bleeding and thrombotic disorders", "Transfusion and oncologic emergencies"]
};

export const makeInitialTree = (): TopicTree => {
  const base = Object.fromEntries(
  Object.entries(seed).map(([subject, systems]) => [
    subject,
    Object.fromEntries(Object.entries(systems).map(([system, topics]) => [
      system, topics.map((name, i) => ({ id: `${slug(subject)}-${slug(system)}-${i}`, name, status: "Active" as const }))
    ]))
  ])) as TopicTree;
  for (const [subject, topics] of Object.entries(gitTopicNames)) {
    if (!base[subject]) base[subject] = {};
    base[subject]["Gastrointestinal system"] = topics.map((name, i) => ({ id: `${slug(subject)}-git-${i}`, name, status: "Active" as const }));
  }
  for (const [subject, topics] of Object.entries(hematologyTopicNames)) {
    if (!base[subject]) base[subject] = {};
    base[subject]["Hematology system"] = topics.map((name, i) => ({ id: `${slug(subject)}-hema-${i}`, name, status: "Active" as const }));
  }
  for (const [subject, topics] of Object.entries(renalTopicNames)) {
    if (!base[subject]) base[subject] = {};
    base[subject]["Renal system"] = topics.map((name, i) => ({ id: `${slug(subject)}-renal-${i}`, name, status: "Active" as const }));
  }
  return base;
};

export const mergeTopicTree = (saved: TopicTree): TopicTree => {
  const defaults = makeInitialTree();
  const merged: TopicTree = { ...defaults };
  for (const [subject, systems] of Object.entries(saved || {})) {
    merged[subject] = { ...(merged[subject] || {}) };
    for (const [system, topics] of Object.entries(systems || {})) {
      const existing = topics || [];
      const defaultTopics = merged[subject][system] || [];
      const byId = new Map(existing.map(t => [t.id, t]));
      merged[subject][system] = [...existing, ...defaultTopics.filter(t => !byId.has(t.id))];
    }
  }
  return merged;
};

export const slug = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
export const readStore = <T,>(key: string, fallback: T): T => {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) as T : fallback; }
  catch { return fallback; }
};
export const writeStore = (key: string, value: unknown) => localStorage.setItem(key, JSON.stringify(value));

export const CASES: Case[] = [{
  id: "mq-opd-001",
  title: "The Thirst That Wouldn't Stop",
  difficulty: "Medium",
  subjectTags: ["Pathology", "Physiology", "Biochemistry", "Pharmacology"],
  topicTags: ["Endocrine pathology", "Endocrine physiology", "Carbohydrate metabolism", "Endocrine drugs"],
  supportingConcepts: ["Renal physiology", "Acid–base physiology", "Potassium shifts", "Fluid and electrolyte balance"],
  patient: { age: 19, sex: "Female", name: "Aarohi M.", portrait: "/portraits/young-woman.png" },
  complaint: "Vomiting, abdominal pain and excessive thirst for one day",
  hopi: "A 19-year-old woman with type 1 diabetes presents with one day of nausea, repeated vomiting, diffuse abdominal discomfort, marked thirst and frequent urination. She has felt increasingly fatigued over two days. She has been unable to keep food down and missed her usual basal insulin for the last two nights. No chest pain, cough, dysuria or focal abdominal pain is reported.",
  background: ["Known type 1 diabetes mellitus since age 12", "Uses basal–bolus insulin; missed basal doses for approximately 48 hours", "No known drug allergies", "No known chronic kidney disease"],
  examination: ["Appears tired and dehydrated; answers questions appropriately", "Dry mucous membranes and reduced skin turgor", "Deep, rapid breathing", "Mild diffuse abdominal tenderness without guarding or rebound", "No focal neurological deficit"],
  vitals: [
    { label: "Heart rate", value: "122", flag: "High" },
    { label: "Blood pressure", value: "100/64", flag: "Low-normal" },
    { label: "Respiratory rate", value: "28", flag: "High" },
    { label: "Temperature", value: "37.2", flag: "Normal" },
    { label: "Oxygen saturation", value: "99", flag: "Normal" }
  ],
  investigations: [
    { id: "vitals", name: "Vitals", category: "Bedside", relevance: "Immediate assessment of haemodynamic status, respiratory compensation and severity of illness.", result: "HR 122/min; BP 100/64 mmHg; RR 28/min, deep; Temp 37.2 °C; SpO₂ 99% on room air.", interpretation: "Tachycardia and low-normal blood pressure with dehydration suggest reduced intravascular volume. Deep tachypnoea may represent respiratory compensation for metabolic acidosis.", useful: true },
    { id: "glucose", name: "Capillary blood glucose", category: "Bedside", relevance: "Rapidly identifies hyperglycaemia in a symptomatic patient with diabetes.", result: "486", units: "mg/dL", reference: "Usually 70–140 mg/dL depending on timing and context", interpretation: "Marked hyperglycaemia. This supports a hyperglycaemic emergency but does not, by itself, distinguish ketoacidosis from other causes.", useful: true },
    { id: "ketones", name: "Serum beta-hydroxybutyrate", category: "Blood", relevance: "Preferred blood ketone measurement to establish and quantify ketonaemia.", result: "6.2", units: "mmol/L", reference: "Usually <0.6 mmol/L", interpretation: "Significant ketonaemia. In the context of diabetes and acidosis, this is a key diagnostic finding.", useful: true },
    { id: "abg", name: "Venous blood gas", category: "Blood", relevance: "Assesses acid–base status and severity; venous pH is generally adequate for DKA assessment in a stable patient.", result: "pH 7.12; HCO₃⁻ 8; pCO₂ 22", units: "pH; mmol/L; mmHg", reference: "pH 7.35–7.45; HCO₃⁻ 22–28 mmol/L", interpretation: "Acidaemia with low bicarbonate indicates metabolic acidosis. The reduced pCO₂ is consistent with respiratory compensation.", useful: true },
    { id: "electrolytes", name: "Serum electrolytes", category: "Blood", relevance: "Evaluates sodium and potassium abnormalities and allows calculation of the anion gap.", result: "Na⁺ 130; K⁺ 5.2; Cl⁻ 96; calculated anion gap 26", units: "mmol/L", reference: "Na⁺ 135–145; K⁺ 3.5–5.0; Cl⁻ 98–106; anion gap lab-dependent", interpretation: "Raised anion gap supports accumulation of unmeasured acids. Serum potassium is mildly elevated, but total-body potassium is typically depleted in DKA; insulin and fluids can rapidly lower serum potassium.", useful: true },
    { id: "renal", name: "Renal function", category: "Blood", relevance: "Assesses renal perfusion and helps guide fluid and electrolyte monitoring.", result: "Urea 28; creatinine 1.3", units: "mg/dL; mg/dL", reference: "Urea 7–20 mg/dL; creatinine varies by laboratory", interpretation: "Mild elevation may reflect dehydration and reduced renal perfusion. Trend after fluid resuscitation.", useful: true },
    { id: "cbc", name: "Complete blood count", category: "Blood", relevance: "May help identify infection or another precipitating stressor; interpret leukocytosis in clinical context.", result: "WBC 13,200; Hb 13.1; platelets 280,000", units: "/µL; g/dL; /µL", reference: "WBC approximately 4,000–11,000/µL", interpretation: "Mild leukocytosis can occur with physiological stress in DKA and does not independently prove infection.", useful: true },
    { id: "urine", name: "Urine examination", category: "Urine", relevance: "Can demonstrate glucosuria and ketonuria; may help assess urinary infection if suspected.", result: "Glucose 4+; ketones 3+; nitrite negative; leukocyte esterase negative", interpretation: "Glucosuria and ketonuria support the metabolic picture. No dipstick evidence of UTI is shown, though this does not fully exclude infection.", useful: true },
    { id: "ecg", name: "ECG", category: "Cardiac", relevance: "Consider when potassium disturbance, chest symptoms or cardiac risk is present.", result: "Sinus tachycardia; no acute ischaemic changes; no prominent peaked T waves.", interpretation: "Sinus tachycardia is consistent with physiological stress. ECG does not replace serial potassium measurement.", useful: true },
    { id: "cxr", name: "Chest X-ray", category: "Imaging", relevance: "Useful if respiratory symptoms, fever, hypoxia or suspected chest infection are present.", result: "No focal consolidation or pleural effusion.", interpretation: "No radiographic focus of chest infection is identified. In this presentation without respiratory infective symptoms, it is a low-yield routine test.", useful: false }
  ],
  diagnosisOptions: ["Diabetic ketoacidosis", "Hyperosmolar hyperglycaemic state", "Starvation ketosis", "Acute pancreatitis", "Lactic acidosis"],
  correctDiagnosis: "Diabetic ketoacidosis",
  mechanismOptions: [
    "Absolute/relative insulin deficiency with excess counter-regulatory hormones causing lipolysis, ketogenesis and high-anion-gap metabolic acidosis",
    "Excess insulin causing intracellular glucose uptake and severe hypoglycaemia",
    "Primary respiratory alkalosis due to hyperventilation",
    "Isolated renal bicarbonate loss causing normal-anion-gap metabolic acidosis"
  ],
  correctMechanism: "Absolute/relative insulin deficiency with excess counter-regulatory hormones causing lipolysis, ketogenesis and high-anion-gap metabolic acidosis",
  differentials: [
    { name: "Hyperosmolar hyperglycaemic state", whyNot: "Usually features more profound hyperglycaemia and hyperosmolality with absent or mild ketonaemia; this patient has marked ketonaemia and metabolic acidosis." },
    { name: "Starvation ketosis", whyNot: "Usually follows prolonged inadequate intake and generally causes less severe acidosis; the marked hyperglycaemia and known type 1 diabetes support DKA." },
    { name: "Acute pancreatitis", whyNot: "Can precipitate DKA, but no focal epigastric pain or lipase result is provided to establish pancreatitis." },
    { name: "Lactic acidosis", whyNot: "Can cause high-anion-gap acidosis, but the substantial beta-hydroxybutyrate elevation identifies ketonaemia as a major driver here." }
  ],
  managementOptions: [
    { id: "fluids", label: "Begin isotonic IV crystalloid resuscitation and reassess circulation", detail: "Initial priority for the clinically dehydrated patient, with fluid choice/rate individualized to age, cardiac/renal status and local protocol." },
    { id: "potassium", label: "Check potassium and renal function; monitor potassium closely before and during insulin", detail: "Serum potassium can fall rapidly with insulin and correction of acidosis. Replace only according to measured levels and protocol." },
    { id: "insulin", label: "Start protocolized IV regular insulin after initial assessment and ensuring potassium is safe", detail: "Insulin suppresses ketogenesis; do not start if potassium is dangerously low. Follow a validated institutional DKA protocol." },
    { id: "monitor", label: "Monitor glucose, electrolytes, ketones, venous pH, fluid balance and clinical status serially", detail: "Resolution is assessed by ketones/acidosis and clinical status, not glucose alone." },
    { id: "trigger", label: "Assess for precipitating cause and address missed insulin / intercurrent illness", detail: "Check for infection and other triggers based on history and examination; provide sick-day and insulin education after stabilization." },
    { id: "bicarb", label: "Give IV bicarbonate routinely to correct the acidosis", detail: "Routine bicarbonate is not recommended in typical DKA; consider only in exceptional severe acidemia according to specialist/local protocol." },
    { id: "potassium_now", label: "Give a large potassium bolus immediately because total-body potassium is depleted", detail: "Unsafe without measured level, renal function and ECG/monitoring context. Potassium replacement must be guided by serial results and protocol." }
  ],
  correctManagement: ["fluids", "potassium", "insulin", "monitor", "trigger"],
  explanation: "The combination of known diabetes, marked hyperglycaemia, significant ketonaemia and metabolic acidosis establishes DKA. The elevated anion gap and low bicarbonate indicate accumulation of ketoacids. Dehydration explains tachycardia, dry mucosa and low-normal blood pressure.",
  pathophysiology: "Insulin deficiency together with increased counter-regulatory hormones (glucagon, catecholamines, cortisol and growth hormone) increases hepatic gluconeogenesis and glycogenolysis while reducing peripheral glucose utilization. Hyperglycaemia causes osmotic diuresis and loss of water and electrolytes. Increased hormone-sensitive lipase activity releases free fatty acids, which the liver converts to ketone bodies (especially beta-hydroxybutyrate), producing high-anion-gap metabolic acidosis. Serum potassium may initially be normal or high because of insulin deficiency and acidosis-related shifts, despite substantial total-body potassium depletion from urinary losses.",
  learningObjectives: [
    "Recognize DKA using hyperglycaemia/diabetes, ketonaemia and metabolic acidosis together.",
    "Explain why serum potassium can be elevated despite total-body potassium depletion.",
    "Interpret a high-anion-gap metabolic acidosis with respiratory compensation.",
    "Prioritize fluid resuscitation, potassium assessment, protocolized insulin and serial monitoring.",
    "Identify missed insulin and intercurrent illness as common precipitating factors."
  ]
}, ...additionalCases, ...gitCases, ...renalCases, ...hematologyCases];