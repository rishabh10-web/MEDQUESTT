import type { Case } from "./data";
const records = [
  {
    "title": "Minimal change disease",
    "topic": "Nephrotic syndrome",
    "complaint": "child with periorbital edema, frothy urine and selective proteinuria",
    "hopi": "A patient presents with child with periorbital edema, frothy urine and selective proteinuria. The clinical pattern raises concern for Minimal change disease; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "podocyte foot-process effacement disrupts filtration-barrier selectivity",
    "test": "urine protein quantification and electron microscopy",
    "result": "nephrotic-range proteinuria with diffuse foot-process effacement",
    "management": "edema care, sodium restriction and glucocorticoids for typical steroid-sensitive disease",
    "difficulty": "Easy"
  },
  {
    "title": "Poststreptococcal glomerulonephritis",
    "topic": "Nephritic syndrome",
    "complaint": "child with cola-colored urine and edema 2 weeks after impetigo",
    "hopi": "A patient presents with child with cola-colored urine and edema 2 weeks after impetigo. The clinical pattern raises concern for Poststreptococcal glomerulonephritis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "immune-complex deposition activates complement in glomeruli",
    "test": "C3, ASO titre and urine microscopy",
    "result": "low C3, elevated ASO and RBC casts",
    "management": "supportive fluid/sodium restriction and blood-pressure control",
    "difficulty": "Easy"
  },
  {
    "title": "IgA nephropathy",
    "topic": "Glomerular disease",
    "complaint": "young adult with gross hematuria concurrent with an upper respiratory infection",
    "hopi": "A patient presents with young adult with gross hematuria concurrent with an upper respiratory infection. The clinical pattern raises concern for IgA nephropathy; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "mesangial IgA immune deposits trigger glomerular inflammation",
    "test": "urinalysis, complement and renal biopsy",
    "result": "normal complement with mesangial IgA-dominant deposits",
    "management": "control blood pressure and proteinuria; specialist risk-based treatment",
    "difficulty": "Medium"
  },
  {
    "title": "Alport syndrome",
    "topic": "Hereditary nephritis",
    "complaint": "adolescent with persistent hematuria, sensorineural hearing loss and family history",
    "hopi": "A patient presents with adolescent with persistent hematuria, sensorineural hearing loss and family history. The clinical pattern raises concern for Alport syndrome; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "type IV collagen defect affects glomerular, cochlear and ocular basement membranes",
    "test": "audiometry, genetic testing and renal evaluation",
    "result": "pathogenic COL4A5 variant with glomerular hematuria",
    "management": "renoprotection, hearing support and genetic counselling",
    "difficulty": "Medium"
  },
  {
    "title": "Anti-GBM disease",
    "topic": "Pulmonary-renal syndrome",
    "complaint": "young adult with hemoptysis, anemia, rapidly rising creatinine and RBC casts",
    "hopi": "A patient presents with young adult with hemoptysis, anemia, rapidly rising creatinine and RBC casts. The clinical pattern raises concern for Anti-GBM disease; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "antibodies target type IV collagen in glomerular and alveolar basement membranes",
    "test": "anti-GBM antibodies and renal biopsy",
    "result": "linear IgG staining with crescentic glomerulonephritis",
    "management": "urgent specialist plasma exchange and immunosuppression",
    "difficulty": "Expert"
  },
  {
    "title": "Granulomatosis with polyangiitis",
    "topic": "Vasculitic glomerulonephritis",
    "complaint": "adult with chronic sinusitis, epistaxis, pulmonary symptoms and hematuria",
    "hopi": "A patient presents with adult with chronic sinusitis, epistaxis, pulmonary symptoms and hematuria. The clinical pattern raises concern for Granulomatosis with polyangiitis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "PR3-associated necrotizing granulomatous vasculitis causes pauci-immune GN",
    "test": "PR3-ANCA and renal biopsy",
    "result": "pauci-immune necrotizing crescentic GN",
    "management": "urgent specialist induction immunosuppression",
    "difficulty": "Expert"
  },
  {
    "title": "Microscopic polyangiitis",
    "topic": "Vasculitic glomerulonephritis",
    "complaint": "adult with constitutional symptoms, pulmonary capillaritis and AKI",
    "hopi": "A patient presents with adult with constitutional symptoms, pulmonary capillaritis and AKI. The clinical pattern raises concern for Microscopic polyangiitis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "small-vessel necrotizing vasculitis causes pauci-immune crescentic GN",
    "test": "MPO-ANCA and renal biopsy",
    "result": "pauci-immune crescentic GN without granulomatous inflammation",
    "management": "urgent specialist immunosuppression for organ-threatening disease",
    "difficulty": "Expert"
  },
  {
    "title": "Eosinophilic granulomatosis with polyangiitis",
    "topic": "Systemic vasculitis",
    "complaint": "adult-onset asthma, eosinophilia, purpura and renal abnormalities",
    "hopi": "A patient presents with adult-onset asthma, eosinophilia, purpura and renal abnormalities. The clinical pattern raises concern for Eosinophilic granulomatosis with polyangiitis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "eosinophil-rich necrotizing vasculitis can involve renal vessels",
    "test": "CBC differential, ANCA and tissue biopsy",
    "result": "marked eosinophilia with compatible systemic vasculitis",
    "management": "glucocorticoids and specialist immunosuppression by severity",
    "difficulty": "Expert"
  },
  {
    "title": "Focal segmental glomerulosclerosis",
    "topic": "Nephrotic syndrome",
    "complaint": "adult with obesity, edema, hypoalbuminemia and heavy proteinuria",
    "hopi": "A patient presents with adult with obesity, edema, hypoalbuminemia and heavy proteinuria. The clinical pattern raises concern for Focal segmental glomerulosclerosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "podocyte injury produces segmental sclerosis in a subset of glomeruli",
    "test": "urine protein quantification and renal biopsy",
    "result": "focal segmental scarring with podocyte injury",
    "management": "treat cause and reduce proteinuria; specialist therapy for primary disease",
    "difficulty": "Hard"
  },
  {
    "title": "Membranous nephropathy",
    "topic": "Nephrotic syndrome",
    "complaint": "adult with edema, heavy proteinuria and increased thrombosis risk",
    "hopi": "A patient presents with adult with edema, heavy proteinuria and increased thrombosis risk. The clinical pattern raises concern for Membranous nephropathy; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "subepithelial immune deposits injure podocytes",
    "test": "anti-PLA2R testing and renal biopsy",
    "result": "capillary-wall thickening with subepithelial deposits",
    "management": "evaluate secondary causes and thrombosis; risk-based specialist therapy",
    "difficulty": "Hard"
  },
  {
    "title": "Membranoproliferative glomerulonephritis",
    "topic": "Glomerular pathology",
    "complaint": "adult with hematuria, proteinuria and low complement",
    "hopi": "A patient presents with adult with hematuria, proteinuria and low complement. The clinical pattern raises concern for Membranoproliferative glomerulonephritis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "immune-complex or complement dysregulation causes mesangial proliferation and capillary remodeling",
    "test": "complement studies and renal biopsy",
    "result": "double-contour GBM with mesangial expansion",
    "management": "treat underlying cause and provide renoprotection",
    "difficulty": "Hard"
  },
  {
    "title": "C3 glomerulopathy",
    "topic": "Complement-mediated disease",
    "complaint": "young person with persistent low C3 and recurrent hematuria",
    "hopi": "A patient presents with young person with persistent low C3 and recurrent hematuria. The clinical pattern raises concern for C3 glomerulopathy; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "alternative complement pathway dysregulation causes C3-dominant deposits",
    "test": "complement evaluation and biopsy",
    "result": "C3-dominant immunofluorescence",
    "management": "specialist nephrology care and individualized treatment",
    "difficulty": "Expert"
  },
  {
    "title": "Lupus nephritis",
    "topic": "Immune-mediated glomerular disease",
    "complaint": "young woman with SLE flare, edema, proteinuria and RBC casts",
    "hopi": "A patient presents with young woman with SLE flare, edema, proteinuria and RBC casts. The clinical pattern raises concern for Lupus nephritis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "immune-complex deposition activates complement in glomeruli",
    "test": "C3/C4, anti-dsDNA and renal biopsy",
    "result": "low complement and classifiable lupus nephritis on biopsy",
    "management": "class-directed rheumatology/nephrology immunosuppression",
    "difficulty": "Hard"
  },
  {
    "title": "IgA vasculitis nephritis",
    "topic": "Systemic immune disease",
    "complaint": "child with palpable purpura, abdominal pain, arthralgia and hematuria",
    "hopi": "A patient presents with child with palpable purpura, abdominal pain, arthralgia and hematuria. The clinical pattern raises concern for IgA vasculitis nephritis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "IgA immune complexes affect small vessels and glomerular mesangium",
    "test": "urinalysis, renal function and blood pressure",
    "result": "hematuria/proteinuria with compatible purpura",
    "management": "monitor renal involvement; specialist therapy if severe",
    "difficulty": "Medium"
  },
  {
    "title": "Infection-related glomerulonephritis",
    "topic": "Infection-associated GN",
    "complaint": "older diabetic with active skin infection, edema and AKI",
    "hopi": "A patient presents with older diabetic with active skin infection, edema and AKI. The clinical pattern raises concern for Infection-related glomerulonephritis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "infection-associated immune complexes activate complement",
    "test": "cultures, complement and renal biopsy",
    "result": "nephritic sediment with low complement",
    "management": "treat infection and manage volume and blood pressure",
    "difficulty": "Hard"
  },
  {
    "title": "Diabetic kidney disease",
    "topic": "Chronic kidney disease",
    "complaint": "longstanding diabetes with retinopathy and progressive albuminuria",
    "hopi": "A patient presents with longstanding diabetes with retinopathy and progressive albuminuria. The clinical pattern raises concern for Diabetic kidney disease; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "hyperglycemia causes glomerular hyperfiltration, GBM thickening and mesangial expansion",
    "test": "urine albumin-creatinine ratio and eGFR",
    "result": "persistent albuminuria with declining eGFR",
    "management": "glycemic/BP control and indicated ACEi/ARB or SGLT2 inhibitor",
    "difficulty": "Easy"
  },
  {
    "title": "Kimmelstiel-Wilson nodules",
    "topic": "Diabetic glomerulosclerosis",
    "complaint": "diabetic patient with nephrotic proteinuria and nodular biopsy lesions",
    "hopi": "A patient presents with diabetic patient with nephrotic proteinuria and nodular biopsy lesions. The clinical pattern raises concern for Kimmelstiel-Wilson nodules; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "advanced diabetic glomerulosclerosis produces nodular mesangial expansion",
    "test": "renal biopsy with PAS stain",
    "result": "PAS-positive nodular mesangial sclerosis",
    "management": "risk-factor control and renoprotective treatment",
    "difficulty": "Hard"
  },
  {
    "title": "Hypertensive nephrosclerosis",
    "topic": "Chronic kidney disease",
    "complaint": "older adult with decades of hypertension and slowly declining eGFR",
    "hopi": "A patient presents with older adult with decades of hypertension and slowly declining eGFR. The clinical pattern raises concern for Hypertensive nephrosclerosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "arteriolar hyalinosis and intimal thickening cause chronic ischemic nephron injury",
    "test": "BP trend, urine albumin and renal ultrasound",
    "result": "small echogenic kidneys with bland sediment",
    "management": "BP and cardiovascular risk control; avoid nephrotoxins",
    "difficulty": "Medium"
  },
  {
    "title": "Amyloidosis of kidney",
    "topic": "Nephrotic syndrome",
    "complaint": "patient with chronic inflammatory disease and heavy proteinuria",
    "hopi": "A patient presents with patient with chronic inflammatory disease and heavy proteinuria. The clinical pattern raises concern for Amyloidosis of kidney; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "amyloid fibrils deposit in glomeruli and vessels",
    "test": "Congo red staining and amyloid typing",
    "result": "apple-green birefringence in Congo-red-positive deposits",
    "management": "treat underlying plasma-cell or inflammatory disease",
    "difficulty": "Hard"
  },
  {
    "title": "HIV-associated nephropathy",
    "topic": "Secondary glomerular disease",
    "complaint": "untreated HIV with heavy proteinuria and rapidly declining renal function",
    "hopi": "A patient presents with untreated HIV with heavy proteinuria and rapidly declining renal function. The clinical pattern raises concern for HIV-associated nephropathy; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "HIV-associated podocyte injury causes collapsing glomerulopathy",
    "test": "HIV viral load and renal biopsy",
    "result": "collapsing FSGS pattern with tubular microcysts",
    "management": "antiretroviral therapy and renoprotective care",
    "difficulty": "Hard"
  },
  {
    "title": "Anti-PLA2R primary membranous nephropathy",
    "topic": "Glomerular immunology",
    "complaint": "adult with nephrotic syndrome and positive anti-PLA2R antibody",
    "hopi": "A patient presents with adult with nephrotic syndrome and positive anti-PLA2R antibody. The clinical pattern raises concern for Anti-PLA2R primary membranous nephropathy; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "autoantibodies target podocyte PLA2R, producing subepithelial immune deposits",
    "test": "serum anti-PLA2R and renal biopsy",
    "result": "positive anti-PLA2R with membranous pattern",
    "management": "risk-based supportive and specialist immunotherapy",
    "difficulty": "Expert"
  },
  {
    "title": "Thin basement membrane nephropathy",
    "topic": "Hereditary hematuria",
    "complaint": "young adult with lifelong isolated microscopic hematuria and normal renal function",
    "hopi": "A patient presents with young adult with lifelong isolated microscopic hematuria and normal renal function. The clinical pattern raises concern for Thin basement membrane nephropathy; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "thin GBM permits red-cell leakage without typical progressive inflammation",
    "test": "family history, urinalysis and genetic evaluation",
    "result": "isolated hematuria with thin GBM on EM if biopsied",
    "management": "reassurance and periodic renal monitoring",
    "difficulty": "Medium"
  },
  {
    "title": "Acute tubular necrosis",
    "topic": "Acute kidney injury",
    "complaint": "oliguria after prolonged hypotension with muddy-brown casts",
    "hopi": "A patient presents with oliguria after prolonged hypotension with muddy-brown casts. The clinical pattern raises concern for Acute tubular necrosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "ischemic tubular epithelial injury causes cell sloughing and intratubular casts",
    "test": "urine microscopy and serial creatinine",
    "result": "muddy-brown granular casts and impaired concentrating ability",
    "management": "treat shock, optimize perfusion and manage fluid/electrolyte complications",
    "difficulty": "Hard"
  },
  {
    "title": "Prerenal azotemia",
    "topic": "Acute kidney injury",
    "complaint": "vomiting, orthostasis, dry mucosa and oliguria",
    "hopi": "A patient presents with vomiting, orthostasis, dry mucosa and oliguria. The clinical pattern raises concern for Prerenal azotemia; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "reduced circulating volume lowers renal perfusion while tubules conserve sodium",
    "test": "volume assessment, urine sodium and BUN/creatinine",
    "result": "concentrated urine and low fractional sodium excretion in context",
    "management": "restore appropriate volume and treat fluid losses",
    "difficulty": "Easy"
  },
  {
    "title": "Postrenal AKI from bladder outlet obstruction",
    "topic": "Obstructive uropathy",
    "complaint": "older man with hesitancy, suprapubic discomfort and anuria",
    "hopi": "A patient presents with older man with hesitancy, suprapubic discomfort and anuria. The clinical pattern raises concern for Postrenal AKI from bladder outlet obstruction; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "outflow obstruction raises tubular hydrostatic pressure and reduces filtration",
    "test": "bladder scan and renal ultrasound",
    "result": "large postvoid residual and bilateral hydronephrosis",
    "management": "promptly relieve obstruction and monitor post-obstructive diuresis",
    "difficulty": "Easy"
  },
  {
    "title": "Drug-induced acute interstitial nephritis",
    "topic": "Tubulointerstitial disease",
    "complaint": "fever, rash, sterile pyuria and AKI after a new medication",
    "hopi": "A patient presents with fever, rash, sterile pyuria and AKI after a new medication. The clinical pattern raises concern for Drug-induced acute interstitial nephritis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "drug hypersensitivity causes interstitial inflammation and edema",
    "test": "drug timeline, urine microscopy and biopsy if uncertain",
    "result": "sterile pyuria and WBC casts; interstitial infiltrate on biopsy",
    "management": "stop culprit drug and consider specialist-directed corticosteroids",
    "difficulty": "Medium"
  },
  {
    "title": "Aminoglycoside nephrotoxicity",
    "topic": "Drug-induced AKI",
    "complaint": "nonoliguric AKI after several days of gentamicin",
    "hopi": "A patient presents with nonoliguric AKI after several days of gentamicin. The clinical pattern raises concern for Aminoglycoside nephrotoxicity; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "aminoglycoside accumulation injures proximal tubular epithelium",
    "test": "drug exposure review, urine microscopy and serial creatinine",
    "result": "granular casts and rising creatinine",
    "management": "stop/adjust nephrotoxin and monitor renal recovery",
    "difficulty": "Medium"
  },
  {
    "title": "NSAID hemodynamic AKI",
    "topic": "Renal pharmacology",
    "complaint": "dehydrated patient with CKD develops AKI after ibuprofen",
    "hopi": "A patient presents with dehydrated patient with CKD develops AKI after ibuprofen. The clinical pattern raises concern for NSAID hemodynamic AKI; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "COX inhibition reduces prostaglandin-mediated afferent arteriolar dilation",
    "test": "medication review, renal function and volume assessment",
    "result": "AKI after NSAID exposure with compatible perfusion context",
    "management": "stop NSAID, restore perfusion and reassess renal function",
    "difficulty": "Medium"
  },
  {
    "title": "Contrast-associated AKI",
    "topic": "Renal pharmacology",
    "complaint": "patient with diabetes and CKD has creatinine rise after angiography",
    "hopi": "A patient presents with patient with diabetes and CKD has creatinine rise after angiography. The clinical pattern raises concern for Contrast-associated AKI; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "contrast exposure may cause renal hemodynamic and tubular stress in susceptible patients",
    "test": "baseline/serial creatinine and volume assessment",
    "result": "temporal creatinine rise; assess other causes",
    "management": "use contrast only when indicated, minimize dose and optimize volume status",
    "difficulty": "Hard"
  },
  {
    "title": "Rhabdomyolysis-associated AKI",
    "topic": "Pigment nephropathy",
    "complaint": "crush injury with muscle pain, dark urine and high CK",
    "hopi": "A patient presents with crush injury with muscle pain, dark urine and high CK. The clinical pattern raises concern for Rhabdomyolysis-associated AKI; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "myoglobin causes oxidative tubular injury and casts",
    "test": "CK, urine dipstick/microscopy and electrolytes",
    "result": "heme-positive urine with few RBCs and markedly elevated CK",
    "management": "early tailored fluids and monitor potassium and renal function",
    "difficulty": "Hard"
  },
  {
    "title": "Acute pyelonephritis",
    "topic": "Urinary infection",
    "complaint": "fever, dysuria, flank pain and costovertebral-angle tenderness",
    "hopi": "A patient presents with fever, dysuria, flank pain and costovertebral-angle tenderness. The clinical pattern raises concern for Acute pyelonephritis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "ascending bacteria infect renal pelvis and parenchyma",
    "test": "urinalysis and urine culture",
    "result": "pyuria, bacteriuria and positive culture",
    "management": "culture-guided antibiotics and assess sepsis/obstruction",
    "difficulty": "Easy"
  },
  {
    "title": "Proteus-associated struvite stone",
    "topic": "Infection-related nephrolithiasis",
    "complaint": "recurrent alkaline urine infections and staghorn calculus",
    "hopi": "A patient presents with recurrent alkaline urine infections and staghorn calculus. The clinical pattern raises concern for Proteus-associated struvite stone; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "urease raises urine pH and promotes magnesium ammonium phosphate precipitation",
    "test": "urine culture, pH and noncontrast CT",
    "result": "branching staghorn calculus with urease-producing organism",
    "management": "culture-guided antibiotics and complete stone clearance",
    "difficulty": "Hard"
  },
  {
    "title": "Uric acid nephrolithiasis",
    "topic": "Stone disease",
    "complaint": "gout with renal colic and acidic urine",
    "hopi": "A patient presents with gout with renal colic and acidic urine. The clinical pattern raises concern for Uric acid nephrolithiasis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "low urine pH promotes poorly soluble uric acid crystallization",
    "test": "urine pH, stone analysis and noncontrast CT",
    "result": "stone visible on CT but often radiolucent on plain film",
    "management": "urine alkalinization and high fluid intake; urate-lowering when indicated",
    "difficulty": "Medium"
  },
  {
    "title": "Calcium oxalate nephrolithiasis",
    "topic": "Stone disease",
    "complaint": "recurrent colicky flank pain and calcium oxalate stone analysis",
    "hopi": "A patient presents with recurrent colicky flank pain and calcium oxalate stone analysis. The clinical pattern raises concern for Calcium oxalate nephrolithiasis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "urinary supersaturation drives calcium oxalate crystallization",
    "test": "stone analysis and 24-hour urine profile",
    "result": "calcium oxalate stone with low urine volume/hyperoxaluria",
    "management": "increase fluids, maintain normal dietary calcium and address metabolic risks",
    "difficulty": "Medium"
  },
  {
    "title": "Primary hyperparathyroidism with stones",
    "topic": "Calcium homeostasis",
    "complaint": "recurrent calcium stones, constipation and elevated calcium/PTH",
    "hopi": "A patient presents with recurrent calcium stones, constipation and elevated calcium/PTH. The clinical pattern raises concern for Primary hyperparathyroidism with stones; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "PTH increases bone resorption and renal calcium reabsorption while causing phosphaturia",
    "test": "serum calcium, phosphate and PTH",
    "result": "hypercalcemia with inappropriately elevated PTH",
    "management": "evaluate parathyroidectomy criteria and manage stone risk",
    "difficulty": "Hard"
  },
  {
    "title": "Cystinuria",
    "topic": "Inherited stone disease",
    "complaint": "young adult with recurrent stones and hexagonal urine crystals",
    "hopi": "A patient presents with young adult with recurrent stones and hexagonal urine crystals. The clinical pattern raises concern for Cystinuria; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "defective dibasic amino acid transport reduces cystine reabsorption",
    "test": "urine microscopy, stone analysis and urine cystine",
    "result": "hexagonal crystals and elevated urinary cystine",
    "management": "high fluids, urine alkalinization and thiol-binding therapy when needed",
    "difficulty": "Hard"
  },
  {
    "title": "Primary hyperoxaluria",
    "topic": "Inherited stone disease",
    "complaint": "child with recurrent bilateral calcium oxalate stones and nephrocalcinosis",
    "hopi": "A patient presents with child with recurrent bilateral calcium oxalate stones and nephrocalcinosis. The clinical pattern raises concern for Primary hyperoxaluria; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "hepatic glyoxylate pathway defect increases oxalate production",
    "test": "urine/plasma oxalate and genetic testing",
    "result": "marked hyperoxaluria with calcium oxalate deposition",
    "management": "specialist metabolic and renal management",
    "difficulty": "Expert"
  },
  {
    "title": "Medullary sponge kidney",
    "topic": "Congenital renal disorder",
    "complaint": "recurrent stones and medullary nephrocalcinosis",
    "hopi": "A patient presents with recurrent stones and medullary nephrocalcinosis. The clinical pattern raises concern for Medullary sponge kidney; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "ectatic terminal collecting ducts cause urinary stasis",
    "test": "CT urography and metabolic stone workup",
    "result": "paintbrush-like papillary contrast striations",
    "management": "hydration and stone prevention",
    "difficulty": "Hard"
  },
  {
    "title": "Autosomal dominant polycystic kidney disease",
    "topic": "Cystic kidney disease",
    "complaint": "adult with hypertension, flank fullness and family history of dialysis",
    "hopi": "A patient presents with adult with hypertension, flank fullness and family history of dialysis. The clinical pattern raises concern for Autosomal dominant polycystic kidney disease; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "PKD1/PKD2 polycystin defects cause progressive bilateral renal cysts",
    "test": "renal ultrasound and family/genetic assessment",
    "result": "enlarged kidneys with multiple bilateral cysts",
    "management": "BP control, complication surveillance and selected disease-modifying therapy",
    "difficulty": "Medium"
  },
  {
    "title": "Autosomal recessive polycystic kidney disease",
    "topic": "Cystic kidney disease",
    "complaint": "neonate with enlarged echogenic kidneys and respiratory distress",
    "hopi": "A patient presents with neonate with enlarged echogenic kidneys and respiratory distress. The clinical pattern raises concern for Autosomal recessive polycystic kidney disease; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "PKHD1-related collecting duct dilation associates with congenital hepatic fibrosis",
    "test": "prenatal/neonatal ultrasound and liver assessment",
    "result": "bilateral enlarged echogenic kidneys",
    "management": "support respiratory/renal function and manage portal-hypertension complications",
    "difficulty": "Hard"
  },
  {
    "title": "Horseshoe kidney",
    "topic": "Renal embryology",
    "complaint": "incidental fused lower renal poles and low renal position",
    "hopi": "A patient presents with incidental fused lower renal poles and low renal position. The clinical pattern raises concern for Horseshoe kidney; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "inferior poles fuse and become trapped beneath inferior mesenteric artery during ascent",
    "test": "renal ultrasound or CT anatomy when indicated",
    "result": "fused lower poles crossing midline",
    "management": "no treatment if uncomplicated; manage stones or obstruction",
    "difficulty": "Medium"
  },
  {
    "title": "Unilateral renal agenesis",
    "topic": "Renal embryology",
    "complaint": "incidental solitary kidney with compensatory hypertrophy",
    "hopi": "A patient presents with incidental solitary kidney with compensatory hypertrophy. The clinical pattern raises concern for Unilateral renal agenesis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "failure of ureteric bud development prevents induction of metanephric mesenchyme",
    "test": "renal ultrasound and contralateral urinary tract assessment",
    "result": "one absent kidney and compensatory contralateral enlargement",
    "management": "monitor BP, albuminuria and renal function",
    "difficulty": "Medium"
  },
  {
    "title": "Bilateral renal agenesis and Potter sequence",
    "topic": "Renal embryology",
    "complaint": "newborn with oligohydramnios, pulmonary hypoplasia and limb deformities",
    "hopi": "A patient presents with newborn with oligohydramnios, pulmonary hypoplasia and limb deformities. The clinical pattern raises concern for Bilateral renal agenesis and Potter sequence; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "absence of fetal renal urine causes oligohydramnios and fetal compression",
    "test": "prenatal ultrasound",
    "result": "absent bilateral renal tissue and severe oligohydramnios",
    "management": "neonatal supportive care and counselling; very poor prognosis with severe pulmonary hypoplasia",
    "difficulty": "Expert"
  },
  {
    "title": "Posterior urethral valves",
    "topic": "Congenital obstruction",
    "complaint": "male infant with poor stream and antenatal bilateral hydronephrosis",
    "hopi": "A patient presents with male infant with poor stream and antenatal bilateral hydronephrosis. The clinical pattern raises concern for Posterior urethral valves; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "persistent posterior urethral membrane causes bladder outlet obstruction",
    "test": "renal/bladder ultrasound and VCUG",
    "result": "thick bladder and bilateral hydroureteronephrosis; posterior urethral dilation",
    "management": "bladder drainage and endoscopic valve ablation",
    "difficulty": "Hard"
  },
  {
    "title": "Vesicoureteral reflux",
    "topic": "Pediatric urinary disease",
    "complaint": "child with recurrent febrile UTIs and cortical scars",
    "hopi": "A patient presents with child with recurrent febrile UTIs and cortical scars. The clinical pattern raises concern for Vesicoureteral reflux; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "incompetent ureterovesical junction permits retrograde urine flow",
    "test": "urine culture and selected VCUG",
    "result": "reflux into ureter and renal pelvis",
    "management": "culture-guided infection treatment and urology follow-up",
    "difficulty": "Medium"
  },
  {
    "title": "Ureteropelvic junction obstruction",
    "topic": "Congenital obstruction",
    "complaint": "antenatal hydronephrosis with dilated renal pelvis but normal ureter",
    "hopi": "A patient presents with antenatal hydronephrosis with dilated renal pelvis but normal ureter. The clinical pattern raises concern for Ureteropelvic junction obstruction; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "narrowing at UPJ impairs drainage from renal pelvis",
    "test": "renal ultrasound and diuretic renography",
    "result": "pelvicalyceal dilation without ureteral dilation",
    "management": "observe mild cases; pyeloplasty for impaired drainage/function",
    "difficulty": "Medium"
  },
  {
    "title": "Multicystic dysplastic kidney",
    "topic": "Renal embryology",
    "complaint": "prenatal unilateral kidney replaced by noncommunicating cysts",
    "hopi": "A patient presents with prenatal unilateral kidney replaced by noncommunicating cysts. The clinical pattern raises concern for Multicystic dysplastic kidney; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "abnormal ureteric bud-metanephric mesenchyme interaction produces nonfunctional dysplastic tissue",
    "test": "prenatal and postnatal ultrasound",
    "result": "multiple noncommunicating cysts with little normal parenchyma",
    "management": "serial observation for many unilateral cases and evaluate associated anomalies",
    "difficulty": "Medium"
  },
  {
    "title": "Duplicated collecting system",
    "topic": "Renal embryology",
    "complaint": "child with recurrent UTIs and duplicated ureter",
    "hopi": "A patient presents with child with recurrent UTIs and duplicated ureter. The clinical pattern raises concern for Duplicated collecting system; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "early ureteric bud bifurcation or duplicated buds form double collecting system",
    "test": "renal ultrasound and selected VCUG",
    "result": "duplicated pelvis/ureter with possible reflux or obstruction",
    "management": "treat infection and manage reflux/obstruction by anatomy",
    "difficulty": "Medium"
  },
  {
    "title": "Central diabetes insipidus",
    "topic": "Water balance",
    "complaint": "polyuria and hypernatremia after pituitary surgery",
    "hopi": "A patient presents with polyuria and hypernatremia after pituitary surgery. The clinical pattern raises concern for Central diabetes insipidus; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "vasopressin deficiency prevents collecting-duct water reabsorption",
    "test": "serum/urine osmolality and desmopressin response",
    "result": "dilute urine concentrates substantially after desmopressin",
    "management": "careful free-water replacement and desmopressin with sodium monitoring",
    "difficulty": "Medium"
  },
  {
    "title": "Nephrogenic diabetes insipidus",
    "topic": "Water balance",
    "complaint": "patient on lithium with polydipsia and dilute urine",
    "hopi": "A patient presents with patient on lithium with polydipsia and dilute urine. The clinical pattern raises concern for Nephrogenic diabetes insipidus; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "collecting duct resistance to vasopressin impairs aquaporin-2 insertion",
    "test": "serum/urine osmolality and desmopressin response",
    "result": "urine remains dilute after desmopressin",
    "management": "review lithium, ensure water access and consider amiloride/thiazide",
    "difficulty": "Hard"
  },
  {
    "title": "SIADH",
    "topic": "Sodium-water balance",
    "complaint": "euvolemic hyponatremia with concentrated urine in smoker",
    "hopi": "A patient presents with euvolemic hyponatremia with concentrated urine in smoker. The clinical pattern raises concern for SIADH; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "excess ADH increases collecting-duct water reabsorption and dilutes serum sodium",
    "test": "serum/urine osmolality, urine sodium and endocrine exclusion",
    "result": "low serum osmolality with inappropriately concentrated urine",
    "management": "fluid restriction for stable cases; monitored hypertonic saline for severe symptoms",
    "difficulty": "Medium"
  },
  {
    "title": "Exercise-associated hyponatremia",
    "topic": "Sodium-water balance",
    "complaint": "confusion after endurance event with excessive hypotonic fluid intake",
    "hopi": "A patient presents with confusion after endurance event with excessive hypotonic fluid intake. The clinical pattern raises concern for Exercise-associated hyponatremia; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "water excess plus non-osmotic ADH secretion causes acute hypotonic hyponatremia",
    "test": "serum sodium and osmolality",
    "result": "acute hypotonic hyponatremia",
    "management": "monitored hypertonic saline for severe neurologic symptoms; avoid rapid correction",
    "difficulty": "Hard"
  },
  {
    "title": "Severe hyperkalemia",
    "topic": "Electrolyte emergency",
    "complaint": "weakness, AKI and peaked T waves with QRS widening",
    "hopi": "A patient presents with weakness, AKI and peaked T waves with QRS widening. The clinical pattern raises concern for Severe hyperkalemia; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "reduced renal potassium excretion depolarizes cardiac cell membranes",
    "test": "ECG and repeat nonhemolyzed serum potassium",
    "result": "marked hyperkalemia with ECG toxicity",
    "management": "IV calcium for ECG toxicity, shift potassium intracellularly and remove potassium; dialysis if refractory",
    "difficulty": "Hard"
  },
  {
    "title": "Hypokalemic metabolic alkalosis",
    "topic": "Electrolyte disorder",
    "complaint": "weakness and cramps while taking loop diuretic",
    "hopi": "A patient presents with weakness and cramps while taking loop diuretic. The clinical pattern raises concern for Hypokalemic metabolic alkalosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "increased distal sodium delivery and aldosterone promote potassium and hydrogen loss",
    "test": "serum electrolytes, magnesium and urine chloride",
    "result": "low potassium with elevated bicarbonate",
    "management": "replace potassium/magnesium and reassess diuretic and volume status",
    "difficulty": "Medium"
  },
  {
    "title": "Type 1 distal renal tubular acidosis",
    "topic": "Renal tubular acidosis",
    "complaint": "calcium phosphate stones with hypokalemic normal-gap acidosis",
    "hopi": "A patient presents with calcium phosphate stones with hypokalemic normal-gap acidosis. The clinical pattern raises concern for Type 1 distal renal tubular acidosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "distal nephron cannot secrete hydrogen adequately",
    "test": "serum bicarbonate, urine pH and urine anion gap",
    "result": "urine pH remains above 5.5 during systemic acidosis",
    "management": "alkali and potassium replacement; investigate autoimmune causes",
    "difficulty": "Hard"
  },
  {
    "title": "Type 2 proximal renal tubular acidosis",
    "topic": "Renal tubular acidosis",
    "complaint": "proximal bicarbonate wasting with normal-gap acidosis",
    "hopi": "A patient presents with proximal bicarbonate wasting with normal-gap acidosis. The clinical pattern raises concern for Type 2 proximal renal tubular acidosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "reduced proximal bicarbonate reabsorption causes bicarbonaturia",
    "test": "serum bicarbonate, urine pH and fractional bicarbonate excretion",
    "result": "bicarbonate wasting with urine pH pattern dependent on serum bicarbonate",
    "management": "replace alkali and evaluate for Fanconi syndrome or drug causes",
    "difficulty": "Hard"
  },
  {
    "title": "Type 4 renal tubular acidosis",
    "topic": "Renal tubular acidosis",
    "complaint": "diabetic CKD with hyperkalemic normal-gap acidosis",
    "hopi": "A patient presents with diabetic CKD with hyperkalemic normal-gap acidosis. The clinical pattern raises concern for Type 4 renal tubular acidosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "hypoaldosteronism or aldosterone resistance reduces distal potassium and hydrogen secretion",
    "test": "serum electrolytes, renin/aldosterone and medication review",
    "result": "hyperkalemic hyperchloremic metabolic acidosis",
    "management": "review medications, manage potassium and treat cause",
    "difficulty": "Hard"
  },
  {
    "title": "Fanconi syndrome",
    "topic": "Proximal tubular disease",
    "complaint": "child with growth failure, rickets and normoglycemic glucosuria",
    "hopi": "A patient presents with child with growth failure, rickets and normoglycemic glucosuria. The clinical pattern raises concern for Fanconi syndrome; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "generalized proximal tubular dysfunction causes phosphate, glucose, bicarbonate and amino acid wasting",
    "test": "urinalysis and serum/urine solute assessment",
    "result": "normoglycemic glucosuria, phosphaturia and aminoaciduria",
    "management": "treat cause and replace phosphate/bicarbonate and other losses",
    "difficulty": "Hard"
  },
  {
    "title": "Bartter syndrome",
    "topic": "Inherited tubular disorder",
    "complaint": "child with growth delay, polyuria and hypokalemic alkalosis",
    "hopi": "A patient presents with child with growth delay, polyuria and hypokalemic alkalosis. The clinical pattern raises concern for Bartter syndrome; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "thick ascending limb transport defect mimics loop diuretic action",
    "test": "electrolytes, urine calcium and renin/aldosterone",
    "result": "hypokalemic alkalosis with high renin/aldosterone and often hypercalciuria",
    "management": "salt and potassium supplementation with specialist care",
    "difficulty": "Hard"
  },
  {
    "title": "Gitelman syndrome",
    "topic": "Inherited tubular disorder",
    "complaint": "adult with cramps, hypokalemia and hypomagnesemia",
    "hopi": "A patient presents with adult with cramps, hypokalemia and hypomagnesemia. The clinical pattern raises concern for Gitelman syndrome; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "NCC loss in distal convoluted tubule mimics thiazide exposure",
    "test": "electrolytes, urine calcium and genetic testing",
    "result": "hypokalemic alkalosis, hypomagnesemia and hypocalciuria",
    "management": "potassium/magnesium replacement and selected potassium-sparing therapy",
    "difficulty": "Hard"
  },
  {
    "title": "Liddle syndrome",
    "topic": "Inherited tubular disorder",
    "complaint": "young adult with severe hypertension and low renin/aldosterone",
    "hopi": "A patient presents with young adult with severe hypertension and low renin/aldosterone. The clinical pattern raises concern for Liddle syndrome; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "gain-of-function ENaC increases sodium reabsorption and potassium loss",
    "test": "renin, aldosterone and genetic testing",
    "result": "suppressed renin and aldosterone with hypokalemic alkalosis",
    "management": "amiloride or triamterene and sodium restriction",
    "difficulty": "Expert"
  },
  {
    "title": "Primary hyperaldosteronism",
    "topic": "Renal endocrine physiology",
    "complaint": "resistant hypertension, hypokalemia and alkalosis",
    "hopi": "A patient presents with resistant hypertension, hypokalemia and alkalosis. The clinical pattern raises concern for Primary hyperaldosteronism; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "autonomous aldosterone increases distal sodium uptake and potassium/hydrogen secretion",
    "test": "aldosterone-renin ratio and confirmatory testing",
    "result": "suppressed renin with inappropriately high aldosterone",
    "management": "mineralocorticoid antagonist or surgery for unilateral disease after workup",
    "difficulty": "Hard"
  },
  {
    "title": "Renal artery stenosis",
    "topic": "Renal vascular disease",
    "complaint": "resistant hypertension, abdominal bruit and flash pulmonary edema",
    "hopi": "A patient presents with resistant hypertension, abdominal bruit and flash pulmonary edema. The clinical pattern raises concern for Renal artery stenosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "reduced renal perfusion activates renin-angiotensin-aldosterone system",
    "test": "renal artery duplex or CT/MR angiography",
    "result": "hemodynamically significant renal artery narrowing",
    "management": "medical risk reduction; revascularization for selected high-risk presentations",
    "difficulty": "Hard"
  },
  {
    "title": "Bilateral renal artery stenosis with ACE inhibitor",
    "topic": "Renal hemodynamics",
    "complaint": "marked creatinine rise after ACE inhibitor in atherosclerotic patient",
    "hopi": "A patient presents with marked creatinine rise after ACE inhibitor in atherosclerotic patient. The clinical pattern raises concern for Bilateral renal artery stenosis with ACE inhibitor; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "efferent dilation reduces intraglomerular pressure when GFR depends on angiotensin II",
    "test": "medication review, serial creatinine and renovascular imaging",
    "result": "substantial creatinine increase after ACE inhibition",
    "management": "hold drug while evaluating volume and renovascular disease",
    "difficulty": "Expert"
  },
  {
    "title": "Scleroderma renal crisis",
    "topic": "Renal vascular emergency",
    "complaint": "systemic sclerosis with abrupt severe hypertension and AKI",
    "hopi": "A patient presents with systemic sclerosis with abrupt severe hypertension and AKI. The clinical pattern raises concern for Scleroderma renal crisis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "renal arteriolar injury triggers ischemia and renin-mediated malignant hypertension",
    "test": "BP, renal profile, urinalysis and hemolysis evaluation",
    "result": "new severe hypertension with AKI and possible microangiopathic hemolysis",
    "management": "prompt ACE inhibitor under specialist monitoring and emergency BP management",
    "difficulty": "Expert"
  },
  {
    "title": "Atheroembolic renal disease",
    "topic": "Renal vascular disease",
    "complaint": "subacute AKI, livedo and blue toes after angiography",
    "hopi": "A patient presents with subacute AKI, livedo and blue toes after angiography. The clinical pattern raises concern for Atheroembolic renal disease; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "cholesterol crystals lodge in small renal arteries and provoke inflammation",
    "test": "renal function, eosinophils, complement and biopsy",
    "result": "cholesterol clefts in arterioles when biopsied",
    "management": "supportive renal care and aggressive atherosclerotic risk reduction",
    "difficulty": "Expert"
  },
  {
    "title": "Renal vein thrombosis",
    "topic": "Renal vascular disease",
    "complaint": "nephrotic syndrome with sudden flank pain and hematuria",
    "hopi": "A patient presents with nephrotic syndrome with sudden flank pain and hematuria. The clinical pattern raises concern for Renal vein thrombosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "loss of anticoagulant proteins and increased procoagulants cause hypercoagulability",
    "test": "Doppler or CT/MR venography",
    "result": "renal vein filling defect",
    "management": "anticoagulation when appropriate and treat nephrotic cause",
    "difficulty": "Hard"
  },
  {
    "title": "Clear cell renal cell carcinoma",
    "topic": "Renal neoplasia",
    "complaint": "smoker with painless hematuria, weight loss and enhancing renal mass",
    "hopi": "A patient presents with smoker with painless hematuria, weight loss and enhancing renal mass. The clinical pattern raises concern for Clear cell renal cell carcinoma; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "VHL pathway disruption and HIF accumulation promote angiogenesis and tumor growth",
    "test": "contrast-enhanced renal mass imaging and histopathology",
    "result": "enhancing cortical mass with clear cells and delicate vasculature",
    "management": "stage and refer to urologic oncology",
    "difficulty": "Hard"
  },
  {
    "title": "Wilms tumor",
    "topic": "Pediatric renal neoplasia",
    "complaint": "young child with painless abdominal mass and hypertension",
    "hopi": "A patient presents with young child with painless abdominal mass and hypertension. The clinical pattern raises concern for Wilms tumor; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "embryonic nephrogenic tissue gives rise to pediatric renal tumor",
    "test": "abdominal ultrasound and staging imaging",
    "result": "intrarenal mass with triphasic histology",
    "management": "pediatric oncology/urology stage-directed management",
    "difficulty": "Medium"
  },
  {
    "title": "Urothelial carcinoma of renal pelvis",
    "topic": "Urinary tract neoplasia",
    "complaint": "older smoker with painless hematuria and renal pelvic filling defect",
    "hopi": "A patient presents with older smoker with painless hematuria and renal pelvic filling defect. The clinical pattern raises concern for Urothelial carcinoma of renal pelvis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "urothelial carcinogens cause malignant transformation of collecting-system epithelium",
    "test": "CT urography, urine cytology and ureteroscopic biopsy",
    "result": "renal pelvic filling defect with malignant urothelial histology",
    "management": "urologic oncology staging and treatment",
    "difficulty": "Hard"
  },
  {
    "title": "Reninoma",
    "topic": "Renal neoplasia/endocrine",
    "complaint": "young adult with severe hypertension, hypokalemia and high renin",
    "hopi": "A patient presents with young adult with severe hypertension, hypokalemia and high renin. The clinical pattern raises concern for Reninoma; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "juxtaglomerular cell tumor secretes renin and activates RAAS",
    "test": "plasma renin/aldosterone and renal imaging",
    "result": "high renin with small cortical renal lesion",
    "management": "specialist assessment and surgical resection when confirmed",
    "difficulty": "Expert"
  },
  {
    "title": "Wilms tumor with WT1 association",
    "topic": "Renal embryology/genetics",
    "complaint": "child with renal mass and congenital genitourinary anomaly",
    "hopi": "A patient presents with child with renal mass and congenital genitourinary anomaly. The clinical pattern raises concern for Wilms tumor with WT1 association; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "WT1 pathway abnormalities affect nephrogenic development and tumor predisposition",
    "test": "renal imaging and genetic evaluation",
    "result": "renal mass with syndromic features",
    "management": "pediatric oncology and genetics management",
    "difficulty": "Hard"
  },
  {
    "title": "BK polyomavirus nephropathy",
    "topic": "Transplant nephrology",
    "complaint": "kidney transplant recipient with progressive graft dysfunction",
    "hopi": "A patient presents with kidney transplant recipient with progressive graft dysfunction. The clinical pattern raises concern for BK polyomavirus nephropathy; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "viral reactivation in immunosuppression injures tubular epithelium",
    "test": "plasma BK PCR and graft biopsy",
    "result": "high BK viral load and SV40-positive viral cytopathic change",
    "management": "carefully reduce immunosuppression with transplant team",
    "difficulty": "Expert"
  },
  {
    "title": "Acute cellular transplant rejection",
    "topic": "Transplant immunology",
    "complaint": "graft tenderness and rising creatinine after missed medication",
    "hopi": "A patient presents with graft tenderness and rising creatinine after missed medication. The clinical pattern raises concern for Acute cellular transplant rejection; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "recipient T cells infiltrate allograft and cause tubulitis",
    "test": "allograft biopsy and immunosuppressant levels",
    "result": "interstitial mononuclear infiltrate and tubulitis",
    "management": "urgent transplant-team-directed rejection therapy",
    "difficulty": "Hard"
  },
  {
    "title": "Hyperacute transplant rejection",
    "topic": "Transplant immunology",
    "complaint": "immediate graft failure after reperfusion",
    "hopi": "A patient presents with immediate graft failure after reperfusion. The clinical pattern raises concern for Hyperacute transplant rejection; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "preformed antibodies bind donor endothelium and cause complement-mediated thrombosis",
    "test": "crossmatch history and graft histopathology",
    "result": "vascular thrombosis and antibody/complement deposition",
    "management": "prevention by compatibility testing; urgent transplant team management",
    "difficulty": "Expert"
  },
  {
    "title": "Tacrolimus nephrotoxicity",
    "topic": "Transplant pharmacology",
    "complaint": "transplant recipient with tremor, hypertension and rising creatinine",
    "hopi": "A patient presents with transplant recipient with tremor, hypertension and rising creatinine. The clinical pattern raises concern for Tacrolimus nephrotoxicity; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "calcineurin inhibitor causes renal vasoconstriction and chronic tubular/vascular injury",
    "test": "tacrolimus trough, renal function and graft assessment",
    "result": "elevated trough with creatinine rise after excluding rejection",
    "management": "adjust drug under transplant supervision and monitor levels",
    "difficulty": "Hard"
  },
  {
    "title": "BK virus versus rejection",
    "topic": "Transplant differential",
    "complaint": "graft dysfunction with positive BK viral load",
    "hopi": "A patient presents with graft dysfunction with positive BK viral load. The clinical pattern raises concern for BK virus versus rejection; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "viral tubular injury can mimic rejection histologically and clinically",
    "test": "plasma BK PCR and biopsy with SV40 staining",
    "result": "viral cytopathic change with SV40 positivity supports BK nephropathy",
    "management": "reduce immunosuppression carefully rather than reflexively intensifying it",
    "difficulty": "Expert"
  },
  {
    "title": "Uremic pericarditis",
    "topic": "CKD complication",
    "complaint": "advanced kidney failure with pleuritic pain and pericardial rub",
    "hopi": "A patient presents with advanced kidney failure with pleuritic pain and pericardial rub. The clinical pattern raises concern for Uremic pericarditis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "retained uremic toxins cause pericardial inflammation",
    "test": "renal profile, ECG and echocardiography",
    "result": "advanced azotemia with pericardial inflammation/effusion",
    "management": "urgent dialysis initiation and complication management",
    "difficulty": "Expert"
  },
  {
    "title": "Anemia of CKD",
    "topic": "CKD complication",
    "complaint": "fatigue and normocytic anemia in stage 4 CKD",
    "hopi": "A patient presents with fatigue and normocytic anemia in stage 4 CKD. The clinical pattern raises concern for Anemia of CKD; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "loss of renal EPO-producing interstitial cells reduces erythropoiesis",
    "test": "CBC, reticulocyte count, iron/B12/folate and renal function",
    "result": "normocytic anemia with inadequate reticulocyte response",
    "management": "correct reversible causes and consider ESA by guideline thresholds",
    "difficulty": "Medium"
  },
  {
    "title": "Secondary hyperparathyroidism in CKD",
    "topic": "CKD-mineral bone disorder",
    "complaint": "bone pain, high phosphate and elevated PTH",
    "hopi": "A patient presents with bone pain, high phosphate and elevated PTH. The clinical pattern raises concern for Secondary hyperparathyroidism in CKD; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "phosphate retention and low calcitriol drive secondary PTH elevation",
    "test": "calcium, phosphate, PTH, alkaline phosphatase and vitamin D",
    "result": "hyperphosphatemia with high PTH and low active vitamin D",
    "management": "phosphate management, binders and selected vitamin D/calcimimetic therapy",
    "difficulty": "Hard"
  },
  {
    "title": "Pulmonary edema in renal failure",
    "topic": "CKD complication",
    "complaint": "missed dialysis with dyspnea, raised JVP and crackles",
    "hopi": "A patient presents with missed dialysis with dyspnea, raised JVP and crackles. The clinical pattern raises concern for Pulmonary edema in renal failure; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "sodium/water retention increases pulmonary hydrostatic pressure",
    "test": "oxygenation, chest radiograph, ECG and electrolytes",
    "result": "pulmonary vascular congestion with volume overload",
    "management": "stabilize and arrange urgent ultrafiltration/dialysis when severe",
    "difficulty": "Hard"
  },
  {
    "title": "Dialysis disequilibrium syndrome",
    "topic": "Renal replacement therapy",
    "complaint": "headache and confusion during first rapid dialysis",
    "hopi": "A patient presents with headache and confusion during first rapid dialysis. The clinical pattern raises concern for Dialysis disequilibrium syndrome; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "rapid urea removal creates osmotic gradient and cerebral edema",
    "test": "neurologic assessment and dialysis parameters",
    "result": "symptoms during rapid initial dialysis with marked urea reduction",
    "management": "stop/slow dialysis and use gentler prescriptions in high-risk patients",
    "difficulty": "Expert"
  },
  {
    "title": "Peritoneal dialysis peritonitis",
    "topic": "Renal replacement therapy",
    "complaint": "abdominal pain, fever and cloudy dialysate",
    "hopi": "A patient presents with abdominal pain, fever and cloudy dialysate. The clinical pattern raises concern for Peritoneal dialysis peritonitis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "contamination introduces organisms into peritoneal cavity",
    "test": "dialysate cell count, Gram stain and culture",
    "result": "neutrophil-rich cloudy effluent with positive culture",
    "management": "collect samples and start empiric intraperitoneal antibiotics per protocol",
    "difficulty": "Medium"
  },
  {
    "title": "Tumor lysis syndrome",
    "topic": "Renal emergency",
    "complaint": "oliguria after chemotherapy with hyperkalemia and hyperphosphatemia",
    "hopi": "A patient presents with oliguria after chemotherapy with hyperkalemia and hyperphosphatemia. The clinical pattern raises concern for Tumor lysis syndrome; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "cell lysis releases potassium, phosphate and nucleic acids; urate and calcium-phosphate precipitate",
    "test": "serial electrolytes, uric acid, creatinine and ECG",
    "result": "hyperkalemia, hyperphosphatemia, hyperuricemia, hypocalcemia and AKI",
    "management": "urgent protocol hydration, urate-lowering and electrolyte management; dialysis if indicated",
    "difficulty": "Expert"
  },
  {
    "title": "Hemolytic uremic syndrome",
    "topic": "Renal vascular pathology",
    "complaint": "child with pallor, bruising and oliguria after bloody diarrhea",
    "hopi": "A patient presents with child with pallor, bruising and oliguria after bloody diarrhea. The clinical pattern raises concern for Hemolytic uremic syndrome; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "Shiga toxin injures renal endothelium and causes platelet microthrombi",
    "test": "CBC, smear, LDH, haptoglobin and stool Shiga toxin",
    "result": "schistocytes, thrombocytopenia, hemolysis and AKI",
    "management": "supportive care and dialysis if indicated; avoid antimotility agents",
    "difficulty": "Hard"
  },
  {
    "title": "Thrombotic thrombocytopenic purpura with renal injury",
    "topic": "Renal vascular pathology",
    "complaint": "AKI, thrombocytopenia, confusion and schistocytes",
    "hopi": "A patient presents with AKI, thrombocytopenia, confusion and schistocytes. The clinical pattern raises concern for Thrombotic thrombocytopenic purpura with renal injury; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "severe ADAMTS13 deficiency causes platelet-rich microthrombi",
    "test": "ADAMTS13 activity, CBC, smear and hemolysis markers",
    "result": "microangiopathic hemolysis and severe thrombocytopenia",
    "management": "emergency hematology pathway and prompt plasma exchange-based treatment",
    "difficulty": "Expert"
  },
  {
    "title": "Renal papillary necrosis",
    "topic": "Renal medullary pathology",
    "complaint": "diabetes with pyelonephritis, hematuria and colicky pain",
    "hopi": "A patient presents with diabetes with pyelonephritis, hematuria and colicky pain. The clinical pattern raises concern for Renal papillary necrosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "medullary ischemia causes coagulative necrosis and sloughing of papillae",
    "test": "urinalysis and CT urography when indicated",
    "result": "sloughed papilla or calyceal excavation",
    "management": "treat infection/precipitant and relieve obstruction if present",
    "difficulty": "Hard"
  },
  {
    "title": "Sickle cell nephropathy",
    "topic": "Renal medullary pathology",
    "complaint": "sickle cell disease with nocturia and painless hematuria",
    "hopi": "A patient presents with sickle cell disease with nocturia and painless hematuria. The clinical pattern raises concern for Sickle cell nephropathy; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "medullary hypoxia and hypertonicity promote vasa recta sickling",
    "test": "urinalysis and renal function; imaging if gross hematuria",
    "result": "hematuria with impaired urine concentration",
    "management": "hydration, sickle cell disease control and evaluate bleeding source",
    "difficulty": "Medium"
  },
  {
    "title": "Genitourinary tuberculosis",
    "topic": "Urinary microbiology",
    "complaint": "chronic urinary symptoms with persistent sterile pyuria",
    "hopi": "A patient presents with chronic urinary symptoms with persistent sterile pyuria. The clinical pattern raises concern for Genitourinary tuberculosis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "hematogenous TB seeding causes granulomatous urinary tract inflammation",
    "test": "early morning urine mycobacterial culture/NAAT and imaging",
    "result": "sterile pyuria with positive mycobacterial test",
    "management": "TB-directed multidrug therapy and assessment of urinary tract damage",
    "difficulty": "Expert"
  },
  {
    "title": "Renal tuberculosis versus bacterial pyelonephritis",
    "topic": "Urinary microbiology",
    "complaint": "recurrent sterile pyuria and calyceal irregularity",
    "hopi": "A patient presents with recurrent sterile pyuria and calyceal irregularity. The clinical pattern raises concern for Renal tuberculosis versus bacterial pyelonephritis; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "mycobacterial infection produces chronic granulomatous lesions rather than acute routine bacterial infection",
    "test": "urine AFB culture/NAAT and CT urography",
    "result": "repeated sterile pyuria and calyceal stricturing",
    "management": "specialist TB treatment and urologic follow-up",
    "difficulty": "Hard"
  },
  {
    "title": "Preeclampsia-associated renal injury",
    "topic": "Pregnancy and renal disease",
    "complaint": "pregnant patient after 20 weeks with hypertension and proteinuria",
    "hopi": "A patient presents with pregnant patient after 20 weeks with hypertension and proteinuria. The clinical pattern raises concern for Preeclampsia-associated renal injury; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "placental endothelial dysfunction causes glomerular endotheliosis and reduced filtration",
    "test": "BP, urine protein, CBC, liver tests and creatinine",
    "result": "new hypertension with proteinuria after 20 weeks",
    "management": "urgent obstetric assessment and maternal-fetal monitoring; treat severe features",
    "difficulty": "Hard"
  },
  {
    "title": "ACE inhibitor fetopathy",
    "topic": "Renal embryology/pharmacology",
    "complaint": "fetal oligohydramnios after maternal ACE inhibitor exposure",
    "hopi": "A patient presents with fetal oligohydramnios after maternal ACE inhibitor exposure. The clinical pattern raises concern for ACE inhibitor fetopathy; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "fetal RAAS blockade impairs renal perfusion and urine production",
    "test": "medication history and prenatal ultrasound",
    "result": "oligohydramnios with fetal/neonatal renal impairment",
    "management": "avoid ACE inhibitors/ARBs in pregnancy and coordinate neonatal assessment",
    "difficulty": "Expert"
  },
  {
    "title": "Physiologic hydronephrosis of pregnancy",
    "topic": "Renal anatomy in pregnancy",
    "complaint": "late pregnancy with mild right collecting-system dilation and no infection",
    "hopi": "A patient presents with late pregnancy with mild right collecting-system dilation and no infection. The clinical pattern raises concern for Physiologic hydronephrosis of pregnancy; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "progesterone relaxation and uterine compression dilate ureter, often right-predominant",
    "test": "urinalysis/culture and renal ultrasound",
    "result": "mild right-predominant hydronephrosis without obstruction",
    "management": "reassure if uncomplicated; evaluate fever, severe pain or infection promptly",
    "difficulty": "Medium"
  },
  {
    "title": "Renal dose adjustment",
    "topic": "Renal pharmacology",
    "complaint": "drug toxicity after standard dosing in stage 4 CKD",
    "hopi": "A patient presents with drug toxicity after standard dosing in stage 4 CKD. The clinical pattern raises concern for Renal dose adjustment; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "reduced GFR decreases clearance of renally eliminated medication",
    "test": "eGFR/CrCl and medication review",
    "result": "drug dose exceeds current renal clearance capacity",
    "management": "adjust dose or interval using drug-specific guidance",
    "difficulty": "Easy"
  },
  {
    "title": "Trimethoprim pseudo-creatinine rise",
    "topic": "Renal pharmacology",
    "complaint": "modest creatinine rise and hyperkalemia after TMP-SMX",
    "hopi": "A patient presents with modest creatinine rise and hyperkalemia after TMP-SMX. The clinical pattern raises concern for Trimethoprim pseudo-creatinine rise; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "trimethoprim blocks tubular creatinine secretion and ENaC",
    "test": "repeat renal profile, potassium and medication review",
    "result": "small creatinine rise with possible true hyperkalemia",
    "management": "review drug necessity/dose and monitor potassium",
    "difficulty": "Hard"
  },
  {
    "title": "Amphotericin B nephrotoxicity",
    "topic": "Renal pharmacology",
    "complaint": "AKI with hypokalemia and hypomagnesemia during antifungal therapy",
    "hopi": "A patient presents with AKI with hypokalemia and hypomagnesemia during antifungal therapy. The clinical pattern raises concern for Amphotericin B nephrotoxicity; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "tubular membrane injury and renal vasoconstriction cause electrolyte wasting",
    "test": "renal function, potassium and magnesium",
    "result": "creatinine rise with renal K/Mg wasting",
    "management": "consider lipid formulation, appropriate hydration and electrolyte monitoring",
    "difficulty": "Hard"
  },
  {
    "title": "Cisplatin nephrotoxicity",
    "topic": "Renal pharmacology",
    "complaint": "AKI and magnesium wasting after chemotherapy",
    "hopi": "A patient presents with AKI and magnesium wasting after chemotherapy. The clinical pattern raises concern for Cisplatin nephrotoxicity; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "cisplatin accumulates in proximal tubular cells and causes oxidative injury",
    "test": "creatinine, magnesium and potassium",
    "result": "AKI with hypomagnesemia after cisplatin",
    "management": "protocol hydration, dose adjustment and electrolyte replacement",
    "difficulty": "Hard"
  },
  {
    "title": "Acetazolamide-induced proximal RTA",
    "topic": "Renal pharmacology",
    "complaint": "paresthesias and low bicarbonate after acetazolamide",
    "hopi": "A patient presents with paresthesias and low bicarbonate after acetazolamide. The clinical pattern raises concern for Acetazolamide-induced proximal RTA; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "carbonic anhydrase inhibition reduces proximal bicarbonate reabsorption",
    "test": "serum bicarbonate and urine pH",
    "result": "normal-gap metabolic acidosis with bicarbonaturia",
    "management": "review medication and correct significant electrolyte disturbance",
    "difficulty": "Medium"
  },
  {
    "title": "Furosemide ototoxicity",
    "topic": "Renal pharmacology",
    "complaint": "tinnitus during rapid high-dose IV loop diuretic",
    "hopi": "A patient presents with tinnitus during rapid high-dose IV loop diuretic. The clinical pattern raises concern for Furosemide ototoxicity; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "NKCC1 inhibition in stria vascularis disrupts endolymph ionic gradients",
    "test": "drug review and audiology",
    "result": "hearing symptoms temporally related to high-dose IV furosemide",
    "management": "reduce/stop exposure and avoid other ototoxic agents",
    "difficulty": "Hard"
  },
  {
    "title": "Thiazide effect on calcium",
    "topic": "Renal pharmacology",
    "complaint": "recurrent calcium stones with hypercalciuria",
    "hopi": "A patient presents with recurrent calcium stones with hypercalciuria. The clinical pattern raises concern for Thiazide effect on calcium; the following targeted findings are provided for diagnostic reasoning.",
    "mechanism": "thiazide increases distal calcium reabsorption and reduces urinary calcium",
    "test": "24-hour urine calcium and serum electrolytes",
    "result": "hypercalciuria on metabolic evaluation",
    "management": "consider thiazide with sodium reduction and electrolyte monitoring",
    "difficulty": "Medium"
  }
];
const subjects = ["Medicine","Pathology","Pharmacology","Anatomy","Physiology","Microbiology","Histology","Embryology"];
const names = ["Daniel R.", "Maya P.", "Arjun V.", "Sara K.", "Omar H.", "Elena C.", "Nina S.", "Rohan M."];
const portraitFor = (age:number, sex:string) => {
 const band = age < 35 ? "young" : age < 65 ? "middle-age" : "old";
 const gender = sex === "Female" ? "woman" : "man";
 return `/portraits/${band}-${gender}.png`;
};
const patientAgeFor = (r:any,i:number) => {
 const t = `${r.complaint} ${r.hopi}`.toLowerCase();
 if (/\b(infant|newborn|neonate|baby|child|paediatric|pediatric)\b/.test(t)) return [5,7,9,11][i%4];
 if (/\b(adolescent|teenager|teenage)\b/.test(t)) return [14,16,17][i%3];
 if (/\b(older|elderly|aged)\b/.test(t)) return [65,68,72,76][i%4];
 if (/\byoung adult\b/.test(t)) return [21,24,29][i%3];
 return [34,38,42,47,51,56][i%6];
};
const diagnosisDistractors = (r:any,i:number) => {
 const t = `${r.topic} ${r.title} ${r.complaint} ${r.mechanism}`.toLowerCase();
 let pool:string[];
 if (/nephrotic|podocyte|membranous|fsgs|minimal change|amyloid/.test(t)) pool=["Minimal change disease","Focal segmental glomerulosclerosis","Membranous nephropathy","Diabetic kidney disease","Amyloidosis of kidney","Lupus nephritis"];
 else if (/nephritic|glomerul|iga|poststrept|anti-gbm|vasculitis|alport|complement/.test(t)) pool=["IgA nephropathy","Poststreptococcal glomerulonephritis","Lupus nephritis","Anti-GBM disease","Membranoproliferative glomerulonephritis","Infection-related glomerulonephritis"];
 else if (/stone|nephrolith|oxal|struvite|cystinuria|uric acid/.test(t)) pool=["Calcium oxalate nephrolithiasis","Uric acid nephrolithiasis","Cystinuria","Proteus-associated struvite stone","Primary hyperoxaluria","Medullary sponge kidney"];
 else if (/infection|pyelonephritis|uti|tuberculosis/.test(t)) pool=["Acute pyelonephritis","Acute cystitis","Renal tuberculosis","Infection-related glomerulonephritis","Proteus-associated struvite stone"];
 else if (/aki|acute kidney|tubular|prerenal|interstitial|nephrotox|rhabdomyolysis|contrast/.test(t)) pool=["Prerenal azotemia","Acute tubular necrosis","Acute interstitial nephritis","Postrenal acute kidney injury","Rhabdomyolysis-associated AKI","NSAID hemodynamic AKI"];
 else if (/ckd|chronic kidney|diabetic|hypertensive|anemia of ckd/.test(t)) pool=["Diabetic kidney disease","Hypertensive nephrosclerosis","Chronic glomerulonephritis","Polycystic kidney disease","Amyloidosis of kidney"];
 else if (/rta|acid|electrolyte|potassium|calcium|phosphate|diabetes insipidus|water balance/.test(t)) pool=["Type 1 distal renal tubular acidosis","Type 2 proximal renal tubular acidosis","Type 4 renal tubular acidosis","Primary hyperaldosteronism","Central diabetes insipidus","Nephrogenic diabetes insipidus"];
 else if (/congenital|embry|ureteric|agenesis|potter|horseshoe|polycystic/.test(t)) pool=["Bilateral renal agenesis","Horseshoe kidney","Autosomal dominant polycystic kidney disease","Posterior urethral valves","Duplex collecting system"];
 else if (/diuretic|drug|pharmac|cisplatin|amphotericin|acetazolamide|furosemide|thiazide/.test(t)) pool=["Cisplatin nephrotoxicity","Amphotericin B nephrotoxicity","Acetazolamide-induced proximal RTA","NSAID hemodynamic AKI","Thiazide effect on calcium","Furosemide ototoxicity"];
 else pool=["IgA nephropathy","Acute tubular necrosis","Diabetic kidney disease","Renal artery stenosis","Autosomal dominant polycystic kidney disease"];
 const unique=pool.filter(x=>x.toLowerCase()!==String(r.title).toLowerCase());
 const offset=i % Math.max(1,unique.length);
 const rotated=[...unique.slice(offset),...unique.slice(0,offset)];
 const reasons:Record<string,string> = {
  "Minimal change disease":"Usually causes nephrotic-range proteinuria with bland urine sediment and diffuse podocyte foot-process effacement; the case-specific biopsy/serology or nephritic sediment described here points elsewhere.",
  "Focal segmental glomerulosclerosis":"Often has segmental sclerosis on biopsy and may be associated with HIV, obesity or reduced nephron mass; the defining clinical or biopsy feature in this vignette is absent.",
  "Membranous nephropathy":"Typically causes nephrotic syndrome in adults with subepithelial immune deposits and capillary-wall thickening; the age, urine pattern or biopsy finding here is not characteristic.",
  "Diabetic kidney disease":"Usually develops after longstanding diabetes with albuminuria and gradual eGFR decline; the acute timeline or non-diabetic biopsy pattern here argues against it.",
  "Amyloidosis of kidney":"Usually causes proteinuria in a systemic context and Congo-red-positive deposits; no compatible systemic clues or biopsy finding is supplied.",
  "Lupus nephritis":"Would be supported by SLE features, autoantibodies and immune-complex biopsy findings; the specific clinical/serologic pattern in this vignette is different.",
  "IgA nephropathy":"Classically causes synpharyngitic hematuria with mesangial IgA and often normal complement; the timing, complement or biopsy pattern here does not fit.",
  "Poststreptococcal glomerulonephritis":"Usually follows streptococcal infection after a latent interval with low C3; the timing or complement pattern described here is not compatible.",
  "Anti-GBM disease":"Typically causes rapidly progressive GN with linear IgG and may include pulmonary hemorrhage; those serologic/biopsy or pulmonary findings are absent.",
  "Membranoproliferative glomerulonephritis":"Usually has a characteristic mesangial/endocapillary proliferative pattern and double-contoured GBM; the biopsy and complement profile here differ.",
  "Infection-related glomerulonephritis":"Requires a compatible active or recent infection and often low complement with immune-complex deposits; the clinical timing and test profile here argue against it.",
  "Acute pyelonephritis":"Usually causes fever, flank pain, pyuria and bacteriuria; a bland urine or glomerular sediment without systemic infection makes it less likely.",
  "Acute cystitis":"Causes dysuria, frequency and urgency without renal parenchymal involvement; it does not explain the flank/systemic or glomerular findings here.",
  "Renal tuberculosis":"Usually causes chronic sterile pyuria, urinary symptoms and exposure risk; the acute presentation and negative relevant testing do not support it.",
  "Calcium oxalate nephrolithiasis":"Usually causes colicky flank-to-groin pain and radiopaque stones; the imaging, urine chemistry or absence of colic here argues against it.",
  "Uric acid nephrolithiasis":"Associated with acidic urine and radiolucent stones, often with gout/metabolic syndrome; the urine pH or stone analysis here does not fit.",
  "Cystinuria":"Typically presents with recurrent stones at a young age and hexagonal crystals; neither the crystal morphology nor recurrence pattern is present.",
  "Proteus-associated struvite stone":"Requires urease-producing infection and often a staghorn calculus; urine culture and imaging findings here do not support it.",
  "Prerenal azotemia":"Usually follows reduced effective circulating volume and improves with perfusion restoration; the sediment or persistent intrinsic injury pattern here is inconsistent.",
  "Acute tubular necrosis":"Typically follows ischemia or nephrotoxins with muddy brown granular casts and persistent renal dysfunction; the urine sediment and timeline here point elsewhere.",
  "Acute interstitial nephritis":"Often follows a medication exposure and may cause pyuria, WBC casts, rash or eosinophilia; the exposure and urine findings here are not supportive.",
  "Postrenal acute kidney injury":"Requires urinary obstruction, often with hydronephrosis or retention; the bladder assessment and imaging here do not show obstruction.",
  "Rhabdomyolysis-associated AKI":"Usually follows muscle injury with marked CK elevation and heme-positive urine with few RBCs; those findings are not present.",
  "NSAID hemodynamic AKI":"Usually follows NSAID exposure in a volume-depleted or CKD patient due to afferent vasoconstriction; no relevant exposure or hemodynamic context is described.",
  "Type 1 distal renal tubular acidosis":"Typically causes normal-anion-gap acidosis, inappropriately high urine pH and nephrolithiasis; the acid-base/urine pattern here differs.",
  "Type 2 proximal renal tubular acidosis":"Causes bicarbonate wasting and may be part of Fanconi syndrome; the urine pH and associated proximal tubular losses here are not supportive.",
  "Type 4 renal tubular acidosis":"Usually occurs with hypoaldosteronism and hyperkalemia; potassium and hormonal context in this vignette do not fit.",
  "Central diabetes insipidus":"Causes dilute polyuria that responds to desmopressin; the response to testing or medication history here favors another cause.",
  "Nephrogenic diabetes insipidus":"Causes dilute polyuria resistant to desmopressin, often from lithium or electrolyte disturbance; the trigger and test response here are inconsistent.",
  "Renal artery stenosis":"Usually causes resistant hypertension, asymmetric kidneys or a creatinine rise after ACE inhibitor/ARB; the vascular clues are absent.",
  "Autosomal dominant polycystic kidney disease":"Usually has bilateral renal cysts and often a family history; imaging and inheritance clues in this case do not support it."
 };
 return rotated.slice(0,4).map(name=>({name,whyNot:reasons[name] || `${name} remains a consideration, but its defining clinical clues or confirmatory test pattern are not present. In this vignette, the timing, examination and targeted result (${r.result}) provide a more specific explanation for the leading diagnosis.`}));
};
const levels=["Easy","Medium","Hard","Expert"];
const renalCategoryFor = (r:any) => {
 const t = `${r.topic} ${r.title} ${r.complaint} ${r.mechanism}`.toLowerCase();
 if (/renal anatomy|kidney and ureter|renal vasculature|collecting system|renal artery anatomy/.test(t)) return "Kidney and ureter anatomy";
 if (/ureteric bud|metanephric|congenital|horseshoe|potter|polycystic|posterior urethral|agenesis|hydronephrosis|duplex/.test(t)) return "Congenital renal and urinary anomalies";
 if (/glomerular filtration barrier|podocyte|basement membrane|juxtaglomerular apparatus|tubular segments|collecting duct|renal histology/.test(t)) return /juxtaglomerular/.test(t) ? "Juxtaglomerular apparatus" : /tubular segments|collecting duct/.test(t) ? "Tubular segments and collecting duct" : "Glomerular filtration barrier";
 if (/renal physiology|glomerular filtration|renal blood flow|gfr|filtration fraction/.test(t)) return "Glomerular filtration and renal blood flow";
 if (/tubular transport|countercurrent|concentrat|reabsorption|secretion/.test(t)) return "Tubular transport and concentration";
 if (/diuretic|acetazolamide|furosemide|thiazide|loop diuretic/.test(t)) return "Diuretics and tubular transport";
 if (/raas|ace inhibitor|arb|angiotensin|aldosterone/.test(t)) return "RAAS drugs and renal hemodynamics";
 if (/tobramycin|amphotericin|cisplatin|trimethoprim|nephrotoxic|renal dose|drug toxicity|drug-induced/.test(t)) return "Nephrotoxic drugs and renal dosing";
 if (/urinary tract infection|uti|pyelonephritis|cystitis|bacteriuria/.test(t)) return "Urinary tract infections";
 if (/tuberculosis|renal infection/.test(t)) return "Renal infections and tuberculosis";
 if (/glomerul|nephrotic|nephritic|iga|anti-gbm|vasculitis|podocyte|membranous|fsgs|amyloid|alport|lupus nephritis/.test(t)) return "Glomerular diseases";
 if (/acute kidney injury|acute tubular|prerenal|interstitial nephritis|rhabdomyolysis|contrast nephropathy|oliguria/.test(t)) return "Acute kidney injury";
 if (/chronic kidney|diabetic kidney|hypertensive nephrosclerosis|uremia|ckd/.test(t)) return "Chronic kidney disease";
 if (/stone|nephrolith|oxaluria|struvite|uric acid|cystinuria|medullary sponge/.test(t)) return "Renal neoplasia and stones";
 if (/acid|rta|potassium|sodium|calcium|phosphate|water balance|diabetes insipidus|aldosterone/.test(t)) return "Electrolyte and acid-base regulation";
 if (/renal artery|stenosis|vascular|hypertension/.test(t)) return "Tubulointerstitial and vascular disease";
 if (/transplant/.test(t)) return "Transplant and renal emergencies";
 return "Nephritic and nephrotic syndromes";
};
const renalTitleFor = (r:any) => {
 const phrase = String(r.complaint || "A renal presentation").replace(/^a(n)?\s+/i, "");
 const words = phrase.split(/\s+/).slice(0, 8).join(" ").replace(/[.,;:]$/, "");
 return words.charAt(0).toUpperCase() + words.slice(1);
};
const renalContext = (r:any) => {
 const t = `${r.title} ${r.topic} ${r.complaint} ${r.hopi}`.toLowerCase();
 if (/alport|hearing|sensorineural/.test(t)) return {background:["Persistent microscopic or episodic gross hematuria has been noted since childhood.","A first-degree relative has kidney disease or hearing impairment.","No recent streptococcal infection or nephrotoxic medication exposure."],examination:["Blood pressure and growth parameters assessed.","No edema or rash is present unless separately described.","Bedside hearing screen is abnormal; ocular assessment is arranged."]};
 if (/poststrept|impetigo|pharyngitis|cola-colored/.test(t)) return {background:["A recent group A streptococcal skin or throat infection preceded the urinary symptoms.","No prior episodes of hematuria or known chronic kidney disease.","No recent NSAID or contrast exposure."],examination:["Periorbital and dependent edema present.","Blood pressure is elevated for age.","No purpura, arthritis or pulmonary findings."]};
 if (/iga nephropathy|synpharyngitic|uri/.test(t)) return {background:["Gross hematuria began during or within a day or two of an upper respiratory infection.","No preceding skin infection several weeks earlier.","No hearing loss or family history of hereditary nephritis."],examination:["Blood pressure assessed for hypertension.","Mild peripheral edema may be present; no pulmonary edema.","No palpable purpura or systemic vasculitic rash."]};
 if (/nephrotic|minimal change|fsgs|membranous/.test(t)) return {background:["Progressive frothy urine and edema without dysuria or flank colic.","Medication and systemic disease history reviewed for secondary causes.","No recent gross hematuria or urinary tract infection."],examination:["Periorbital and dependent pitting edema present.","Ascites assessed; lungs auscultated for effusions.","Blood pressure and intravascular volume status assessed."]};
 if (/stone|nephrolith|calculus|oxalate|struvite|cystin/.test(t)) return {background:["Colicky flank pain radiates toward the groin and is associated with nausea.","Prior stone episodes, fluid intake and dietary risk factors reviewed.","No fever or rigors unless infection is specifically described."],examination:["Costovertebral-angle tenderness present.","Abdominal examination shows no peritonism.","Assess fever, hemodynamic stability and urine output for infected obstruction."]};
 if (/uti|pyelo|infection|recurrent febrile/.test(t)) return {background:["Urinary symptoms and prior culture results reviewed.","Ask about urinary instrumentation, reflux, pregnancy and recent antibiotics.","No known stone history unless specified in the vignette."],examination:["Temperature and hemodynamic status assessed.","Suprapubic or costovertebral-angle tenderness present when clinically appropriate.","Assess hydration and signs of sepsis."]};
 if (/acute kidney injury|acute tubular|prerenal|nephrotoxic|rhabdomyolysis/.test(t)) return {background:["Recent fluid losses, poor intake and urine output quantified.","Medication review includes NSAIDs, aminoglycosides, contrast and other nephrotoxins.","Baseline creatinine and recent procedures or hypotension reviewed."],examination:["Volume status assessed for dehydration or overload.","Blood pressure, perfusion and urine output assessed.","Look for edema, bladder distension or systemic clues to the cause."]};
 if (/renal artery|hypertension|vascular/.test(t)) return {background:["Blood pressure has been difficult to control despite multiple agents.","Ask about smoking, atherosclerotic disease and sudden worsening after RAAS blockade.","No urinary infection symptoms."],examination:["Repeated blood pressure measurements confirm hypertension.","Abdominal bruit assessed.","Peripheral pulses and signs of vascular disease assessed."]};
 if (/polycystic|cystic kidney/.test(t)) return {background:["First-degree relatives have renal cysts or kidney failure.","Ask about hematuria, flank discomfort and family history of intracranial aneurysm.","No recent infection or trauma."],examination:["Bilateral flank fullness or enlarged kidneys may be present.","Blood pressure assessed for early hypertension.","Assess for hepatic cyst-related findings and abdominal tenderness."]};
 if (/diabetes insipidus|acetazolamide|rta|acid|potassium|electrolyte|sodium/.test(t)) return {background:["Medication history specifically reviews diuretics, acetazolamide and agents affecting tubular transport.","Fluid intake, thirst, urine volume and recent gastrointestinal losses are documented.","No unreported chronic renal history is assumed."],examination:["Assess hydration, orthostatic symptoms and volume status.","Neurologic status assessed for severe sodium disturbance.","Look for weakness, arrhythmia or respiratory compensation when acid-base disturbance is suspected."]};
 return {background:[`The history is focused on the onset and course of ${r.complaint}.`,`Medication exposure, family history and relevant systemic symptoms are reviewed for ${r.topic}.`,`No additional risk factor is assumed unless stated in the vignette.`],examination:["Blood pressure, hydration and peripheral edema are specifically assessed.","Abdominal and flank examination is directed by the presenting urinary or renal symptoms.","Systemic examination checks for rash, joint, pulmonary, auditory or ocular findings relevant to the differential."]};
};
export const renalCases: Case[] = records.map((r:any,i:number)=>{
 const diffPool=diagnosisDistractors(r,i);
 const context=renalContext(r);
 return {id:`mq-renal-${String(i+1).padStart(3,"0")}`,title:renalTitleFor(r),difficulty:r.difficulty,subjectTags:subjects,topicTags:[r.topic,renalCategoryFor(r)],supportingConcepts:["Renal pathology",r.topic,r.mechanism,renalCategoryFor(r)],patient:{age:patientAgeFor(r,i),sex:i%2?"Female":"Male",name:names[i%8],portrait:portraitFor(patientAgeFor(r,i),i%2?"Female":"Male")},complaint:r.complaint,hopi:`A patient presents with ${r.complaint}. ${r.hopi.replace(/^A patient presents with .*?\. The clinical pattern raises concern for .*?; /i, "Further assessment is directed by the history and examination. ").replace(/The clinical pattern raises concern for [^;]+; /i, "Further assessment is directed by the history and examination. ")}`,background:context.background,examination:context.examination,vitals:[{label:"Heart rate",value:"96/min",flag:"Context-dependent"},{label:"Blood pressure",value:"138/86 mmHg",flag:"Assess clinically"},{label:"Respiratory rate",value:"18/min",flag:"Normal"},{label:"Temperature",value:"36.8 °C",flag:"Normal"},{label:"Oxygen saturation",value:"98%",flag:"Normal"}],investigations:[{id:"vitals",name:"Vitals and focused assessment",category:"Bedside",relevance:"Assess stability, volume status and immediate complications.",result:"No additional abnormal vital sign is assumed beyond the case presentation.",interpretation:"Interpret with the vignette and repeat if the patient's condition changes.",useful:true},{id:"targeted",name:r.test,category:"Targeted renal investigation",relevance:`Selected to answer the specific diagnostic question for ${r.title}.`,result:r.result,interpretation:`${r.result} This finding supports the leading diagnosis in the clinical context; correlate with timing and pre-test probability.`,useful:true},{id:"urinalysis",name:"Urinalysis and urine microscopy",category:"Urine",relevance:"Assess protein, blood, casts, cells, concentration and infection as appropriate.",result:"No additional urine abnormality is asserted beyond the targeted findings in this vignette.",interpretation:"Use sediment and protein quantification to localize glomerular, tubular, interstitial or postrenal disease.",useful:true},{id:"renal-profile",name:"Renal function and electrolytes",category:"Blood",relevance:"Assess filtration and metabolic complications when relevant.",result:"No additional abnormality is specified beyond the case findings.",interpretation:"Interpret against baseline and laboratory-specific ranges.",useful:true},{id:"imaging",name:"Renal tract imaging",category:"Imaging",relevance:"Use ultrasound or CT when obstruction, stones, structural anomaly, mass or complication is suspected.",result:"Normal renal tract imaging: no hydronephrosis, calculus, mass or structural abnormality is identified in this teaching case.",interpretation:"No structural abnormality is demonstrated. Imaging may be normal in primary glomerular or tubular disease and should answer a specific clinical question.",useful:false}],diagnosisOptions:[r.title,...diffPool.map((d:any)=>d.name)].map((v:string,j:number,a:string[])=>({v,k:((j+1)*37+i*19)%101})).sort((a:any,b:any)=>a.k-b.k).map((x:any)=>x.v),correctDiagnosis:r.title,mechanismOptions:[r.mechanism,"Immune-complex deposition causing glomerular inflammation","Tubular epithelial injury causing impaired reabsorption","Obstruction raising tubular hydrostatic pressure"],correctMechanism:r.mechanism,differentials:diffPool,managementOptions:[{id:"targeted",label:r.management,detail:`Diagnosis-directed management principle for ${r.topic}; individualize to severity, renal function, contraindications and current local/specialist guidance.`},{id:"support",label:"Assess volume status, blood pressure, urine output and renal function; provide appropriate supportive care",detail:"Avoid both hypovolemia and fluid overload; tailor supportive care to the cause."},{id:"review",label:"Review medications and stop or adjust potential nephrotoxins and renally cleared drugs",detail:"Medication reconciliation and renal dose adjustment are essential in renal presentations."},{id:"monitor",label:"Monitor electrolytes, acid-base status and clinical trajectory",detail:"Escalate for refractory electrolyte disturbance, pulmonary edema, uremic complications or worsening oliguria."},{id:"unsafe",label:"Ignore worsening oliguria, hyperkalemia or pulmonary edema and discharge without reassessment",detail:"Unsafe: these findings may represent life-threatening renal complications."}],correctManagement:["targeted","support","review","monitor"],explanation:`${r.topic} is the leading concept because ${r.hopi} The key discriminating investigation is ${r.test}: ${r.result} Interpret with the clinical timeline and differential diagnoses.`,pathophysiology:r.mechanism,learningObjectives:[`Recognize the presentation of ${r.topic}.`,`Explain the mechanism: ${r.mechanism}`,`Select and interpret ${r.test}.`,`Integrate renal anatomy, physiology, pathology, pharmacology, microbiology, histology and embryology.`,`Choose appropriate management and identify complications requiring escalation.`]};
}).sort((a,b)=>levels.indexOf(a.difficulty)-levels.indexOf(b.difficulty));
