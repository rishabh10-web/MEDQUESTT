import type { Case } from "./data";

export const additionalCases: Case[] = [
  {
    id: "mq-opd-002",
    title: "The Crushing Pain",
    difficulty: "Medium",
    subjectTags: ["Pathology", "Physiology", "Pharmacology", "Biochemistry"],
    topicTags: ["Cardiovascular pathology", "Cardiovascular physiology", "Cardiovascular drugs"],
    supportingConcepts: ["Coronary circulation", "Cardiac biomarkers", "Lipid metabolism", "Haemodynamics", "Hemodynamic disorders", "Cell injury and adaptation"],
    patient: { age: 56, sex: "Male", name: "Rajesh K.", portrait: "/portraits/middle-age-man.png" },
    complaint: "Central chest pressure radiating to the left arm for 90 minutes",
    hopi: "A 56-year-old man presents with persistent central chest pressure that began while walking uphill. The discomfort radiates to his left arm and is associated with sweating and nausea. It has not settled with rest. He denies fever, cough or recent chest trauma.",
    background: ["Hypertension for 8 years; adherence to medication is inconsistent", "Smokes approximately 10 cigarettes daily", "Father had a myocardial infarction in his early sixties", "No known drug allergies"],
    examination: ["Anxious and diaphoretic", "Cool peripheries with palpable peripheral pulses", "No unilateral leg swelling", "Heart sounds present; no new loud murmur identified"],
    vitals: [
      { label: "Heart rate", value: "104", flag: "High" },
      { label: "Blood pressure", value: "148/92", flag: "High" },
      { label: "Respiratory rate", value: "22", flag: "High" },
      { label: "Temperature", value: "36.8", flag: "Normal" },
      { label: "Oxygen saturation", value: "97", flag: "Normal" }
    ],
    investigations: [
      { id: "vitals", name: "Vitals", category: "Bedside", relevance: "Assess haemodynamic stability and identify early deterioration.", result: "HR 104/min; BP 148/92 mmHg; RR 22/min; SpO₂ 97% on room air.", interpretation: "Tachycardia and hypertension may accompany pain and sympathetic activation. Continue serial assessment.", useful: true },
      { id: "ecg", name: "12-lead ECG", category: "Cardiac", relevance: "Obtain promptly in suspected acute coronary syndrome; repeat if symptoms persist and initial tracing is nondiagnostic.", result: "ST-segment elevation in leads II, III and aVF with reciprocal ST depression in I and aVL.", interpretation: "The regional ST-elevation pattern is consistent with an acute inferior STEMI in the appropriate clinical context. Activate the local reperfusion pathway urgently.", useful: true },
      { id: "troponin", name: "High-sensitivity troponin", category: "Blood", relevance: "Supports myocardial injury; interpret serial values and do not delay reperfusion when ECG establishes STEMI.", result: "Markedly above the assay's 99th percentile; rising on repeat sample.", units: "ng/L (assay-specific)", reference: "Below the assay-specific 99th percentile", interpretation: "A rising troponin supports acute myocardial injury. The ECG and clinical presentation determine immediate STEMI management.", useful: true },
      { id: "cbc", name: "Complete blood count", category: "Blood", relevance: "Baseline assessment and evaluation for anaemia or other relevant abnormalities.", result: "Hb 14.2; WBC 11,600; platelets 246,000", units: "g/dL; /µL; /µL", reference: "Laboratory-specific ranges", interpretation: "No anaemia or thrombocytopenia is evident in these teaching results. Mild leukocytosis is nonspecific.", useful: true },
      { id: "electrolytes", name: "Serum electrolytes and renal function", category: "Blood", relevance: "Baseline renal function and potassium inform medication and contrast planning.", result: "Na⁺ 139; K⁺ 4.1; creatinine 1.0", units: "mmol/L; mmol/L; mg/dL", reference: "Na⁺ 135–145; K⁺ 3.5–5.0; creatinine lab-dependent", interpretation: "No major electrolyte abnormality is shown. Renal function should be considered when planning contrast-based procedures and medication dosing.", useful: true },
      { id: "cxr", name: "Chest X-ray", category: "Imaging", relevance: "Use when alternative diagnoses or complications are suspected; it must not delay reperfusion.", result: "No acute pulmonary oedema or focal consolidation.", interpretation: "No acute radiographic abnormality is identified. A normal chest X-ray does not exclude myocardial infarction.", useful: false }
    ],
    diagnosisOptions: ["Acute inferior ST-elevation myocardial infarction", "Acute pericarditis", "Pulmonary embolism", "Stable angina", "Aortic dissection"],
    correctDiagnosis: "Acute inferior ST-elevation myocardial infarction",
    mechanismOptions: [
      "Acute coronary plaque disruption with thrombotic occlusion causing transmural myocardial ischaemia",
      "Inflammation of the pericardial layers causing positional pleuritic pain",
      "Pulmonary arterial obstruction causing acute right ventricular strain",
      "Fixed coronary narrowing causing predictable exertional ischaemia without acute thrombosis"
    ],
    correctMechanism: "Acute coronary plaque disruption with thrombotic occlusion causing transmural myocardial ischaemia",
    differentials: [
      { name: "Acute pericarditis", whyNot: "Typically causes pleuritic, positional pain with diffuse rather than territorial ST elevation." },
      { name: "Pulmonary embolism", whyNot: "Can cause chest pain and tachycardia, but the territorial inferior ST-elevation pattern and rising troponin support STEMI." },
      { name: "Stable angina", whyNot: "Usually resolves with rest and does not produce persistent ST elevation from acute coronary occlusion." },
      { name: "Aortic dissection", whyNot: "Consider urgently if tearing pain, pulse deficits or mediastinal findings are present; those features are not supplied here." }
    ],
    managementOptions: [
      { id: "activate", label: "Activate the emergency STEMI/reperfusion pathway and arrange immediate cardiology transfer", detail: "Time-critical reperfusion is the priority; follow local STEMI protocols and do not wait for troponin when the ECG is diagnostic." },
      { id: "aspirin", label: "Give aspirin promptly if no contraindication, following local acute coronary syndrome protocol", detail: "Antiplatelet therapy is a core early intervention; confirm allergy, bleeding risk and local protocol." },
      { id: "monitor", label: "Continuous cardiac monitoring, IV access and repeated vital-sign assessment", detail: "Detect arrhythmia and haemodynamic deterioration early." },
      { id: "antithrombotic", label: "Use additional antiplatelet and anticoagulant therapy as directed by the reperfusion pathway", detail: "Choice and timing depend on PCI strategy, bleeding risk and institutional protocol." },
      { id: "oxygen", label: "Give oxygen routinely despite normal oxygen saturation", detail: "Routine oxygen is not indicated in a normoxic patient; use when hypoxaemia or another clear indication is present." },
      { id: "delay", label: "Wait for the repeat troponin before activating reperfusion", detail: "Unsafe in a diagnostic STEMI ECG; reperfusion must not be delayed for biomarker confirmation." }
    ],
    correctManagement: ["activate", "aspirin", "monitor", "antithrombotic"],
    explanation: "Persistent ischaemic chest discomfort with inferior ST elevation and reciprocal changes is an acute inferior STEMI until proven otherwise. Reperfusion is time-critical; troponin supports myocardial injury but must not delay activation of the STEMI pathway.",
    pathophysiology: "Atherosclerotic plaque disruption exposes thrombogenic material, promoting platelet activation and thrombus formation. Acute coronary occlusion reduces oxygen delivery to myocardium, producing ischaemia and, if prolonged, myocardial necrosis. ECG changes reflect the territory and extent of injury.",
    learningObjectives: [
      "Recognize a territorial ST-elevation pattern with reciprocal changes.",
      "Prioritize reperfusion in STEMI without waiting for troponin results.",
      "Explain plaque rupture and coronary thrombosis in acute myocardial infarction.",
      "Distinguish STEMI from pericarditis, pulmonary embolism and stable angina.",
      "Use oxygen selectively rather than routinely in normoxic patients."
    ]
  },
  {
    id: "mq-opd-003",
    title: "The Breathless Morning",
    difficulty: "Medium",
    subjectTags: ["Pathology", "Microbiology", "Physiology", "Pharmacology"],
    topicTags: ["Respiratory pathology", "Respiratory infections", "Respiratory physiology", "Antimicrobials"],
    supportingConcepts: ["Alveolar gas exchange", "Innate immunity", "Inflammatory response", "Antibiotic stewardship", "Inflammation and repair"],
    patient: { age: 72, sex: "Female", name: "Meera S.", portrait: "/portraits/old-woman.png" },
    complaint: "Fever, cough with sputum and worsening breathlessness for three days",
    hopi: "A 72-year-old woman presents with three days of fever, productive cough and increasing shortness of breath. She reports right-sided discomfort on deep inspiration and reduced appetite. There is no recent hospital admission or known aspiration event.",
    background: ["Type 2 diabetes mellitus treated with oral medication", "No known chronic lung disease", "No recent hospitalisation or antibiotic exposure", "No known drug allergies"],
    examination: ["Febrile and mildly breathless while speaking", "Crackles over the right lower posterior chest", "Bronchial breath sounds and dullness to percussion at the right base", "No peripheral oedema"],
    vitals: [
      { label: "Heart rate", value: "112", flag: "High" },
      { label: "Blood pressure", value: "112/70", flag: "Stable" },
      { label: "Respiratory rate", value: "26", flag: "High" },
      { label: "Temperature", value: "38.6", flag: "High" },
      { label: "Oxygen saturation", value: "92", flag: "Low" }
    ],
    investigations: [
      { id: "vitals", name: "Vitals", category: "Bedside", relevance: "Assess severity, oxygenation and physiological instability.", result: "HR 112/min; BP 112/70 mmHg; RR 26/min; Temp 38.6 °C; SpO₂ 92% on room air.", interpretation: "Fever, tachycardia, tachypnoea and mild hypoxaemia indicate a significant acute respiratory infection requiring severity assessment.", useful: true },
      { id: "cxr", name: "Chest X-ray", category: "Imaging", relevance: "Confirms a suspected pulmonary infiltrate and assesses extent or complications.", result: "Right lower-lobe air-space opacity with air bronchograms; no large pleural effusion.", interpretation: "A focal lobar opacity with air bronchograms supports consolidation in the clinical context.", useful: true },
      { id: "cbc", name: "Complete blood count", category: "Blood", relevance: "Assesses inflammatory response and provides baseline haematology.", result: "WBC 15,800 with neutrophil predominance; Hb 12.4; platelets 310,000", units: "/µL; g/dL; /µL", reference: "WBC approximately 4,000–11,000/µL", interpretation: "Neutrophilic leukocytosis supports an acute bacterial inflammatory process but is not organism-specific.", useful: true },
      { id: "crp", name: "C-reactive protein", category: "Blood", relevance: "Can support assessment of inflammation; interpret with clinical findings.", result: "Elevated at 126", units: "mg/L", reference: "Usually <5 mg/L (laboratory-dependent)", interpretation: "Raised CRP supports significant inflammation but cannot independently diagnose bacterial pneumonia or identify its organism.", useful: true },
      { id: "culture", name: "Sputum culture", category: "Microbiology", relevance: "May identify an organism in selected patients, especially severe disease or treatment failure; obtain before antibiotics when feasible without delaying treatment.", result: "Good-quality sputum sample: predominant Streptococcus pneumoniae growth in this teaching case.", interpretation: "The result supports pneumococcal pneumonia in this constructed case; culture results must be interpreted with sample quality and clinical context.", useful: true },
      { id: "abg", name: "Arterial blood gas", category: "Blood", relevance: "Consider if respiratory distress, worsening hypoxaemia or concern for ventilatory failure.", result: "pH 7.46; PaCO₂ 32 mmHg; PaO₂ 66 mmHg; HCO₃⁻ 22 mmol/L", units: "pH; mmHg; mmHg; mmol/L", reference: "PaO₂ and PaCO₂ depend on age and altitude; pH 7.35–7.45", interpretation: "Mild hypoxaemia with low PaCO₂ is compatible with tachypnoea and respiratory alkalosis. Use clinical severity to guide escalation.", useful: true },
      { id: "urine", name: "Urine examination", category: "Urine", relevance: "Not routinely required to diagnose uncomplicated pneumonia; investigate only if another indication exists.", result: "No pyuria or nitrites.", interpretation: "Does not contribute materially to the respiratory diagnosis in this presentation.", useful: false }
    ],
    diagnosisOptions: ["Community-acquired right lower-lobe pneumonia", "Acute pulmonary oedema", "Pulmonary tuberculosis", "Acute asthma exacerbation", "Pulmonary embolism"],
    correctDiagnosis: "Community-acquired right lower-lobe pneumonia",
    mechanismOptions: [
      "Inhaled or aspirated pathogen reaches alveoli, triggering neutrophilic inflammation and alveolar exudate",
      "Left ventricular failure raises pulmonary venous pressure and causes hydrostatic alveolar oedema",
      "Reversible bronchial smooth-muscle constriction causes episodic airflow obstruction",
      "A thrombus obstructs pulmonary arterial blood flow and creates ventilation-perfusion mismatch"
    ],
    correctMechanism: "Inhaled or aspirated pathogen reaches alveoli, triggering neutrophilic inflammation and alveolar exudate",
    differentials: [
      { name: "Acute pulmonary oedema", whyNot: "Often produces bilateral interstitial or alveolar opacities and signs of volume overload; this case has focal lobar consolidation and fever." },
      { name: "Pulmonary tuberculosis", whyNot: "Usually has a more subacute course and characteristic epidemiological/radiographic context; the acute lobar presentation favours community-acquired pneumonia." },
      { name: "Asthma exacerbation", whyNot: "Would more typically feature wheeze and airflow obstruction rather than focal bronchial breathing and lobar opacity." },
      { name: "Pulmonary embolism", whyNot: "Can cause pleuritic pain and hypoxaemia, but fever, neutrophilia and focal air-space consolidation support pneumonia." }
    ],
    managementOptions: [
      { id: "severity", label: "Assess pneumonia severity, comorbidities and need for hospital-level care", detail: "Use clinical judgement and an appropriate validated severity tool; age, hypoxaemia and comorbidity matter." },
      { id: "oxygen", label: "Assess oxygen requirement and provide titrated oxygen if indicated", detail: "Oxygen should be titrated to an appropriate target based on the patient's context and local guidance." },
      { id: "antibiotic", label: "Start empiric community-acquired pneumonia antibiotics according to local guidance, then tailor to results", detail: "Regimen depends on severity, allergies, comorbidities, resistance patterns and local protocol." },
      { id: "fluids", label: "Assess hydration and provide appropriate oral or IV fluids", detail: "Supportive care should account for cardiac/renal status and volume tolerance." },
      { id: "cultures", label: "Obtain indicated microbiology samples without delaying necessary antibiotics", detail: "Microbiology is selected according to severity and risk factors; avoid indiscriminate testing." },
      { id: "steroids", label: "Give systemic corticosteroids routinely to every patient with pneumonia", detail: "Not routine for all community-acquired pneumonia; use only for a separate indication or according to selected severe-disease protocols." }
    ],
    correctManagement: ["severity", "oxygen", "antibiotic", "fluids", "cultures"],
    explanation: "The acute febrile illness, productive cough, focal bronchial breathing and right lower-lobe air-space opacity support community-acquired pneumonia. Hypoxaemia and age make severity assessment and disposition important.",
    pathophysiology: "Pathogens reach distal airways and alveoli, activating resident macrophages and inflammatory signalling. Neutrophils, protein-rich exudate and fluid accumulate in alveoli, causing consolidation and impaired gas exchange. Ventilation-perfusion mismatch produces hypoxaemia.",
    learningObjectives: [
      "Recognize focal consolidation clinically and radiographically.",
      "Explain how alveolar exudate impairs gas exchange.",
      "Assess severity and oxygenation in an older adult with pneumonia.",
      "Use microbiology selectively and interpret culture results in context.",
      "Apply antibiotic stewardship and local empiric treatment guidance."
    ]
  },
  {
    id: "mq-opd-004",
    title: "Pain in the Right Lower Quadrant",
    difficulty: "Medium",
    subjectTags: ["Anatomy", "Pathology", "Physiology"],
    topicTags: ["Abdomen", "Gastrointestinal pathology", "Gastrointestinal physiology"],
    supportingConcepts: ["Visceral and parietal pain", "Peritoneal inflammation", "Embryological midgut rotation", "Inflammation and repair", "Cell injury and adaptation"],
    patient: { age: 21, sex: "Male", name: "Arjun P.", portrait: "/portraits/young-man.png" },
    complaint: "Abdominal pain that has moved to the right lower abdomen over 14 hours",
    hopi: "A 21-year-old man describes vague central abdominal pain that began around the umbilicus and later localized to the right lower quadrant. He has nausea, reduced appetite and one episode of vomiting. He reports no diarrhoea, urinary symptoms or previous similar episodes.",
    background: ["Previously well", "No previous abdominal surgery", "No regular medication", "No known drug allergies"],
    examination: ["Prefers to lie still", "Right lower-quadrant tenderness maximal near McBurney point", "Localized guarding and rebound tenderness", "Bowel sounds present"],
    vitals: [
      { label: "Heart rate", value: "102", flag: "High" },
      { label: "Blood pressure", value: "118/76", flag: "Stable" },
      { label: "Respiratory rate", value: "20", flag: "Normal" },
      { label: "Temperature", value: "38.0", flag: "High" },
      { label: "Oxygen saturation", value: "99", flag: "Normal" }
    ],
    investigations: [
      { id: "vitals", name: "Vitals", category: "Bedside", relevance: "Assess systemic response and identify physiological instability.", result: "HR 102/min; BP 118/76 mmHg; RR 20/min; Temp 38.0 °C; SpO₂ 99%.", interpretation: "Low-grade fever and tachycardia are compatible with acute inflammation; monitor for progression or sepsis.", useful: true },
      { id: "cbc", name: "Complete blood count", category: "Blood", relevance: "Assess inflammatory response and baseline haemoglobin/platelets.", result: "WBC 14,600 with neutrophilia; Hb 14.0; platelets 270,000", units: "/µL; g/dL; /µL", reference: "WBC approximately 4,000–11,000/µL", interpretation: "Neutrophilic leukocytosis supports an acute inflammatory process but is not diagnostic alone.", useful: true },
      { id: "crp", name: "C-reactive protein", category: "Blood", relevance: "Can support inflammatory assessment and may help with risk stratification.", result: "Elevated at 38", units: "mg/L", reference: "Usually <5 mg/L (laboratory-dependent)", interpretation: "Raised CRP is consistent with inflammation but must be interpreted alongside the clinical picture.", useful: true },
      { id: "urine", name: "Urine examination", category: "Urine", relevance: "Helps assess urinary mimics such as infection or stone disease.", result: "No nitrites; no significant pyuria; trace ketones.", interpretation: "No strong dipstick evidence of urinary infection. A normal urine result does not exclude all urinary pathology.", useful: true },
      { id: "ultrasound", name: "Abdominal ultrasound", category: "Imaging", relevance: "Useful first-line imaging in selected patients and settings; operator and body-habitus dependent.", result: "Non-compressible blind-ending tubular structure in the right iliac fossa, 9 mm diameter, with surrounding echogenic fat.", interpretation: "Findings support acute appendicitis. Imaging should be integrated with examination and surgical assessment.", useful: true },
      { id: "ct", name: "CT abdomen and pelvis", category: "Imaging", relevance: "Consider when diagnosis remains uncertain or complications are suspected, balancing radiation and local pathways.", result: "Enlarged enhancing appendix with periappendiceal fat stranding; no drainable collection.", interpretation: "Supports uncomplicated acute appendicitis in this teaching case. CT is not automatically required when clinical/imaging pathway is already clear.", useful: false },
      { id: "ecg", name: "ECG", category: "Cardiac", relevance: "No routine indication in this otherwise typical young adult abdominal presentation.", result: "Sinus rhythm.", interpretation: "Does not contribute materially to the working diagnosis here.", useful: false }
    ],
    diagnosisOptions: ["Acute appendicitis", "Acute gastroenteritis", "Right ureteric calculus", "Mesenteric adenitis", "Crohn disease flare"],
    correctDiagnosis: "Acute appendicitis",
    mechanismOptions: [
      "Luminal obstruction followed by distension, venous congestion, bacterial proliferation and appendiceal inflammation",
      "Diffuse viral enterocyte injury causing increased intestinal secretion and diarrhoea",
      "Ureteric obstruction causing referred colicky pain and haematuria",
      "Chronic transmural granulomatous inflammation causing relapsing intestinal disease"
    ],
    correctMechanism: "Luminal obstruction followed by distension, venous congestion, bacterial proliferation and appendiceal inflammation",
    differentials: [
      { name: "Gastroenteritis", whyNot: "Usually features prominent diarrhoea and diffuse cramping rather than migration of pain with focal peritoneal signs." },
      { name: "Ureteric calculus", whyNot: "Often causes colicky flank-to-groin pain and may produce haematuria; this case has focal right iliac fossa peritonism." },
      { name: "Mesenteric adenitis", whyNot: "Can mimic appendicitis but is often associated with a recent viral illness; imaging here identifies an inflamed appendix." },
      { name: "Crohn disease flare", whyNot: "Usually has a more chronic/recurrent history, often with diarrhoea or weight loss." }
    ],
    managementOptions: [
      { id: "surgical", label: "Arrange prompt surgical assessment and definitive management planning", detail: "Suspected appendicitis with localized peritoneal signs warrants timely surgical review." },
      { id: "npo", label: "Keep nil by mouth while urgent assessment is underway", detail: "Appropriate when operative intervention may be required; follow local perioperative guidance." },
      { id: "analgesia", label: "Provide appropriate analgesia and antiemetic treatment", detail: "Do not withhold analgesia to preserve examination findings." },
      { id: "fluids", label: "Assess hydration and provide IV fluids if clinically indicated", detail: "Correct dehydration and monitor observations." },
      { id: "antibiotics", label: "Use perioperative antibiotics according to local surgical protocol", detail: "Antibiotic choice and timing depend on operative plan, allergy history and local guidance." },
      { id: "discharge", label: "Discharge without review because pain began near the umbilicus", detail: "Unsafe with focal tenderness, guarding, fever and imaging consistent with appendicitis." }
    ],
    correctManagement: ["surgical", "npo", "analgesia", "fluids", "antibiotics"],
    explanation: "Migration of periumbilical pain to the right lower quadrant, anorexia, fever, localized guarding and supportive imaging are characteristic of acute appendicitis. Prompt surgical assessment is required.",
    pathophysiology: "Appendiceal luminal obstruction, often by a faecolith or lymphoid hyperplasia, increases intraluminal pressure. Venous and lymphatic drainage become impaired, followed by bacterial proliferation, inflammation and potentially ischaemia or perforation. Early visceral afferent pain is poorly localized near the umbilicus; later parietal peritoneal irritation localizes pain to the right lower quadrant.",
    learningObjectives: [
      "Explain migration of pain from periumbilical region to the right iliac fossa.",
      "Relate appendiceal anatomy and visceral/parietal innervation to clinical findings.",
      "Interpret supportive ultrasound findings in suspected appendicitis.",
      "Recognize guarding and rebound as signs of localized peritoneal irritation.",
      "Prioritize surgical assessment, analgesia and appropriate supportive care."
    ]
  },
  {
    id: "mq-opd-005",
    title: "The Fatigue Nobody Noticed",
    difficulty: "Easy",
    subjectTags: ["Pathology", "Physiology", "Biochemistry"],
    topicTags: ["Hematopathology", "Blood", "Nutrition"],
    supportingConcepts: ["Iron absorption", "Haemoglobin synthesis", "Microcytosis", "Oxygen delivery", "Cell injury and adaptation"],
    patient: { age: 29, sex: "Female", name: "Nisha R.", portrait: "/portraits/middle-age-woman.png" },
    complaint: "Progressive tiredness, reduced exercise tolerance and hair shedding for three months",
    hopi: "A 29-year-old woman reports gradually worsening fatigue, occasional light-headedness on standing and reduced exercise tolerance over three months. She describes heavy menstrual bleeding for the first two days of each cycle. She has no fever, weight loss, black stools or visible gastrointestinal bleeding.",
    background: ["Mostly vegetarian diet", "Heavy menstrual bleeding for approximately one year", "No known chronic kidney or inflammatory disease", "No regular medication or known drug allergies"],
    examination: ["Pale conjunctivae", "Mild angular cheilitis", "Pulse mildly elevated on standing", "No jaundice, lymphadenopathy or hepatosplenomegaly"],
    vitals: [
      { label: "Heart rate", value: "96", flag: "High-normal" },
      { label: "Blood pressure", value: "112/72", flag: "Stable" },
      { label: "Respiratory rate", value: "18", flag: "Normal" },
      { label: "Temperature", value: "36.7", flag: "Normal" },
      { label: "Oxygen saturation", value: "99", flag: "Normal" }
    ],
    investigations: [
      { id: "vitals", name: "Vitals", category: "Bedside", relevance: "Assess haemodynamic response and orthostatic symptoms.", result: "HR 96/min; BP 112/72 mmHg; RR 18/min; Temp 36.7 °C; SpO₂ 99%.", interpretation: "Mild tachycardia may accompany anaemia; assess orthostatic observations if clinically indicated.", useful: true },
      { id: "cbc", name: "Complete blood count", category: "Blood", relevance: "Establish anaemia and assess red-cell indices and other cell lines.", result: "Hb 8.9; MCV 68; MCH 21; RDW increased; WBC 7,200; platelets 420,000", units: "g/dL; fL; pg; /µL; /µL", reference: "Hb adult female commonly 12–16 g/dL; MCV 80–100 fL", interpretation: "Microcytic, hypochromic anaemia with increased RDW is compatible with iron deficiency, but iron studies are needed to confirm the cause.", useful: true },
      { id: "iron", name: "Iron studies", category: "Blood", relevance: "Differentiate iron deficiency from other causes of microcytosis.", result: "Ferritin 5; serum iron low; TIBC elevated; transferrin saturation 6%", units: "µg/L; laboratory-specific", reference: "Ferritin reference ranges vary; low ferritin strongly supports depleted iron stores", interpretation: "Low ferritin and transferrin saturation with increased TIBC support iron deficiency anaemia.", useful: true },
      { id: "smear", name: "Peripheral blood smear", category: "Haematology", relevance: "Characterizes red-cell morphology and helps assess alternative haematological causes.", result: "Microcytosis, hypochromia and anisopoikilocytosis; no blasts reported.", interpretation: "Morphology supports iron deficiency in the context of the iron studies; smear alone is not definitive.", useful: true },
      { id: "retic", name: "Reticulocyte count", category: "Blood", relevance: "Assesses marrow response and can be useful in baseline evaluation or follow-up.", result: "Low-normal reticulocyte response for degree of anaemia.", interpretation: "An inappropriately modest response is compatible with limited substrate for erythropoiesis.", useful: true },
      { id: "b12", name: "Vitamin B12 and folate", category: "Blood", relevance: "Consider if mixed indices, macrocytosis, neurological symptoms or dietary risk suggest deficiency.", result: "Vitamin B12 and folate within laboratory reference ranges.", interpretation: "No deficiency is demonstrated in this teaching case; routine testing should be guided by clinical context.", useful: false },
      { id: "stool", name: "Stool occult blood", category: "Other", relevance: "May be considered in selected contexts, but does not replace evaluation of the source of iron deficiency.", result: "Negative on this sample.", interpretation: "A negative result does not exclude gastrointestinal blood loss. Menstrual history and other risk factors still require appropriate evaluation.", useful: false }
    ],
    diagnosisOptions: ["Iron deficiency anaemia due to chronic menstrual blood loss", "Beta-thalassaemia trait", "Anaemia of chronic inflammation", "Vitamin B12 deficiency", "Aplastic anaemia"],
    correctDiagnosis: "Iron deficiency anaemia due to chronic menstrual blood loss",
    mechanismOptions: [
      "Chronic iron loss depletes iron stores, limiting haem synthesis and producing microcytic hypochromic erythrocytes",
      "Reduced globin-chain synthesis causes inherited microcytosis despite adequate iron stores",
      "Inflammation increases hepcidin, restricting iron availability and trapping iron in storage sites",
      "Vitamin B12 deficiency impairs DNA synthesis and causes megaloblastic erythropoiesis"
    ],
    correctMechanism: "Chronic iron loss depletes iron stores, limiting haem synthesis and producing microcytic hypochromic erythrocytes",
    differentials: [
      { name: "Beta-thalassaemia trait", whyNot: "Can cause microcytosis, but ferritin is generally not depleted unless coexisting iron deficiency is present; iron studies here support iron deficiency." },
      { name: "Anaemia of chronic inflammation", whyNot: "Often has normal or increased ferritin with low serum iron and low/normal TIBC; there is no chronic inflammatory condition provided." },
      { name: "Vitamin B12 deficiency", whyNot: "Typically causes macrocytosis and may cause neurological findings; indices here are microcytic." },
      { name: "Aplastic anaemia", whyNot: "Usually causes pancytopenia rather than isolated microcytic anaemia with depleted iron stores." }
    ],
    managementOptions: [
      { id: "source", label: "Evaluate and address the cause of heavy menstrual bleeding", detail: "Treating iron deficiency without addressing ongoing blood loss risks recurrence; arrange appropriate gynaecological assessment." },
      { id: "iron", label: "Begin appropriate iron replacement and counsel on administration and follow-up", detail: "Oral iron is commonly used when appropriate; formulation, schedule and tolerance should be individualized." },
      { id: "diet", label: "Discuss iron-rich foods and dietary factors that affect iron absorption", detail: "Dietary advice supports but may not replace iron therapy in established deficiency." },
      { id: "monitor", label: "Recheck haemoglobin and iron response at an appropriate interval", detail: "Document response and continue replacement long enough to replenish stores, guided by clinical follow-up." },
      { id: "transfusion", label: "Transfuse red cells immediately solely because Hb is 8.9 g/dL in this stable patient", detail: "Transfusion is not determined by haemoglobin alone; assess symptoms, haemodynamic status, comorbidities and local thresholds." },
      { id: "ignore", label: "Ignore menstrual blood loss because the ferritin confirms the diagnosis", detail: "Unsafe reasoning: the underlying source of iron loss must be assessed and managed." }
    ],
    correctManagement: ["source", "iron", "diet", "monitor"],
    explanation: "The microcytic, hypochromic blood picture and depleted ferritin with low transferrin saturation support iron deficiency anaemia. Heavy menstrual bleeding is a plausible ongoing source and needs assessment rather than assuming dietary intake is the only cause.",
    pathophysiology: "Iron is required for haem synthesis. Chronic loss progressively depletes storage iron, reducing iron available to developing erythroblasts. Haemoglobin synthesis becomes limited, producing smaller red cells with reduced haemoglobin content. Reduced oxygen-carrying capacity contributes to fatigue, pallor and reduced exercise tolerance.",
    learningObjectives: [
      "Interpret MCV, MCH, RDW and iron studies in microcytic anaemia.",
      "Differentiate iron deficiency from thalassaemia trait and anaemia of inflammation.",
      "Explain the role of iron in haemoglobin synthesis.",
      "Investigate and address ongoing blood loss in iron deficiency.",
      "Plan iron replacement and objective follow-up."
    ]
  }
];
