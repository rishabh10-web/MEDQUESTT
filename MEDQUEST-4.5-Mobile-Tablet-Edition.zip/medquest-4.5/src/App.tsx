import { useEffect, useMemo, useState } from "react";
import {
  Activity, BookOpen, Brain, Check, ChevronDown, ChevronRight, ClipboardCheck,
  ClipboardList, HeartPulse, Plus, Save, Settings, SlidersHorizontal, Sparkles,
  Stethoscope, TestTube2, Trash2, Trophy, UserRound, X, AlertTriangle, ArrowLeft,
  FileText, ShieldCheck, Droplets, Search
} from "lucide-react";
import { makeInitialTree, mergeTopicTree, readStore, writeStore, SUBJECTS, slug, CASES, type TopicTree, type Case, type Investigation } from "./data";

type Page = "OPD" | "Emergency" | "Study" | "Progress" | "Settings";
type Preset = { id: string; name: string; subject: string; system: string; topics: string[]; mode: string; difficulty: string };
type Config = { subject: string; system: string; topics: string[]; mode: string; difficulty: string };
type Stage = "presentation" | "investigations" | "diagnosis" | "management" | "review";
const initialConfig: Config = { subject: "Pathology", system: "Systemic pathology", topics: [], mode: "OPD", difficulty: "Medium" };
const NAV: { name: Page; icon: typeof Stethoscope; sub: string }[] = [
  { name: "OPD", icon: Stethoscope, sub: "Outpatient encounters" },
  { name: "Emergency", icon: HeartPulse, sub: "Time-critical scenarios" },
  { name: "Study", icon: BookOpen, sub: "Topic-based sessions" },
  { name: "Progress", icon: Trophy, sub: "Your clinical journey" },
  { name: "Settings", icon: Settings, sub: "Game preferences" }
];
type CaseOutcome = { caseId: string; title: string; score: number; diagnosisCorrect: boolean; mechanismCorrect: boolean; managementScore: number; subjects: string[]; topics: string[]; completedAt: string; investigationsAppropriate?: boolean; perfectCase?: boolean; difficulty?: string };
type Achievement = { id: string; title: string; description: string; icon: string; requirement: string; unlocked: (rows: CaseOutcome[]) => boolean };
const ACHIEVEMENTS: Achievement[] = [
  { id: "first-steps", title: "First Steps", description: "Complete your first clinical case.", icon: "✦", requirement: "Complete 1 case", unlocked: rows => rows.length >= 1 },
  { id: "diagnostician", title: "Diagnostician", description: "Get ten final diagnoses correct.", icon: "⚕", requirement: "10 correct diagnoses", unlocked: rows => rows.filter(r => r.diagnosisCorrect).length >= 10 },
  { id: "sharp-eye", title: "Sharp Eye", description: "Achieve five correct diagnoses consecutively.", icon: "◉", requirement: "5 correct in a row", unlocked: rows => { let streak = 0; for (const r of rows) { streak = r.diagnosisCorrect ? streak + 1 : 0; if (streak >= 5) return true; } return false; } },
  { id: "investigator", title: "Investigator", description: "Choose only appropriate investigations in ten cases.", icon: "⌕", requirement: "10 appropriate investigation sets", unlocked: rows => rows.filter(r => r.investigationsAppropriate).length >= 10 },
  { id: "clinical-veteran", title: "Clinical Veteran", description: "Complete fifty unique clinical cases.", icon: "★", requirement: "Complete 50 cases", unlocked: rows => rows.length >= 50 },
  { id: "perfectionist", title: "Perfectionist", description: "Complete a case with every scored decision correct.", icon: "◆", requirement: "1 perfect case", unlocked: rows => rows.some(r => r.perfectCase) },
  { id: "pathology-pro", title: "Pathology Pro", description: "Build consistent performance across Pathology cases.", icon: "✚", requirement: "80% mastery across 3 Pathology cases", unlocked: rows => { const linked = rows.filter(r => r.subjects.includes("Pathology")); return linked.length >= 3 && linked.reduce((sum, r) => sum + masteryScore(r), 0) / linked.length >= 80; } },
  { id: "daily-scholar", title: "Daily Scholar", description: "Maintain a week-long clinical learning streak.", icon: "☀", requirement: "7 daily challenges in a row", unlocked: () => false },
];
type PlayerProfile = { name: string; totalXp: number; rewardedCaseIds: string[] };
type Customization = { playerName: string; title: string; avatar: string; frame: string; banner: string; unlocked: string[] };
type AudioPrefs = { sfxOn: boolean; sfxVolume: number; musicOn: boolean; musicVolume: number };
const initialCustomization: Customization = { playerName: "MEDQUEST PLAYER", title: "Intern", avatar: "alex-morgan", frame: "standard", banner: "mint", unlocked: ["standard","mint","alex-morgan"] };
const initialAudio: AudioPrefs = { sfxOn: true, sfxVolume: 55, musicOn: true, musicVolume: 22 };
const cosmeticCatalog = {
  frames: [{id:"standard",name:"Standard frame",level:1},{id:"bronze",name:"Bronze frame",level:5},{id:"silver",name:"Silver frame",level:12},{id:"goldframe",name:"Gold frame",level:25},{id:"master",name:"Master frame",level:40}],
  banners: [{id:"mint",name:"Mint terminal",level:1},{id:"dusk",name:"Dusk ward",level:7},{id:"aurora",name:"Aurora grid",level:18},{id:"royal",name:"Royal rounds",level:30}]
};
const avatarCatalog = [
  {id:"alex-morgan",name:"Alex Morgan",role:"Medical intern",story:"A curious new intern who believes every patient has a story worth hearing.\nDetermined to become the kind of doctor people remember for listening.",image:"/avatars/alex-morgan.png"},
  {id:"maya-patel",name:"Maya Patel",role:"Medical intern",story:"Bright, composed and endlessly observant, Maya notices the details others miss.\nShe hopes to bring thoughtful, compassionate care to every ward she enters.",image:"/avatars/maya-patel.png"},
  {id:"arthur-bennett",name:"Dr. Arthur Bennett",role:"Senior physician",story:"Decades at the bedside have taught Arthur that patience is as important as knowledge.\nHe now mentors young clinicians while taking on the cases others find difficult.",image:"/avatars/arthur-bennett.png"},
  {id:"nina-shah",name:"Nina Shah",role:"Surgical resident",story:"Calm under pressure, Nina has spent years earning her place in the operating theatre.\nHer precision is matched only by her determination to keep learning.",image:"/avatars/nina-shah.png"},
  {id:"leo-fernandez",name:"Leo Fernandez",role:"Medical resident",story:"Quick-thinking and hardworking, Leo thrives on challenging clinical puzzles.\nHe is learning that the best answers come from teamwork, not shortcuts.",image:"/avatars/leo-fernandez.png"},
  {id:"sara-chen",name:"Sara Chen",role:"Clinical researcher",story:"Sara is fascinated by the science behind every symptom and treatment.\nShe wants to connect research and bedside medicine to make care better for everyone.",image:"/avatars/sara-chen.png"}
];
const titles = [{name:"Intern",level:1},{name:"Resident",level:5},{name:"Registrar",level:12},{name:"Consultant",level:25},{name:"Clinical Legend",level:40}];
type DailyChallengeProgress = { completedDates: string[]; currentStreak: number; longestStreak: number; lastCompletedDate: string | null };
const initialDailyProgress: DailyChallengeProgress = { completedDates: [], currentStreak: 0, longestStreak: 0, lastCompletedDate: null };
const localDateKey = (date = new Date()) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
const dayOrdinal = (key: string) => { const [y,m,d] = key.split("-").map(Number); return Math.floor(Date.UTC(y,m-1,d) / 86400000); };
const dailyCaseFor = (key: string) => { const hash = [...key].reduce((n,ch) => (n * 31 + ch.charCodeAt(0)) >>> 0, 7); return CASES[hash % CASES.length]; };
const initialPlayerProfile: PlayerProfile = { name: "MEDQUEST PLAYER", totalXp: 0, rewardedCaseIds: [] };
const xpLevel = (totalXp: number) => Math.min(50, Math.floor(totalXp / 250) + 1);
const xpInLevel = (totalXp: number) => xpLevel(totalXp) === 50 ? Math.min(250, totalXp - 49 * 250) : totalXp % 250;
// Mastery is a learning signal based on the latest saved result for each unique case.
// It is deliberately separate from XP and is not a clinical-competence certification.
const masteryScore = (r: CaseOutcome) => Math.round(
  (r.diagnosisCorrect ? 35 : 0) +
  (r.mechanismCorrect ? 20 : 0) +
  (Math.max(0, Math.min(100, r.managementScore)) * 0.35) +
  (r.investigationsAppropriate ? 10 : 0)
);
const getCaseMatch = (selected: string[], tree: TopicTree, c: Case) => {
  const chosen = Object.values(tree).flatMap(s => Object.values(s).flat()).filter(t => selected.includes(t.id));
  const names = chosen.map(t => t.name.toLowerCase());
  const direct = c.topicTags.some(tag => names.includes(tag.toLowerCase()));
  const integrated = !direct && c.supportingConcepts.some(tag => names.includes(tag.toLowerCase()));
  const revision = chosen.some(t => t.status === "Revision" && (c.topicTags.some(tag => tag.toLowerCase() === t.name.toLowerCase()) || c.supportingConcepts.some(tag => tag.toLowerCase() === t.name.toLowerCase())));
  return direct ? { type: "DIRECT" as const, revision } : integrated ? { type: "INTEGRATED" as const, revision } : null;
};

export default function App() {
  const [page, setPage] = useState<Page>("Study");
  const [tree, setTree] = useState<TopicTree>(() => mergeTopicTree(readStore("mq-topics-v1", makeInitialTree())));
  const [presets, setPresets] = useState<Preset[]>(() => readStore("mq-presets-v1", []));
  const [config, setConfig] = useState<Config>(() => readStore("mq-config-v1", initialConfig));
  const [presetName, setPresetName] = useState("");
  const [notice, setNotice] = useState("");
  const [showPresetSave, setShowPresetSave] = useState(false);
  const [newTopic, setNewTopic] = useState("");
  const [newSystem, setNewSystem] = useState("");
  const [showTopicTools, setShowTopicTools] = useState(false);
  const [activeCase, setActiveCase] = useState<Case | null>(null);
  const [stage, setStage] = useState<Stage>("presentation");
  const [obtained, setObtained] = useState<string[]>([]);
  const [diagnosis, setDiagnosis] = useState("");
  const [mechanism, setMechanism] = useState("");
  const [management, setManagement] = useState<string[]>([]);
  const [caseScore, setCaseScore] = useState<{ diagnosis: boolean; mechanism: boolean; management: number } | null>(null);
  const [reviewedIds, setReviewedIds] = useState<string[]>(() => readStore("mq-reviewed-v1", []));
  const [caseResults, setCaseResults] = useState<CaseOutcome[]>(() => readStore("mq-case-results-v1", []));
  const [playerProfile, setPlayerProfile] = useState<PlayerProfile>(() => readStore("mq-player-profile-v1", initialPlayerProfile));
  const [unlockedAchievements, setUnlockedAchievements] = useState<string[]>(() => readStore("mq-achievements-v1", []));
  const [dailyProgress, setDailyProgress] = useState<DailyChallengeProgress>(() => readStore("mq-daily-challenge-v1", initialDailyProgress));
  const [dailyChallengeActive, setDailyChallengeActive] = useState(false);
  const [customization, setCustomization] = useState<Customization>(() => { const saved = readStore("mq-customization-v1", initialCustomization) as any; const legacyAvatar = ["doctor","doctor-f","pixel","casual"].includes(saved.avatar) ? "alex-morgan" : saved.avatar; return { ...initialCustomization, ...saved, avatar: avatarCatalog.some(a=>a.id===legacyAvatar) ? legacyAvatar : initialCustomization.avatar }; });
  const [audioPrefs, setAudioPrefs] = useState<AudioPrefs>(() => ({ ...initialAudio, ...readStore("mq-audio-v1", initialAudio) }));
  const [prioritizeRevision, setPrioritizeRevision] = useState<boolean>(() => readStore("mq-prioritize-revision-v1", false));

  useEffect(() => writeStore("mq-topics-v1", tree), [tree]);
  useEffect(() => writeStore("mq-presets-v1", presets), [presets]);
  useEffect(() => writeStore("mq-config-v1", config), [config]);
  useEffect(() => writeStore("mq-reviewed-v1", reviewedIds), [reviewedIds]);
  useEffect(() => writeStore("mq-case-results-v1", caseResults), [caseResults]);
  useEffect(() => writeStore("mq-player-profile-v1", playerProfile), [playerProfile]);
  useEffect(() => writeStore("mq-achievements-v1", unlockedAchievements), [unlockedAchievements]);
  useEffect(() => writeStore("mq-daily-challenge-v1", dailyProgress), [dailyProgress]);
  useEffect(() => writeStore("mq-prioritize-revision-v1", prioritizeRevision), [prioritizeRevision]);
  useEffect(() => writeStore("mq-customization-v1", customization), [customization]);
  useEffect(() => writeStore("mq-audio-v1", audioPrefs), [audioPrefs]);
  useEffect(() => { setCustomization(prev => ({ ...prev, playerName: prev.playerName || playerProfile.name || "MEDQUEST PLAYER" })); }, []);
  const currentLevel = xpLevel(playerProfile.totalXp);
  const earnedTitles = titles.filter(t => currentLevel >= t.level || unlockedAchievements.length >= 6);
  const unlockedCosmetics = Object.values(cosmeticCatalog).flat().filter(item => currentLevel >= item.level).map(item => item.id);
  useEffect(() => { setCustomization(prev => ({ ...prev, unlocked: [...new Set([...prev.unlocked, ...unlockedCosmetics])] })); }, [currentLevel]);
  function playSfx() {
    if (!audioPrefs.sfxOn || audioPrefs.sfxVolume <= 0) return;
    try { const Ctx = window.AudioContext || (window as any).webkitAudioContext; const ctx = new Ctx(); const osc = ctx.createOscillator(); const gain = ctx.createGain(); osc.type = "square"; osc.frequency.setValueAtTime(660, ctx.currentTime); osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + .07); gain.gain.setValueAtTime(audioPrefs.sfxVolume / 100 * .035, ctx.currentTime); gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + .11); osc.connect(gain); gain.connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime + .12); osc.onended = () => ctx.close(); } catch {}
  }
  useEffect(() => {
    const track = new Audio("/audio/main-menu.mp3");
    track.loop = true;
    track.volume = Math.max(0, Math.min(1, audioPrefs.musicVolume / 100));
    if (audioPrefs.musicOn && audioPrefs.musicVolume > 0) { void track.play().catch(() => { /* Browser autoplay policy: user can enable playback from Settings after interaction. */ }); }
    return () => { track.pause(); track.currentTime = 0; };
  }, [audioPrefs.musicOn, audioPrefs.musicVolume]);

  const todayKey = localDateKey();
  const dailyChallengeCase = dailyCaseFor(todayKey);
  const dailyChallengeCompleted = dailyProgress.completedDates.includes(todayKey);
  const yesterdayKey = localDateKey(new Date(Date.now() - 86400000));
  const visibleDailyStreak = dailyProgress.lastCompletedDate === todayKey || dailyProgress.lastCompletedDate === yesterdayKey ? dailyProgress.currentStreak : 0;
  const systems = Object.keys(tree[config.subject] || {});
  const topics = tree[config.subject]?.[config.system] || [];
  const selectedTopics = useMemo(() => Object.values(tree).flatMap(s => Object.values(s)).flat().filter(t => config.topics.includes(t.id)), [tree, config.topics]);
  const activeTopicCount = Object.values(tree).flatMap(s => Object.values(s)).flat().filter(t => t.status !== "Completed").length;
  const caseMatches = CASES.map(c => ({ caseData: c, match: getCaseMatch(config.topics, tree, c) }))
    .filter(x => {
      if (!x.match) return false;
      // A named organ-system queue must never leak cases from another organ system.
      if (config.system === "Renal system" && !x.caseData.id.startsWith("mq-renal-")) return false;
      if (config.system === "Gastrointestinal system" && !x.caseData.id.startsWith("mq-git-")) return false;
      if (config.system === "Hematology system" && !x.caseData.id.startsWith("mq-hema-")) return false;
      return x.caseData.difficulty === config.difficulty;
    })
    .sort((a, b) => {
      const rank = (x: typeof a) => (x.match?.type === "DIRECT" ? 0 : 1) + (prioritizeRevision && x.match?.revision ? -0.2 : 0) + (x.caseData.difficulty === config.difficulty ? 0 : 0.05);
      return rank(a) - rank(b) || a.caseData.title.localeCompare(b.caseData.title);
    });
  const matchedCases = caseMatches.map(x => x.caseData);
  const topicMastery = Object.entries(tree).flatMap(([subject, systems]) =>
    Object.entries(systems).flatMap(([system, rows]) => rows.map(topic => {
      const attempts = caseResults.filter(r => r.topics.some(tag => tag.toLowerCase() === topic.name.toLowerCase()));
      return { id: topic.id, subject, system, name: topic.name, status: topic.status, attempts: attempts.length,
        score: attempts.length ? Math.round(attempts.reduce((sum, r) => sum + masteryScore(r), 0) / attempts.length) : null };
    }))
  );
  const subjectMastery = SUBJECTS.map(subject => {
    const rows = caseResults.filter(r => r.subjects.includes(subject));
    return { subject, attempts: rows.length, score: rows.length ? Math.round(rows.reduce((sum, r) => sum + masteryScore(r), 0) / rows.length) : null };
  });
  const revisionSuggestions = topicMastery.filter(t => t.score !== null && t.score < 60);
  const obtainedInvestigations = activeCase?.investigations.filter(i => obtained.includes(i.id)) || [];
  const totalInvestigations = activeCase?.investigations.length || 0;

  function updateConfig<K extends keyof Config>(key: K, value: Config[K]) { setConfig(prev => ({ ...prev, [key]: value })); }
  function chooseSubject(subject: string) {
    const nextSystem = Object.keys(tree[subject] || {})[0] || "";
    setConfig(prev => ({ ...prev, subject, system: nextSystem, topics: [] }));
  }
  function toggleTopic(id: string) {
    setConfig(prev => ({ ...prev, topics: prev.topics.includes(id) ? prev.topics.filter(x => x !== id) : [...prev.topics, id] }));
  }
  function toast(message: string) { playSfx(); setNotice(message); window.setTimeout(() => setNotice(""), 2400); }
  function savePreset() {
    if (!presetName.trim() || !config.topics.length) return;
    setPresets(prev => [...prev, { ...config, id: crypto.randomUUID(), name: presetName.trim() }]);
    setPresetName(""); setShowPresetSave(false); toast("TOPIC PRESET SAVED");
  }
  function loadPreset(p: Preset) { setConfig({ subject: p.subject, system: p.system, topics: p.topics, mode: p.mode, difficulty: p.difficulty }); toast(`LOADED: ${p.name.toUpperCase()}`); }
  function addTopic() {
    if (!newTopic.trim()) return;
    const id = `${slug(config.subject)}-${slug(config.system)}-${slug(newTopic)}-${Date.now()}`;
    setTree(prev => ({ ...prev, [config.subject]: { ...prev[config.subject], [config.system]: [...(prev[config.subject]?.[config.system] || []), { id, name: newTopic.trim(), status: "Active" }] } }));
    setNewTopic(""); toast("TOPIC ADDED");
  }
  function addSystem() {
    if (!newSystem.trim() || tree[config.subject]?.[newSystem.trim()]) return;
    const name = newSystem.trim();
    setTree(prev => ({ ...prev, [config.subject]: { ...prev[config.subject], [name]: [] } }));
    setConfig(prev => ({ ...prev, system: name, topics: [] })); setNewSystem(""); toast("SYSTEM ADDED");
  }
  function changeTopicStatus(id: string, status: "Active" | "Revision" | "Completed") {
    setTree(prev => ({ ...prev, [config.subject]: { ...prev[config.subject], [config.system]: prev[config.subject][config.system].map(t => t.id === id ? { ...t, status } : t) } }));
  }
  function setTopicStatusById(id: string, status: "Active" | "Revision" | "Completed") {
    setTree(prev => Object.fromEntries(Object.entries(prev).map(([subject, systems]) => [subject,
      Object.fromEntries(Object.entries(systems).map(([system, rows]) => [system, rows.map(t => t.id === id ? { ...t, status } : t)]))
    ])));
    toast(status === "Revision" ? "TOPIC ADDED TO REVISION" : "TOPIC STATUS UPDATED");
  }
  function deleteTopic(id: string) {
    setTree(prev => ({ ...prev, [config.subject]: { ...prev[config.subject], [config.system]: prev[config.subject][config.system].filter(t => t.id !== id) } }));
    setConfig(prev => ({ ...prev, topics: prev.topics.filter(x => x !== id) }));
  }
  function startCase(c: Case) {
    setDailyChallengeActive(false); setActiveCase(c); setObtained([]); setDiagnosis(""); setMechanism(""); setManagement([]); setCaseScore(null); setStage("presentation"); setPage("OPD");
  }
  function resetCase() { setDailyChallengeActive(false); setActiveCase(null); setStage("presentation"); setObtained([]); setDiagnosis(""); setMechanism(""); setManagement([]); setCaseScore(null); }
  function toggleInvestigation(id: string) {
    setObtained(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  }
  function submitDiagnosis() {
    if (!activeCase || !diagnosis || !mechanism) return;
    setStage("management");
  }
  function submitManagement() {
    if (!activeCase) return;
    const correct = activeCase.correctManagement;
    const correctSelected = management.filter(x => correct.includes(x)).length;
    const incorrectSelected = management.filter(x => !correct.includes(x)).length;
    const score = Math.max(0, Math.round((correctSelected / correct.length) * 100) - incorrectSelected * 15);
    const diagnosisCorrect = diagnosis === activeCase.correctDiagnosis;
    const mechanismCorrect = mechanism === activeCase.correctMechanism;
    const totalScore = Math.round(((diagnosisCorrect ? 1 : 0) + (mechanismCorrect ? 1 : 0) + score / 100) / 3 * 100);
    setCaseScore({ diagnosis: diagnosisCorrect, mechanism: mechanismCorrect, management: score });
    // Award progression XP once per unique case; replaying updates the learning record but cannot farm XP.
    setPlayerProfile(prev => {
      if (prev.rewardedCaseIds.includes(activeCase.id)) return prev;
      const selectedInvs = activeCase!.investigations.filter(i => obtained.includes(i.id));
      const investigationBonus = selectedInvs.length > 0 && selectedInvs.every(i => i.useful) ? 20 : 0;
      const managementBonus = score === 100 ? 30 : 0;
      const difficultyBonus = ["Hard", "Expert"].includes(activeCase!.difficulty) ? 20 : 0;
      const perfectBonus = diagnosisCorrect && mechanismCorrect && score === 100 && selectedInvs.every(i => i.useful) ? 20 : 0;
      const earned = 50 + (diagnosisCorrect ? 30 : 0) + investigationBonus + managementBonus + difficultyBonus + perfectBonus;
      return { ...prev, totalXp: prev.totalXp + earned, rewardedCaseIds: [...prev.rewardedCaseIds, activeCase!.id] };
    });
    if (dailyChallengeActive && activeCase.id === dailyChallengeCase.id && !dailyChallengeCompleted) {
      const previous = dailyProgress;
      const nextStreak = previous.lastCompletedDate === yesterdayKey ? previous.currentStreak + 1 : previous.lastCompletedDate === todayKey ? previous.currentStreak : 1;
      setDailyProgress({ completedDates: [...previous.completedDates, todayKey], currentStreak: nextStreak, longestStreak: Math.max(previous.longestStreak, nextStreak), lastCompletedDate: todayKey });
      if (nextStreak >= 7) setUnlockedAchievements(current => current.includes("daily-scholar") ? current : [...current, "daily-scholar"]);
      setPlayerProfile(prev => ({ ...prev, totalXp: prev.totalXp + 75 }));
      toast(`DAILY CHALLENGE COMPLETE · +75 XP · ${nextStreak}-DAY STREAK`);
      setDailyChallengeActive(false);
    }
    setStage("review");
    setReviewedIds(prev => prev.includes(activeCase.id) ? prev : [...prev, activeCase.id]);
    const selectedInvs = activeCase.investigations.filter(i => obtained.includes(i.id));
    const result: CaseOutcome = {
      caseId: activeCase.id, title: activeCase.title, score: totalScore,
      diagnosisCorrect, mechanismCorrect, managementScore: score,
      subjects: activeCase.subjectTags, topics: activeCase.topicTags, completedAt: new Date().toISOString(),
      investigationsAppropriate: selectedInvs.length > 0 && selectedInvs.every(i => i.useful),
      perfectCase: diagnosisCorrect && mechanismCorrect && score === 100 && selectedInvs.length > 0 && selectedInvs.every(i => i.useful),
      difficulty: activeCase.difficulty
    };
    setCaseResults(prev => {
      const next = [...prev.filter(r => r.caseId !== activeCase.id), result];
      const newlyUnlocked = ACHIEVEMENTS.filter(a => !unlockedAchievements.includes(a.id) && a.unlocked(next)).map(a => a.id);
      if (newlyUnlocked.length) {
        setUnlockedAchievements(current => [...new Set([...current, ...newlyUnlocked])]);
        const first = ACHIEVEMENTS.find(a => a.id === newlyUnlocked[0]);
        toast(`ACHIEVEMENT UNLOCKED: ${first?.title.toUpperCase()}`);
      }
      return next;
    });
  }
  const selectedCaseTopics = activeCase ? activeCase.topicTags.filter(tag => selectedTopics.some(t => t.name.toLowerCase() === tag.toLowerCase())) : [];
  const caseScoreTotal = caseScore ? Math.round(((caseScore.diagnosis ? 1 : 0) + (caseScore.mechanism ? 1 : 0) + caseScore.management / 100) / 3 * 100) : 0;

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand-lockup"><div className="brand-mark"><Plus size={23} strokeWidth={3}/></div><div><div className="brand-name">MEDQUEST<span> 4.4</span></div><div className="brand-tag">CLINICAL SIMULATION RPG</div></div></div>
      <div className="top-status"><span className="status-dot"/><span>LOCAL SAVE ACTIVE</span><span className="top-divider"/><span className="rank-chip"><Trophy size={13}/> INTERN // LVL {String(xpLevel(playerProfile.totalXp)).padStart(2, "0")}</span></div>
      <button className="mobile-settings" onClick={() => setPage("Settings")} aria-label="Settings"><Settings size={18}/></button>
    </header>
    <div className="layout">
      <aside className="sidebar">
        <div className="side-label">MAIN TERMINAL</div>
        <nav>{NAV.map(item => <button key={item.name} onClick={() => setPage(item.name)} className={`nav-item ${page === item.name ? "active" : ""}`}><item.icon size={18}/><span className="nav-copy"><b>{item.name}</b><small>{item.sub}</small></span>{page === item.name && <ChevronRight size={16} className="nav-arrow"/>}</button>)}</nav>
        <div className="sidebar-bottom"><div className="side-label">FIELD STATUS</div><div className="status-card"><div className="status-card-top"><span className="pixel-heart">♥</span><span>TRAINING ACTIVE</span></div><div className="status-stat"><span>Topics in syllabus</span><b>{activeTopicCount}</b></div><div className="status-stat"><span>Saved presets</span><b>{presets.length}</b></div><div className="status-stat"><span>Cases reviewed</span><b>{reviewedIds.length}</b></div><div className="status-stat"><span>Player XP</span><b>{playerProfile.totalXp.toLocaleString()}</b></div><div className="status-line"><i/></div><small>YOUR PROGRESS IS SAVED ON THIS DEVICE</small></div><div className="build-tag">BUILD 4.4.0 // HEMATOLOGY EXPANSION</div></div>
      </aside>
      <main className="main-content">
        <div className="page-heading"><div><div className="eyebrow">MEDICAL TRAINING NETWORK <span>///</span> {page.toUpperCase()}</div><h1>{page === "Study" ? "Prepare your session" : page === "OPD" ? activeCase ? activeCase.title : "Outpatient department" : page === "Emergency" ? "Emergency bay" : page === "Progress" ? "Your progress" : "System settings"}</h1><p>{page === "Study" ? "Choose topics, difficulty and save reusable study presets. Select individual cases in OPD." : page === "OPD" ? activeCase ? "A clinical encounter. Review the evidence, then make your decisions." : "Choose a topic-matched encounter to begin." : page === "Emergency" ? "Time-critical simulations are scheduled for Milestone 4." : page === "Progress" ? "Your reviewed encounters and learning record." : "Manage your local MEDQUEST experience."}</p></div><div className="date-stamp"><span>SESSION TERMINAL</span><b>MQ // 004</b></div></div>

        {page === "Study" && <div className="study-grid">
          <section className="panel topic-panel">
            <div className="panel-head"><div className="panel-title"><span className="section-icon"><ClipboardList size={17}/></span><div><h2>01 / TOPIC SELECTION</h2><small>BUILD YOUR LEARNING QUEUE</small></div></div><span className="step-indicator">STEP 01—03</span></div>
            <div className="selection-flow">
              <div className="field-block"><label><span>01</span> SELECT SUBJECT</label><div className="subject-grid">{SUBJECTS.map(s => <button key={s} onClick={() => chooseSubject(s)} className={`subject-option ${config.subject === s ? "chosen" : ""}`}>{s}{config.subject === s && <Check size={14}/>}</button>)}</div></div>
              <div className="field-block"><label><span>02</span> SELECT SYSTEM</label><div className="select-wrap"><select value={config.system} onChange={e => { updateConfig("system", e.target.value); updateConfig("topics", []); }}>{systems.map(s => <option key={s}>{s}</option>)}</select><ChevronDown size={16}/></div></div>
              <div className="field-block"><div className="label-row"><label><span>03</span> SELECT TOPICS <em>MULTI-SELECT ENABLED</em></label><button className="text-action" onClick={() => setShowTopicTools(!showTopicTools)}><SlidersHorizontal size={13}/> MANAGE TOPICS</button></div>
                <div className="topic-list">{topics.map(t => <div key={t.id} className={`topic-row ${config.topics.includes(t.id) ? "topic-selected" : ""}`}><button className="topic-pick" onClick={() => toggleTopic(t.id)}><span className="checkbox">{config.topics.includes(t.id) && <Check size={12}/>}</span><span>{t.name}</span></button><span className={`topic-status ${t.status.toLowerCase()}`}>{t.status}</span>{showTopicTools && <div className="topic-tools"><select aria-label={`Status for ${t.name}`} value={t.status} onChange={e => changeTopicStatus(t.id, e.target.value as "Active" | "Revision" | "Completed")}><option>Active</option><option>Revision</option><option>Completed</option></select><button title="Delete topic" onClick={() => deleteTopic(t.id)}><Trash2 size={13}/></button></div>}</div>)}
                {topics.length === 0 && <div className="empty-topics">NO TOPICS IN THIS SYSTEM YET. ADD ONE BELOW.</div>}</div>
                {showTopicTools && <div className="topic-manager"><div className="manager-title">TOPIC MANAGER <span>LOCAL SYLLABUS</span></div><div className="add-row"><input value={newTopic} onChange={e => setNewTopic(e.target.value)} onKeyDown={e => e.key === "Enter" && addTopic()} placeholder="Add a topic to this system"/><button onClick={addTopic} disabled={!newTopic.trim()}><Plus size={15}/> ADD</button></div><div className="add-row"><input value={newSystem} onChange={e => setNewSystem(e.target.value)} onKeyDown={e => e.key === "Enter" && addSystem()} placeholder="Add a new system"/><button onClick={addSystem} disabled={!newSystem.trim()}><Plus size={15}/> SYSTEM</button></div></div>}
                <div className="topic-footer"><span>{config.topics.length} TOPIC{config.topics.length === 1 ? "" : "S"} SELECTED</span><button onClick={() => updateConfig("topics", topics.filter(t => t.status !== "Completed").map(t => t.id))}>SELECT ALL ACTIVE</button><button onClick={() => updateConfig("topics", [])}>CLEAR</button></div>
                <label className="revision-toggle"><input type="checkbox" checked={prioritizeRevision} onChange={e => setPrioritizeRevision(e.target.checked)}/><span><b>Prioritise revision topics</b><small>Move cases linked to topics marked Revision higher in the queue.</small></span></label>
              </div>
            </div>
            <div className="panel-bottom"><div className="selected-summary"><div className="summary-icon"><Brain size={18}/></div><div><b>{config.topics.length ? `${config.topics.length} TOPIC${config.topics.length > 1 ? "S" : ""} QUEUED` : "YOUR LEARNING QUEUE IS EMPTY"}</b><small>{config.topics.length ? selectedTopics.map(t => t.name).join(" · ") : "Select one or more topics to configure a session."}</small></div></div><button className="outline-button" disabled={!config.topics.length} onClick={() => setShowPresetSave(true)}><Save size={15}/> SAVE PRESET</button></div>
          </section>
          <section className="right-column">
            <div className="panel config-panel"><div className="panel-head"><div className="panel-title"><span className="section-icon amber"><SlidersHorizontal size={17}/></span><div><h2>02 / SESSION CONFIG</h2><small>DEFINE YOUR ENCOUNTER</small></div></div></div>
              <div className="config-content"><div className="field-block"><label>SESSION MODE</label><div className="mode-grid">{["OPD", "Emergency", "Mixed"].map(m => <button key={m} className={config.mode === m ? "mode-option selected" : "mode-option"} onClick={() => updateConfig("mode", m)}>{m === "OPD" ? <Stethoscope size={17}/> : m === "Emergency" ? <HeartPulse size={17}/> : <Activity size={17}/>}<span>{m}</span></button>)}</div></div>
                <div className="field-block"><label>DIFFICULTY LEVEL</label><div className="difficulty-list">{["Easy", "Medium", "Hard", "Expert"].map((d, i) => <button key={d} onClick={() => updateConfig("difficulty", d)} className={`difficulty-option ${config.difficulty === d ? "selected" : ""}`}><span className={`difficulty-dot d${i}`}/>{d}<span className="difficulty-desc">{["FOUNDATION", "STANDARD", "CHALLENGING", "SPECIALIST"][i]}</span>{config.difficulty === d && <Check size={14}/>}</button>)}</div></div>
              </div><div className="config-foot"><span>CASE POOL</span><b>{matchedCases.length ? `${matchedCases.length} MATCHED CASES` : "NO CASE AT THIS LEVEL"}</b></div>
            </div>
            <div className="panel presets-panel"><div className="panel-head"><div className="panel-title"><span className="section-icon violet"><Save size={17}/></span><div><h2>03 / SAVED PRESETS</h2><small>REUSE YOUR LEARNING QUEUES</small></div></div><span className="count-pill">{presets.length}</span></div>
              {presets.length ? <div className="preset-list">{presets.map(p => <div className="preset-row" key={p.id}><button className="preset-load" onClick={() => loadPreset(p)}><span className="preset-symbol"><BookOpen size={15}/></span><span><b>{p.name}</b><small>{p.subject} / {p.topics.length} topics / {p.mode}</small></span><ChevronRight size={16}/></button><button className="preset-delete" title="Delete preset" onClick={() => setPresets(prev => prev.filter(x => x.id !== p.id))}><X size={14}/></button></div>)}</div> : <div className="preset-empty"><div className="empty-glyph">▤</div><b>NO PRESETS SAVED</b><small>Save a topic selection to access it here.</small></div>}
            </div>
            <div className="study-note panel"><div className="study-note-kicker">✦ FIELD GUIDE // STUDY QUEUE</div><b>YOUR STUDY QUEUE IS SAVED HERE</b><p>Choose topics and difficulty, then save them as a preset. Open OPD to browse and select the case you want to solve.</p></div>
          </section>
        </div>}

        {page === "OPD" && <section className="encounter-wrap">
          {!activeCase ? <div className="panel encounter-empty"><div className="placeholder-art"><Stethoscope size={42}/></div><div className="eyebrow">OPD // CASE SELECTOR</div><h2>CHOOSE A TOPIC-MATCHED ENCOUNTER</h2><p>Choose a saved study preset or topic selection in Study, then select any matching case here.</p>{caseMatches.map(({caseData:c,match}) => <button className="case-choice" key={c.id} onClick={() => startCase(c)}><span className="case-choice-icon"><img src={c.patient.portrait} alt="" /></span><span><b>{c.title}</b><small>{match?.type} MATCH · {c.difficulty} · {c.subjectTags.join(" / ")}</small></span>{(reviewedIds.includes(c.id) || caseResults.some(r=>r.caseId===c.id)) && <span className="case-completed-mark"><Check size={12}/> COMPLETED</span>}<ChevronRight size={17}/></button>)}{!matchedCases.length && <button className="outline-button" onClick={() => setPage("Study")}>GO TO TOPIC SELECTION</button>}</div>
          : <div className="encounter-layout">
            <div className="encounter-main">
              <div className="panel encounter-panel">
                <div className="encounter-top"><div><div className="eyebrow">OPD ENCOUNTER // {activeCase.id.toUpperCase()}</div><h2>{activeCase.title}</h2></div><span className="case-difficulty">{activeCase.difficulty.toUpperCase()}</span></div>
                <div className="stage-track">{(["presentation","investigations","diagnosis","management","review"] as Stage[]).map((s,i)=><div key={s} className={`stage-step ${stage===s?"current":(["presentation","investigations","diagnosis","management","review"].indexOf(stage)>i?"done":"")}`}><span>{i+1}</span><small>{s.toUpperCase()}</small></div>)}</div>
                {stage === "presentation" && <div className="case-content">
                  <div className="patient-card"><div className="patient-avatar"><img src={activeCase.patient.portrait} alt={`Portrait of ${activeCase.patient.name}`} /><span>OPD PATIENT</span></div><div className="patient-details"><div className="eyebrow">NEW PATIENT // OPD ARRIVAL</div><h3>{activeCase.patient.name}</h3><p>{activeCase.patient.age} years · {activeCase.patient.sex}</p><div className="complaint">“{activeCase.complaint}”</div></div></div>
                  <div className="case-section"><h3><FileText size={16}/> HISTORY OF PRESENT ILLNESS</h3><p>{activeCase.hopi}</p></div>
                  <div className="case-section"><h3><ClipboardList size={16}/> RELEVANT BACKGROUND</h3><ul>{activeCase.background.map(x=><li key={x}>{x}</li>)}</ul></div>
                  <div className="case-section"><h3><Activity size={16}/> EXAMINATION FINDINGS</h3><ul>{activeCase.examination.map(x=><li key={x}>{x}</li>)}</ul></div>
                  <div className="case-section"><h3><HeartPulse size={16}/> INITIAL VITALS</h3><div className="vitals-grid">{activeCase.vitals.map(v=><div className="vital-card" key={v.label}><small>{v.label}</small><b>{v.value}</b><em>{v.flag}</em></div>)}</div></div>
                  <div className="case-actions"><button className="primary-button" onClick={()=>setStage("investigations")}>PROCEED TO INVESTIGATIONS <ChevronRight size={16}/></button></div>
                </div>}
                {stage === "investigations" && <div className="case-content">
                  <div className="instruction-banner"><TestTube2 size={18}/><span><b>Choose investigations</b><small>Select relevant tests. Results are fixed for this case and can be reviewed any time.</small></span><span className="result-count">{obtained.length} / {totalInvestigations}</span></div>
                  <div className="investigation-grid">{activeCase.investigations.map(inv=><button key={inv.id} className={`investigation-option ${obtained.includes(inv.id)?"selected":""}`} onClick={()=>toggleInvestigation(inv.id)}><span className="test-icon"><PixelInvestigationIcon id={inv.id}/></span><span><b>{inv.name}</b><small>{inv.category}</small></span>{obtained.includes(inv.id) ? <Check size={16}/> : <Plus size={16}/>}</button>)}</div>
                  <div className="results-area"><div className="results-heading"><h3><ClipboardCheck size={16}/> INVESTIGATION RESULTS</h3><span>{obtainedInvestigations.length} RESULTS AVAILABLE</span></div>
                    {obtainedInvestigations.length ? obtainedInvestigations.map(inv=><InvestigationResult key={inv.id} inv={inv}/>) : <div className="results-empty">No investigations selected yet. Choose one or more tests above.</div>}
                  </div>
                  <div className="case-actions split"><button className="outline-button" onClick={()=>setStage("presentation")}><ArrowLeft size={15}/> BACK TO PRESENTATION</button><button className="primary-button" disabled={obtained.length===0} onClick={()=>setStage("diagnosis")}>PROCEED TO DIAGNOSIS <ChevronRight size={16}/></button></div>
                </div>}
                {stage === "diagnosis" && <div className="case-content">
                  <div className="instruction-banner"><Brain size={18}/><span><b>Clinical reasoning</b><small>Choose the most likely diagnosis and the underlying mechanism.</small></span></div>
                  <div className="case-section"><h3>01 / MOST LIKELY DIAGNOSIS</h3><div className="answer-list">{activeCase.diagnosisOptions.map(o=><button key={o} className={`answer-option ${diagnosis===o?"selected":""}`} onClick={()=>setDiagnosis(o)}><span className="radio-dot"/>{o}</button>)}</div></div>
                  <div className="case-section"><h3>02 / UNDERLYING MECHANISM</h3><div className="answer-list">{activeCase.mechanismOptions.map(o=><button key={o} className={`answer-option ${mechanism===o?"selected":""}`} onClick={()=>setMechanism(o)}><span className="radio-dot"/>{o}</button>)}</div></div>
                  <div className="case-actions split"><button className="outline-button" onClick={()=>setStage("investigations")}><ArrowLeft size={15}/> REVIEW RESULTS</button><button className="primary-button" disabled={!diagnosis || !mechanism} onClick={submitDiagnosis}>LOCK DIAGNOSIS <ChevronRight size={16}/></button></div>
                </div>}
                {stage === "management" && <div className="case-content">
                  <div className="instruction-banner warning"><ShieldCheck size={18}/><span><b>Management planning</b><small>Select all appropriate management priorities for this simulated patient. This is an educational case, not a live clinical protocol.</small></span></div>
                  <div className="answer-list management-list">{activeCase.managementOptions.map(o=><button key={o.id} className={`management-option ${management.includes(o.id)?"selected":""}`} onClick={()=>setManagement(prev=>prev.includes(o.id)?prev.filter(x=>x!==o.id):[...prev,o.id])}><span className="checkbox">{management.includes(o.id)&&<Check size={12}/>}</span><span><b>{o.label}</b><small>{o.detail}</small></span></button>)}</div>
                  <div className="case-actions split"><button className="outline-button" onClick={()=>setStage("diagnosis")}><ArrowLeft size={15}/> BACK</button><button className="primary-button" disabled={!management.length} onClick={submitManagement}>SUBMIT MANAGEMENT <ChevronRight size={16}/></button></div>
                </div>}
                {stage === "review" && <div className="case-content">
                  <div className="score-banner"><div className="score-ring"><b>{caseScoreTotal}</b><small>/100</small></div><div><div className="eyebrow">ENCOUNTER COMPLETE</div><h3>CASE REVIEW</h3><p>Your answers are compared with the structured teaching key.</p></div></div>
                  <div className="performance-grid"><div><small>DIAGNOSIS</small><b className={caseScore?.diagnosis?"good":"bad"}>{caseScore?.diagnosis?"CORRECT":"INCORRECT"}</b></div><div><small>MECHANISM</small><b className={caseScore?.mechanism?"good":"bad"}>{caseScore?.mechanism?"CORRECT":"INCORRECT"}</b></div><div><small>MANAGEMENT</small><b>{caseScore?.management ?? 0}%</b></div></div>
                  <div className="case-section"><h3><Check size={16}/> CORRECT DIAGNOSIS</h3><p><b>{activeCase.correctDiagnosis}</b></p><p>{activeCase.explanation}</p></div>
                  <div className="case-section"><h3><Brain size={16}/> PATHOPHYSIOLOGY</h3><p>{activeCase.pathophysiology}</p></div>
                  <div className="case-section"><h3><TestTube2 size={16}/> INVESTIGATION INTERPRETATION</h3>{activeCase.investigations.filter(i=>obtained.includes(i.id)).map(i=><div className="review-investigation" key={i.id}><b>{i.name}</b><span>{i.result} {i.units||""}</span><p>{i.interpretation}</p></div>)}</div>
                  <div className="case-section"><h3><ClipboardCheck size={16}/> MANAGEMENT KEY</h3>{activeCase.managementOptions.map(o=><div className={`management-review ${activeCase.correctManagement.includes(o.id)?"is-correct":management.includes(o.id)?"is-wrong":""}`} key={o.id}><b>{activeCase.correctManagement.includes(o.id)?"✓":management.includes(o.id)?"×":"–"} {o.label}</b><p>{o.detail}</p></div>)}</div>
                  <div className="case-section"><h3><Search size={16}/> DIFFERENTIAL DIAGNOSES</h3>{activeCase.differentials.map(d=><div className="differential" key={d.name}><b>{d.name}</b><p>{d.whyNot}</p></div>)}</div>
                  <div className="case-section"><h3><BookOpen size={16}/> USMLE-STYLE LEARNING OBJECTIVES</h3><ul>{activeCase.learningObjectives.map(x=><li key={x}>{x}</li>)}</ul></div>
                  <div className="supporting-note"><b>TOPIC ALIGNMENT</b><p>Directly selected: {selectedCaseTopics.join(", ") || "No direct selected topic recorded"}. Supporting concepts: {activeCase.supportingConcepts.join(", ")}.</p></div>
                  <div className="case-actions split"><button className="outline-button" onClick={()=>{resetCase();setPage("Study");}}>BACK TO STUDY</button><button className="primary-button" onClick={()=>{resetCase();setPage("Study");}}>FINISH ENCOUNTER <Check size={16}/></button></div>
                </div>}
              </div>
            </div>
            <aside className="encounter-aside">
              <div className="panel aside-panel"><div className="panel-head case-note-head"><div className="panel-title"><span className="section-icon"><ClipboardList size={16}/></span><div><h2>CASE NOTE</h2><small>ENCOUNTER SNAPSHOT</small></div></div></div><div className="aside-content"><div className="aside-stat"><small>CASE ID</small><b>{activeCase.id.toUpperCase()}</b></div><div className="aside-stat"><small>DIFFICULTY</small><b>{activeCase.difficulty}</b></div><div className="aside-stat"><small>INVESTIGATIONS</small><b>{obtained.length} obtained</b></div><div className="aside-stat"><small>SELECTED TOPICS</small><b>{selectedCaseTopics.join(", ") || "—"}</b></div><button className="outline-button full" onClick={()=>setStage("investigations")}>OPEN RESULTS ({obtained.length})</button><button className="text-action exit-case" onClick={()=>{if(confirm("Exit this encounter? Your current answers will be lost.")){resetCase();setPage("Study");}}}>EXIT ENCOUNTER</button></div></div>
              <div className="safety-note"><AlertTriangle size={16}/><p><b>Educational simulation</b><br/>Not a substitute for supervised clinical care or local protocols. Case results are fixed teaching data.</p></div>
            </aside>
          </div>}
        </section>}

        {page === "Emergency" && <div className="placeholder-panel panel"><div className="placeholder-art"><HeartPulse size={42}/></div><div className="eyebrow">DEVELOPMENT STATUS // MILESTONE 04</div><h2>EMERGENCY SIMULATIONS</h2><p>Time-dependent patient physiology and dynamic stabilization are intentionally not mocked in this milestone.</p></div>}
        {page === "Progress" && <div className="progress-world">
          <div className="panel progress-panel player-profile-panel">
            <div className="panel-head"><div className="panel-title"><span className="section-icon amber"><Trophy size={17}/></span><div><h2>01 / PLAYER PROFILE</h2><small>YOUR CLINICAL RPG PROGRESSION</small></div></div></div>
            <div className={`profile-overview banner-${customization.banner}`}>
              <div className={`profile-avatar frame-${customization.frame}`}><img src={avatarCatalog.find(a=>a.id===customization.avatar)?.image ?? avatarCatalog[0].image} alt={avatarCatalog.find(a=>a.id===customization.avatar)?.name ?? "MEDQUEST avatar"}/></div>
              <div className="profile-identity"><b>{customization.playerName || playerProfile.name}</b><small>{customization.title.toUpperCase()} · LEVEL {String(xpLevel(playerProfile.totalXp)).padStart(2,"0")}/50</small></div>
              <div className="profile-xp-total"><b>{playerProfile.totalXp.toLocaleString()}</b><small>TOTAL XP</small></div>
            </div>
            <div className="profile-level-row"><span>LEVEL {xpLevel(playerProfile.totalXp)}</span><b>{xpLevel(playerProfile.totalXp) >= 50 ? "MAX LEVEL" : `${xpInLevel(playerProfile.totalXp)} / 250 XP`}</b></div>
            <div className="profile-level-track"><i style={{width:`${xpLevel(playerProfile.totalXp) >= 50 ? 100 : xpInLevel(playerProfile.totalXp) / 250 * 100}%`}}/></div>
            <div className="profile-footnote">Case XP is awarded once per unique case. Daily challenges award a separate 75 XP bonus once per calendar day.</div>
          </div>

          <div className="panel progress-panel daily-challenge-panel">
            <div className="panel-head"><div className="panel-title"><span className="section-icon amber"><Sparkles size={17}/></span><div><h2>DAILY CLINICAL CHALLENGE</h2><small>ONE NEW CASE EVERY DAY · BONUS XP</small></div></div><span className="daily-streak-pill">🔥 {visibleDailyStreak} DAY STREAK</span></div>
            <div className="daily-challenge-body"><div className="daily-challenge-copy"><span className="daily-date">TODAY // {todayKey}</span><h3>{dailyChallengeCase.title}</h3><p>{dailyChallengeCase.subjectTags.join(" · ")} · {dailyChallengeCase.difficulty}</p><div className="daily-reward">✦ +75 BONUS XP <span>·</span> COMPLETE TODAY TO KEEP YOUR STREAK</div></div><div className="daily-challenge-action">{dailyChallengeCompleted ? <div className="daily-complete-state"><Check size={18}/> COMPLETED TODAY</div> : <button className="daily-play-button" onClick={()=>{setDailyChallengeActive(true);setActiveCase(dailyChallengeCase);setObtained([]);setDiagnosis("");setMechanism("");setManagement([]);setCaseScore(null);setStage("presentation");setPage("OPD");}}>PLAY DAILY CHALLENGE <ChevronRight size={15}/></button>}<small>LONGEST STREAK: {dailyProgress.longestStreak} DAYS</small></div></div>
          </div>
          <div className="progress-overview">
            <div className="progress-stat-card"><small>CASES REVIEWED</small><strong>{new Set([...reviewedIds,...caseResults.map(r=>r.caseId)]).size}</strong><span>Unique encounters completed</span></div>
            <div className="progress-stat-card"><small>AVERAGE SCORE</small><strong>{caseResults.length ? Math.round(caseResults.reduce((n,r)=>n+r.score,0)/caseResults.length) : 0}%</strong><span>Latest score per case</span></div>
            <div className="progress-stat-card"><small>SUBJECT AREAS</small><strong>{new Set(caseResults.flatMap(r=>r.subjects)).size}</strong><span>Areas encountered</span></div>
          </div>
          <div className="panel progress-panel"><div className="panel-head"><div className="panel-title"><span className="section-icon"><Trophy size={17}/></span><div><h2>01 / CASE HISTORY</h2><small>YOUR COMPLETED ENCOUNTERS</small></div></div></div>
            {caseResults.length || reviewedIds.length ? <div className="progress-case-list">{[...caseResults].reverse().map(r=><div className="progress-case-row" key={r.caseId}><div><b>{r.title}</b><small>{r.subjects.join(" · ")} · {new Date(r.completedAt).toLocaleDateString()}</small></div><strong className={r.score>=80?"score-high":r.score>=60?"score-mid":"score-low"}>{r.score}%</strong></div>)}{reviewedIds.filter(id=>!caseResults.some(r=>r.caseId===id)).map(id=><div className="progress-case-row" key={id}><div><b>{CASES.find(c=>c.id===id)?.title || id}</b><small>Completed before Milestone 3 · score not recorded</small></div><strong className="score-mid">LEGACY</strong></div>)}</div> : <div className="progress-empty">No encounters completed yet. Finish an OPD case to start building your clinical record.</div>}
          </div>
          <div className="panel progress-panel"><div className="panel-head"><div className="panel-title"><span className="section-icon"><Brain size={17}/></span><div><h2>02 / TOPIC PERFORMANCE</h2><small>ACCURACY BY CLINICAL TOPIC</small></div></div></div>
            {caseResults.length ? <div className="topic-performance">{Array.from(new Set(caseResults.flatMap(r=>r.topics))).map(topic=>{const rows=caseResults.filter(r=>r.topics.includes(topic));const accuracy=Math.round(rows.reduce((n,r)=>n+r.score,0)/rows.length);return <div className="topic-performance-row" key={topic}><div><b>{topic}</b><small>{rows.length} case{rows.length===1?"":"s"} · latest attempt per case</small></div><div className="topic-progress-track"><i style={{width:`${accuracy}%`}}/></div><strong>{accuracy}%</strong></div>})}</div> : <div className="progress-empty">Topic accuracy will appear after your first completed encounter.</div>}
          </div>
          <div className="panel progress-panel"><div className="panel-head"><div className="panel-title"><span className="section-icon"><BookOpen size={17}/></span><div><h2>03 / SUBJECT PERFORMANCE</h2><small>AVERAGE CASE SCORE BY SUBJECT</small></div></div></div>
            {caseResults.length ? <div className="topic-performance">{Array.from(new Set(caseResults.flatMap(r=>r.subjects))).map(subject=>{const rows=caseResults.filter(r=>r.subjects.includes(subject));const accuracy=Math.round(rows.reduce((n,r)=>n+r.score,0)/rows.length);return <div className="topic-performance-row" key={subject}><div><b>{subject}</b><small>{rows.length} linked case{rows.length===1?"":"s"}</small></div><div className="topic-progress-track"><i style={{width:`${accuracy}%`}}/></div><strong>{accuracy}%</strong></div>})}</div> : <div className="progress-empty">Subject performance will appear after your first completed encounter.</div>}
          </div>
          <div className="panel progress-panel mastery-panel">
            <div className="panel-head"><div className="panel-title"><span className="section-icon"><Brain size={17}/></span><div><h2>04 / CLINICAL MASTERY</h2><small>TOPIC AND SUBJECT KNOWLEDGE TRACKER</small></div></div></div>
            <div className="mastery-explainer">Mastery combines diagnosis (35%), mechanism (20%), management (35%) and investigation selection (10%). Each unique case contributes its latest recorded result. Unattempted topics remain unassessed.</div>
            <div className="mastery-subject-grid">{subjectMastery.map(item => <div className="mastery-subject-card" key={item.subject}><div><b>{item.subject}</b><small>{item.attempts} linked case{item.attempts===1?"":"s"}</small></div><strong className={item.score===null?"mastery-na":item.score>=80?"score-high":item.score>=60?"score-mid":"score-low"}>{item.score===null?"—":`${item.score}%`}</strong>{item.score!==null&&<div className="mastery-track"><i style={{width:`${item.score}%`}}/></div>}</div>)}</div>
            <div className="mastery-topic-heading"><b>TOPIC MASTERY</b><small>{topicMastery.filter(t=>t.score!==null).length} assessed · {topicMastery.length} syllabus topics</small></div>
            {topicMastery.some(t=>t.score!==null) ? <div className="mastery-topic-list">{topicMastery.filter(t=>t.score!==null).sort((a,b)=>(a.score??0)-(b.score??0)).map(t=><div className="mastery-topic-row" key={t.id}><div className="mastery-topic-name"><b>{t.name}</b><small>{t.subject} · {t.system} · {t.attempts} case{t.attempts===1?"":"s"}</small></div><div className="mastery-track"><i className={(t.score??0)<60?"needs-revision":(t.score??0)>=80?"strong-mastery":""} style={{width:`${t.score}%`}}/></div><strong className={(t.score??0)>=80?"score-high":(t.score??0)>=60?"score-mid":"score-low"}>{t.score}%</strong>{(t.score??100)<60&&t.status!=="Revision"&&<button className="mastery-revision-button" onClick={()=>setTopicStatusById(t.id,"Revision")}>ADD TO REVISION</button>}{t.status==="Revision"&&<span className="mastery-revision-tag">REVISION</span>}</div>)}</div> : <div className="progress-empty">Complete clinical cases to begin measuring topic mastery. Topics without linked case results are not assigned a score.</div>}
            <div className="mastery-topic-heading"><b>REVISION PRIORITIES</b><small>Based on recorded case performance</small></div>
            {revisionSuggestions.length ? <div className="mastery-recommendations">{revisionSuggestions.slice(0,5).map(t=><div key={t.id}><span><b>{t.name}</b><small>{t.subject} · {t.attempts} case{t.attempts===1?"":"s"}</small></span><strong>{t.score}%</strong><button onClick={()=>setTopicStatusById(t.id,"Revision")}>{t.status==="Revision"?"IN REVISION":"MARK FOR REVISION"}</button></div>)}</div> : <div className="mastery-no-revision">No topics currently fall below the 60% revision threshold. Unassessed topics still need case exposure.</div>}
          </div>
          <div className="panel progress-panel achievement-panel">
            <div className="panel-head"><div className="panel-title"><span className="section-icon amber"><Trophy size={17}/></span><div><h2>06 / ACHIEVEMENTS</h2><small>{unlockedAchievements.length} OF {ACHIEVEMENTS.length} UNLOCKED · CLINICAL MILESTONES</small></div></div></div>
            <div className="achievement-grid">{ACHIEVEMENTS.map(a => { const unlocked = unlockedAchievements.includes(a.id); return <div className={`achievement-card ${unlocked ? "is-unlocked" : "is-locked"}`} key={a.id}><div className="achievement-icon">{unlocked ? a.icon : "?"}</div><div className="achievement-copy"><b>{a.title}</b><small>{a.description}</small><em>{unlocked ? "UNLOCKED" : a.requirement}</em></div><span className="achievement-state">{unlocked ? "✓" : "LOCKED"}</span></div>; })}</div>
          </div>
          <div className="progress-footnote">Achievements are earned through recorded case performance. Topic mastery is estimated from recorded case performance and is not a clinical-competence certification. Scores represent structured case-answer performance, not clinical competence.</div>
        </div>}
        {page === "Settings" && <div className="customization-world">
          <section className={`panel customization-hero banner-${customization.banner}`}><div className={`custom-avatar-preview frame-${customization.frame}`}><img src={avatarCatalog.find(a=>a.id===customization.avatar)?.image ?? avatarCatalog[0].image} alt="Selected MEDQUEST avatar"/></div><div><div className="eyebrow">PLAYER IDENTITY // LEVEL {currentLevel}</div><h2>{customization.playerName || "MEDQUEST PLAYER"}</h2><p>{customization.title} · {playerProfile.totalXp.toLocaleString()} XP</p><small>{avatarCatalog.find(a=>a.id===customization.avatar)?.name} · {avatarCatalog.find(a=>a.id===customization.avatar)?.role}</small></div></section>
          <section className="panel customization-panel"><div className="panel-head"><div className="panel-title"><span className="section-icon"><UserRound size={17}/></span><div><h2>01 / PLAYER IDENTITY</h2><small>YOUR NAME, AVATAR AND EARNED TITLE</small></div></div></div><div className="custom-form-grid"><label>PLAYER NAME<input maxLength={24} value={customization.playerName} onChange={e=>setCustomization(v=>({...v,playerName:e.target.value}))} placeholder="Enter player name"/></label><label>PLAYER TITLE<select value={customization.title} onChange={e=>setCustomization(v=>({...v,title:e.target.value}))}>{earnedTitles.map(t=><option key={t.name}>{t.name}</option>)}</select></label></div><div className="avatar-select-grid">{avatarCatalog.map(a=><button type="button" key={a.id} className={`avatar-select-card ${customization.avatar===a.id?"selected":""}`} onClick={()=>setCustomization(v=>({...v,avatar:a.id}))}><img src={a.image} alt={a.name}/><span><b>{a.name}</b><small>{a.role}</small><em>{a.story}</em></span></button>)}</div></section>
          <section className="panel customization-panel"><div className="panel-head"><div className="panel-title"><span className="section-icon"><Trophy size={17}/></span><div><h2>03 / PROFILE PRESENTATION</h2><small>FRAMES AND SIGNATURE BANNERS</small></div></div></div><div className="cosmetic-grid">{cosmeticCatalog.frames.map(item=><button key={item.id} disabled={currentLevel<item.level} className={`cosmetic-choice ${customization.frame===item.id?"selected":""}`} onClick={()=>setCustomization(v=>({...v,frame:item.id}))}><b>{item.name}</b><small>{currentLevel>=item.level?"UNLOCKED":`LOCKED · LEVEL ${item.level}`}</small></button>)}</div><div className="cosmetic-grid">{cosmeticCatalog.banners.map(item=><button key={item.id} disabled={currentLevel<item.level} className={`cosmetic-choice ${customization.banner===item.id?"selected":""}`} onClick={()=>setCustomization(v=>({...v,banner:item.id}))}><b>{item.name}</b><small>{currentLevel>=item.level?"UNLOCKED":`LOCKED · LEVEL ${item.level}`}</small></button>)}</div></section>
          <section className="panel customization-panel"><div className="panel-head"><div className="panel-title"><span className="section-icon"><Activity size={17}/></span><div><h2>04 / AUDIO SETTINGS</h2><small>ORIGINAL SYNTHESISED MEDQUEST AUDIO</small></div></div></div><div className="audio-setting"><label><input type="checkbox" checked={audioPrefs.sfxOn} onChange={e=>setAudioPrefs(v=>({...v,sfxOn:e.target.checked}))}/> SOUND EFFECTS</label><input aria-label="Sound effects volume" type="range" min="0" max="100" value={audioPrefs.sfxVolume} onChange={e=>setAudioPrefs(v=>({...v,sfxVolume:Number(e.target.value)}))}/><b>{audioPrefs.sfxVolume}%</b><button className="outline-button" onClick={playSfx}>TEST</button></div><div className="audio-setting"><label><input type="checkbox" checked={audioPrefs.musicOn} onChange={e=>setAudioPrefs(v=>({...v,musicOn:e.target.checked}))}/> BACKGROUND MUSIC</label><input aria-label="Background music volume" type="range" min="0" max="100" value={audioPrefs.musicVolume} onChange={e=>setAudioPrefs(v=>({...v,musicVolume:Number(e.target.value)}))}/><b>{audioPrefs.musicVolume}%</b></div><p className="custom-footnote">Main menu soundtrack: Dentist's Office.mp3. Playback loops while background music is enabled. Some browsers require an initial interaction before audio can start.</p></section>
          <section className="panel customization-panel"><div className="panel-head"><div className="panel-title"><span className="section-icon"><ShieldCheck size={17}/></span><div><h2>05 / LOCAL SAVE & DATA</h2><small>YOUR PROGRESSION REMAINS ON THIS DEVICE</small></div></div></div><p>Customisation, audio preferences, XP, achievements, mastery and daily streaks are saved in this browser. Existing M5.1–M5.4 data is preserved.</p><div className="settings-actions"><div><b>LOCAL DATA</b><small>Stored in this browser using LocalStorage.</small></div><button className="danger-button" onClick={()=>{if(confirm("Delete all MEDQUEST topics, presets and progress from this browser? This also removes M5.5 customisation and audio preferences.")){["mq-topics-v1","mq-presets-v1","mq-config-v1","mq-reviewed-v1","mq-case-results-v1","mq-prioritize-revision-v1","mq-player-profile-v1","mq-achievements-v1","mq-daily-challenge-v1","mq-customization-v1","mq-audio-v1"].forEach(k=>localStorage.removeItem(k));setTree(makeInitialTree());setPresets([]);setConfig(initialConfig);setReviewedIds([]);setCaseResults([]);setPlayerProfile(initialPlayerProfile);setUnlockedAchievements([]);setDailyProgress(initialDailyProgress);setPrioritizeRevision(false);setCustomization(initialCustomization);setAudioPrefs(initialAudio);resetCase();toast("LOCAL DATA RESET");}}}>RESET LOCAL DATA</button></div></section>
        </div>}

        <footer className="main-footer"><span>MEDQUEST // TRAIN SMART. THINK CLINICALLY.</span><span>NO BACKEND REQUIRED <i/> OFFLINE-READY FOUNDATION</span></footer>
      </main>
    </div>
    {notice && <div className="toast"><Check size={15}/>{notice}</div>}
    {showPresetSave && <div className="modal-backdrop" onClick={()=>setShowPresetSave(false)}><div className="modal panel" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setShowPresetSave(false)}><X size={17}/></button><div className="eyebrow">SAVE CONFIGURATION</div><h2>Save topic preset</h2><p>Keep this subject, system, topic selection, mode and difficulty for a future session.</p><label>PRESET NAME</label><input autoFocus value={presetName} onChange={e=>setPresetName(e.target.value)} onKeyDown={e=>e.key==="Enter"&&savePreset()} placeholder="e.g. CVS pathology revision"/><div className="modal-actions"><button className="outline-button" onClick={()=>setShowPresetSave(false)}>CANCEL</button><button className="primary-button" disabled={!presetName.trim()} onClick={savePreset}><Save size={15}/> SAVE PRESET</button></div></div></div>}
  </div>;
}


function PixelInvestigationIcon({ id }: { id: string }) {
  const common = { shapeRendering: "crispEdges" as const };
  const palette: Record<string, { bg: string; ink: string; accent: string }> = {
    vitals: { bg: "#ffe5df", ink: "#c65d64", accent: "#f39a88" },
    glucose: { bg: "#fff0c9", ink: "#a66b24", accent: "#f0b64e" },
    ketones: { bg: "#f3e6ff", ink: "#8057a5", accent: "#bd91df" },
    abg: { bg: "#e4efff", ink: "#5578ad", accent: "#8db2e6" },
    electrolytes: { bg: "#e3f4e8", ink: "#3f8a65", accent: "#83c99c" },
    renal: { bg: "#e4efff", ink: "#5274a9", accent: "#8cb6e8" },
    cbc: { bg: "#ffe5e8", ink: "#b84e62", accent: "#e88a9b" },
    urine: { bg: "#fff1d9", ink: "#ad7b35", accent: "#e6bd70" },
    ecg: { bg: "#e0f5e9", ink: "#36865e", accent: "#78c99a" },
    cxr: { bg: "#e8eaff", ink: "#656cb0", accent: "#a2a9e7" },
    troponin: { bg: "#ffe5e8", ink: "#b84e62", accent: "#e88a9b" },
    crp: { bg: "#fff0c9", ink: "#a66b24", accent: "#f0b64e" },
    culture: { bg: "#e4f2e9", ink: "#3f8a65", accent: "#83c99c" },
    iron: { bg: "#ffe5e8", ink: "#b84e62", accent: "#e88a9b" },
    smear: { bg: "#ffe5e8", ink: "#b84e62", accent: "#e88a9b" },
    retic: { bg: "#ffe5e8", ink: "#b84e62", accent: "#e88a9b" },
    b12: { bg: "#f3e6ff", ink: "#8057a5", accent: "#bd91df" },
    stool: { bg: "#fff1d9", ink: "#ad7b35", accent: "#e6bd70" },
    ultrasound: { bg: "#e8eaff", ink: "#656cb0", accent: "#a2a9e7" },
    ct: { bg: "#e8eaff", ink: "#656cb0", accent: "#a2a9e7" },
  };
  const p = palette[id] || palette.vitals;
  return <svg {...common} viewBox="0 0 32 32" width="27" height="27" aria-hidden="true">
    <rect x="2" y="2" width="28" height="28" rx="3" fill={p.bg}/>
    {id === "ecg" || id === "vitals" || id === "troponin" ? <>
      <rect x="5" y="7" width="22" height="18" fill="#fffaf0"/>
      <path d="M6 17h5l2-5 3 10 3-7 2 2h5" fill="none" stroke={p.ink} strokeWidth="2.5" strokeLinejoin="miter"/>
      <rect x="5" y="5" width="4" height="2" fill={p.accent}/>
    </> : id === "electrolytes" ? <>
      <rect x="7" y="7" width="18" height="18" fill="#fffaf0"/>
      <rect x="9" y="9" width="14" height="14" fill={p.accent}/>
      <text x="16" y="20" textAnchor="middle" fontSize="10" fontWeight="900" fill={p.ink}>K+</text>
    </> : id === "glucose" || id === "ketones" ? <>
      <path d="M16 5L8 16v7h16v-7z" fill={p.accent} stroke={p.ink} strokeWidth="1.5"/>
      <rect x="12" y="16" width="8" height="5" fill="#fffaf0"/>
      <text x="16" y="13" textAnchor="middle" fontSize="6" fontWeight="900" fill={p.ink}>{id === "glucose" ? "GLU" : "KET"}</text>
    </> : id === "abg" ? <>
      <path d="M16 5v5M16 10c-7-6-11 1-9 9 1 5 5 7 9 3M16 10c7-6 11 1 9 9-1 5-5 7-9 3" fill={p.accent} stroke={p.ink} strokeWidth="1.5"/>
      <path d="M16 10v14" stroke={p.ink} strokeWidth="2"/>
    </> : id === "renal" ? <>
      <path d="M12 6C5 5 5 14 8 21c2 5 7 5 9 0V11c-1-3-2-5-5-5M20 6c7-1 7 8 4 15-2 5-7 5-9 0V11c1-3 2-5 5-5" fill={p.accent} stroke={p.ink} strokeWidth="1.5"/>
    </> : id === "cbc" || id === "iron" || id === "smear" || id === "retic" || id === "b12" ? <>
      <circle cx="11" cy="13" r="5" fill={p.accent} stroke={p.ink} strokeWidth="1.5"/>
      <circle cx="21" cy="12" r="4" fill="#fffaf0" stroke={p.ink} strokeWidth="1.5"/>
      <circle cx="17" cy="22" r="5" fill={p.accent} stroke={p.ink} strokeWidth="1.5"/>
    </> : id === "urine" || id === "stool" ? <>
      <path d="M11 5h10l-1 5 4 12-2 4H10l-2-4 4-12z" fill={p.accent} stroke={p.ink} strokeWidth="1.5"/>
      <path d="M10 19h12" stroke="#fffaf0" strokeWidth="2"/>
    </> : id === "culture" ? <>
      <rect x="7" y="6" width="18" height="20" fill="#fffaf0" stroke={p.ink} strokeWidth="1.5"/>
      <circle cx="12" cy="12" r="2" fill={p.accent}/><circle cx="19" cy="14" r="2" fill={p.ink}/><circle cx="14" cy="20" r="2" fill={p.accent}/>
    </> : <>
      <rect x="6" y="6" width="20" height="20" fill="#fffaf0" stroke={p.ink} strokeWidth="1.5"/>
      <path d="M11 9v14m10-14v14M8 16h16" stroke={p.accent} strokeWidth="2"/>
      <path d="M14 10l4 12m0-12l-4 12" stroke={p.ink} strokeWidth="1.5"/>
    </>}
  </svg>;
}

function InvestigationResult({ inv }: { inv: Investigation }) {
  return <div className="investigation-result" data-kind={inv.id}><div className="result-top"><span className="result-title"><span className="result-pixel-icon"><PixelInvestigationIcon id={inv.id}/></span><b>{inv.name}</b></span><span className={inv.useful?"useful":"low-value"}>{inv.useful?"CLINICALLY RELEVANT":"LOW-VALUE HERE"}</span></div><div className="result-value">{inv.result} {inv.units && <span>{inv.units}</span>}</div>{inv.reference && <div className="reference-range">Reference: {inv.reference}</div>}<p>{inv.interpretation}</p><small><b>WHY ORDER IT?</b> {inv.relevance}</small></div>;
}