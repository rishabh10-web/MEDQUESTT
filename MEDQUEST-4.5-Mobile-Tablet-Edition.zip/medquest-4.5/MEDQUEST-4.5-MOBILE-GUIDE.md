# MEDQUEST 4.5 — Mobile & Tablet Edition

This release is based on MEDQUEST 4.4 and preserves its existing React/Vite application, clinical content, game systems, typography and signature palette.

## What's changed
- Responsive layout refinements for iPhone, iPad and Windows PC.
- Touch-friendly control sizing on touch devices.
- iPhone safe-area handling for the home indicator and top status area.
- Better tablet layouts for Study, OPD and Progress.
- Responsive clinical encounter panels and case navigation.
- PWA web manifest, 192px/512px app icons and Apple touch icon.
- Updated app title and theme metadata.
- Vercel SPA rewrite configuration.
- No offline mode or service-worker caching was added: internet access is required, as requested.

## Run locally
Requires Node.js LTS.

```powershell
npm.cmd install
npm.cmd run build
npm.cmd run dev
```

## Deploy using Vercel
1. Create a GitHub repository and upload the contents of this project folder (the folder containing `package.json`).
2. Sign in to Vercel and choose **Add New → Project**.
3. Import the GitHub repository.
4. Framework preset: **Vite**.
5. Build command: `npm run build`.
6. Output directory: `dist`.
7. Deploy. Vercel will provide an HTTPS URL.

The included `vercel.json` routes application paths back to `index.html` for SPA navigation.

## Install on devices
- **iPhone/iPad:** Open the deployed HTTPS URL in Safari → Share → Add to Home Screen → Add.
- **Windows PC:** Open the URL in Microsoft Edge or Chrome. Use the Install icon in the address bar (or browser menu → Apps / Install this site as an app).
- **Important:** iOS home-screen web apps require Safari's Add to Home Screen flow. The browser may require an initial tap before audio can play.

## Validation
The archive and project structure should be checked after extraction. A successful production build must be confirmed with `npm.cmd run build` in an environment where dependencies can be installed. This package does not claim that a remote production build or device-browser QA has already occurred.
