MEDQUEST 2.2 — LIGHT PIXEL RPG REFRESH

What's changed:
- Replaced the dark teal visual palette with warm cream, mint, peach and pastel blue/lavender.
- Added Press Start 2P, Pixelify Sans and Nunito font families (Google Fonts; internet connection required for web fonts).
- Replaced the generic DKA patient icon with the supplied young-woman pixel portrait.
- Added six supplied transparent PNG portraits under public/portraits/.
- Restyled the patient presentation, investigation cards, diagnosis/management choices, case review and navigation.
- Preserved the existing clinical case data, investigation results, answer keys, LocalStorage keys and workflow.

Portrait files currently included:
- young-woman.png (assigned to the DKA case)
- young-man.png
- middle-age-man.png
- middle-age-woman.png
- old-man.png
- old-woman.png

The project currently contains six supplied portraits, not twelve. Add future portraits to public/portraits/ and assign their paths in src/data.ts when adding cases.

INSTALL / UPDATE:
1. Back up your current MEDQUEST project folder.
2. Extract this ZIP.
3. Copy the contents of the extracted medquest-2-m2 folder over your existing project folder, allowing updated files to replace old ones.
4. Keep the same project folder and localhost port where possible; this preserves the browser's LocalStorage origin.
5. In PowerShell inside the project folder run:
   npm.cmd install
   npm.cmd run dev
6. Open the localhost URL printed by Vite and refresh the DKA encounter.

Build verification:
A production build could not be completed in the packaging environment because npm dependency installation timed out and React/Vite packages were unavailable there. Run `npm.cmd run build` on the laptop after installation to verify the local environment.
