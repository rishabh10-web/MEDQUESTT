/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: { extend: { colors: { mq: { ink: "#101b24", panel: "#172832", mint: "#8de0c0", amber: "#ffc66d" } } } },
  plugins: []
};